<?php
/** The name of the database*/
define( 'DB_NAME', 'sakhile' );

/** MySQL database username */
define( 'DB_USER', 'sakhile' );

/** MySQL database password */
define( 'DB_PASSWORD', 'sakhile' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );
/** Web hostname */
define( 'WEB_HOST', 'http://'.$_SERVER['HTTP_HOST'].'/SakhileApp');