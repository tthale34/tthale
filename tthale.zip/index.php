<!DOCTYPE html>
<!-- saved from url=(0045)https://lmpixels.com/wp/leven-wp/dark/resume/ 
/* Permalink - use to edit and share this gradient: https://colorzilla.com/gradient-editor/#45484d+0,000000+100;Black+3D+%231 */
background: rgb(69,72,77); /* Old browsers */
background: -moz-linear-gradient(top, rgba(69,72,77,1) 0%, rgba(0,0,0,1) 100%); /* FF3.6-15 */
background: -webkit-linear-gradient(top, rgba(69,72,77,1) 0%,rgba(0,0,0,1) 100%); /* Chrome10-25,Safari5.1-6 */
background: linear-gradient(to bottom, rgba(69,72,77,1) 0%,rgba(0,0,0,1) 100%); /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#45484d', endColorstr='#000000',GradientType=0 );-->
<html lang="en-US" class=" js no-touch cssanimations csstransforms csstransforms3d csstransitions"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link rel="profile" href="https://gmpg.org/xfn/11">
<title>Resume &mdash; Tebogo Thale</title>
<meta name="robots" content="noindex,nofollow">
<link rel="dns-prefetch" href="https://fonts.googleapis.com/">
<!--<link rel="dns-prefetch" href="https://s.w.org/">
<link rel="alternate" type="application/rss+xml" title="Alex Smith � Feed" href="https://lmpixels.com/wp/leven-wp/dark/feed/">
<link rel="alternate" type="application/rss+xml" title="Alex Smith � Comments Feed" href="https://lmpixels.com/wp/leven-wp/dark/comments/feed/">
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/12.0.0-1\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/12.0.0-1\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/lmpixels.com\/wp\/leven-wp\/dark\/wp-includes\/js\/wp-emoji-release.min.js"}};
			/*! This file is auto-generated */
			!function(e,a,t){var r,n,o,i,p=a.createElement("canvas"),s=p.getContext&&p.getContext("2d");function c(e,t){var a=String.fromCharCode;s.clearRect(0,0,p.width,p.height),s.fillText(a.apply(this,e),0,0);var r=p.toDataURL();return s.clearRect(0,0,p.width,p.height),s.fillText(a.apply(this,t),0,0),r===p.toDataURL()}function l(e){if(!s||!s.fillText)return!1;switch(s.textBaseline="top",s.font="600 32px Arial",e){case"flag":return!c([127987,65039,8205,9895,65039],[127987,65039,8203,9895,65039])&&(!c([55356,56826,55356,56819],[55356,56826,8203,55356,56819])&&!c([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]));case"emoji":return!c([55357,56424,55356,57342,8205,55358,56605,8205,55357,56424,55356,57340],[55357,56424,55356,57342,8203,55358,56605,8203,55357,56424,55356,57340])}return!1}function d(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(i=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},o=0;o<i.length;o++)t.supports[i[o]]=l(i[o]),t.supports.everything=t.supports.everything&&t.supports[i[o]],"flag"!==i[o]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[i[o]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(r=t.source||{}).concatemoji?d(r.concatemoji):r.wpemoji&&r.twemoji&&(d(r.twemoji),d(r.wpemoji)))}(window,document,window._wpemojiSettings);
		</script><script src="./wp-emoji-release.min.js" type="text/javascript" defer=""></script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
<link rel="stylesheet" id="css-1-css" href="./753b35d8-1585890976.min.css" type="text/css" media="all">no difference
<link rel="stylesheet" id="leven-google-fonts-css" href="./css" type="text/css" media="all">
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://lmpixels.com/wp/leven-wp/dark/xmlrpc.php?rsd">
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://lmpixels.com/wp/leven-wp/dark/wp-includes/wlwmanifest.xml"> 
<meta name="generator" content="WordPress 5.4.1">
<link rel="canonical" href="https://lmpixels.com/wp/leven-wp/dark/resume/">
<link rel="shortlink" href="https://lmpixels.com/wp/leven-wp/dark/?p=171">
<link rel="alternate" type="application/json+oembed" href="https://lmpixels.com/wp/leven-wp/dark/wp-json/oembed/1.0/embed?url=https%3A%2F%2Flmpixels.com%2Fwp%2Fleven-wp%2Fdark%2Fresume%2F">
<link rel="alternate" type="text/xml+oembed" href="https://lmpixels.com/wp/leven-wp/dark/wp-json/oembed/1.0/embed?url=https%3A%2F%2Flmpixels.com%2Fwp%2Fleven-wp%2Fdark%2Fresume%2F&amp;format=xml">
<style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style>-->
<link rel="stylesheet" id="css-0-css" href="./tthale.css" type="text/css" media="all">
<!--<link rel="stylesheet" id="leven-customization-css" href="./customization.css.php" type="text/css" media="all">-->
<script type="text/javascript" src="./01ef1fff-1585891002.min.js"></script>
<link rel="icon" href="./slides/tthale.ico" sizes="192x192">
<style data-styles="leven-theme-columns-css" type="text/css">
    #col_inner_id-5eb6b660ec23b{ padding: 0px 0px 0px 0px; } 
    #col_inner_id-5eb6b660ec580{ padding: 0px 0px 0px 0px; } 
    #col_inner_id-5eb6b660ec978{ padding: 0px 0px 0px 0px; } 
    #col_inner_id-5eb6b660ecd32{ padding: 0px 0px 0px 0px; } 
    #col_inner_id-5eb6b660ecf4e{ padding: 0px 0px 0px 0px; } 
    #col_inner_id-5eb6b660ed22f{ padding: 0px 0px 0px 0px; } 
    #col_inner_id-5eb6b660ed526{ padding: 0px 0px 0px 0px; } 
    #col_inner_id-5eb6b660ed840{ padding: 0px 0px 0px 0px; } 
</style>
<style data-styles="leven-theme-skills-css" type="text/css">
    .design_imgs{
        max-height: 50%;
        max-width: 50%;
        border-radius: 20px;
        border:2px solid #7066ff;
    }
    #skill-95 .skill-percentage { width: 95%; } 
    #skill-95 > div.skill-percentage { background-color: #007ced; } 
    #skill-75 .skill-percentage { width: 75%; } 
    #skill-75 > div.skill-percentage { background-color: #007ced; } 
    #skill-85 .skill-percentage { width: 85%; } 
    #skill-85 > div.skill-percentage { background-color: #007ced; } 
    #skill-90 .skill-percentage { width: 90%; } 
    #skill-90 > div.skill-percentage { background-color: #007ced; } 
    #skill-100 .skill-percentage { width: 100%; } 
    #skill-100 > div.skill-percentage { background-color: #007ced; } 
    #skill-3e2329f0c9b69868e023b19ec23c82ab .skill-percentage { width: 90%; } 
    #skill-3e2329f0c9b69868e023b19ec23c82ab > div.skill-percentage { background-color: #007ced; } 
    #skill-7f9f771b32e3b1b5256069a455f3e6ab .skill-percentage { width: 90%; } 
    #skill-7f9f771b32e3b1b5256069a455f3e6ab > div.skill-percentage { background-color: #007ced; } 
    #skill-b4113e66cca1abbf19ee2966e729aef6 .skill-percentage { width: 85%; } 
    #skill-b4113e66cca1abbf19ee2966e729aef6 > div.skill-percentage { background-color: #007ced; }
    .contact{color: #fff;}
</style>
    </head>
<body data-rsssl="1" class="page-template-default page page-id-171 wp-embed-responsive masthead-fixed full-width singular">
<div class="lm-animated-bg transition" style="background-position: calc(50% + 2.23149px) calc(50% + 4.26382px);"></div>
<!-- Loading animation -->
<div class="preloader" style="display: none;">
  <div class="preloader-animation">
    <div class="preloader-spinner">
    </div>
  </div>
</div>
<!-- /Loading animation -->
<!-- Scroll To Top Button -->
<div class="lmpixels-scroll-to-top"><i class="lnr lnr-chevron-up"></i></div>
<!-- /Scroll To Top Button -->
<div class="">
    <div id="page_container" class="page-container bg-move-effect theme-style-dark animated transition-flip-in-right" 
         data-animation="transition-flip-in-right">
        <!-- Header -->
        <header id="site_header" class="header">
            <div class="header-content clearfix">
                <!-- Text Logo -->
                <div class="text-logo">
                    <a href="./tthale (2).jpg" class="lightbox">
                        <div class="logo-symbol"><img src="./tthale (2).jpg" style="border-radius: 90px;"></div>
                        <div class="logo-text">Tebogo <span>Thale</span></div>
                    </a>
                </div>
                <!-- /Text Logo -->
                <!-- Navigation -->
<div class="site-nav mobile-menu-hide">
    <ul id="menu-classic-menu" class="leven-classic-menu site-main-menu">
        <li id="menu-item-160" class="<?php if(!isset($_GET['page'])){echo 'current-menu-item';}?> menu-item">
            <a href="./" data-hover="1">About Me</a>
        </li>
        <li id="menu-item-174" class="<?php if(isset($_GET['page']) && $_GET['page'] == "resume"){echo 'current-menu-item';}?> menu-item current_page_item ">
            <a href="./?page=resume" aria-current="page" data-hover="1">C.V</a></li>
        <li id="menu-item-28" class="<?php if(isset($_GET['page']) && $_GET['page'] == "portfolio"){echo 'current-menu-item';}?> menu-item">
            <a href="./?page=portfolio" data-hover="1">Portfolio</a>
            <ul class="sub-menu">
                <li id="menu-item-33" class="menu-item"><a href="http://lemogamedia.co.za" data-hover="1">Lemoga Media</a></li>
                <li id="menu-item-33" class="menu-item"><a href="http://lemogamedia.co.za/MyStore" data-hover="1">MyStore</a></li>
            </ul>
        </li>
        <li id="menu-item-191" class="<?php if(isset($_GET['page']) && $_GET['page'] == "contact"){echo 'current-menu-item';}?> menu-item">
            <a href="./?page=contact" data-hover="1">Contact</a></li>
    </ul>
</div>
                <!-- /Navigation -->
                <a class="menu-toggle mobile-visible">
                    <i class="fa fa-bars"></i>
                </a>
            </div>
        </header>
        <!-- /Header -->
        <div id="main" class="site-main">
            <div id="main-content" class="single-page-content">
                <div id="primary" class="content-area">
                    <?php if(isset($_GET['page']) && $_GET['page'] == "resume") :?>
                    <!--Title-->
                    <div class="page-title">
                        <h1>Curriculum Vatae</h1>
                        <div class="page-subtitle">
                            <h4> 8 Years of Experience</h4>
                        </div>
                    </div>
                    <!--/Title-->
                    <?php else:?>
                        <!--Title-->
                        <!--Carousel Wrapper-->
                        <div id="carousel-example-1z" class="carousel slide carousel-fade pt-4" data-ride="carousel" style="border-radius: 100px;">
<?php require './scanDir.php';
// Scan multiple directories for files with provided file extension,
$file_ext = array("jpg","bmp","png");
$files = scanDir::scan('./slides', $file_ext);
?>
    <!--Indicators-->
    <ol class="carousel-indicators">
        <?php for($i = 0; $i < count($files); $i++):?>
        <li data-target="" data-slide-to="<?php echo $i;?>" <?php if($i == 0){ echo 'class="active"';}?>></li>
      <?php endfor;?>
    </ol>
    <!--/.Indicators-->
    <!--Slides-->
    <div class="carousel-inner" role="listbox">
      <?php for($i = 0; $i < count($files); $i++):?>
      <div class="carousel-item <?php if($i == 0){ echo 'active';}?>">
        <div class="view" style="min-height: 450px; border-radius: 20px;background-image: url('<?php echo preg_replace('/\\\/','/',$files[$i]);?>'); background-repeat: no-repeat; background-size: cover;">
          <!-- Mask & flexbox options-->
          <div class="mask rgba-black-strong d-flex justify-content-center align-items-center">
            <!-- Content -->
            <div class="text-center white-text mx-5 wow fadeIn">            
            </div>
            <!-- Content -->
          </div>
          <!-- Mask & flexbox options-->
        </div>
      </div>
      <?php endfor;?>
    </div><hr>
    <!--/.Slides-->
    <!--Controls-->
    <a class="carousel-control-prev" href="#carousel-example-1z" role="button" data-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="carousel-control-next" href="#carousel-example-1z" role="button" data-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="sr-only">Next</span>
    </a>
    <!--/.Controls-->
  </div>
  <!--/.Carousel Wrapper-->
                        <!--/Title-->
                    <?php endif;?>
                    <div id="content" class="page-content site-content single-post" role="main">
                        <article id="post-171" class="post-171 page type-page status-publish hentry">
                            <div class="entry-content">
                                <div class="fw-page-builder-content">
                                    <section class="fw-main-row  ">
<?php if(!isset($_GET['page'])) :?>
<!--About Page-->
<?php require './about.php';?>
<!--About Page-->
<?php endif;?>
<?php if(isset($_GET['page']) && $_GET['page'] == "resume") :?>
<!--Resume Page-->
<?php require './resume.php';?>
<!--Resume Page-->
<?php endif;?>
<?php if(isset($_GET['page']) && $_GET['page'] == "portfolio") :?>
<!--Portfolio Page-->
<?php require './portfolio.php';?>
<!--Portfolio Page-->
<?php endif;?>
<?php if(isset($_GET['page']) && $_GET['page'] == "contact") :?>
<!--Contact Page-->
<?php require './contact.php';?>
<!--Contact Page-->
<?php endif;?>
                                    </section>
                                </div>
                            </div><!-- .entry-content -->
                        </article><!-- #post-## -->
                    </div><!-- #content -->
                </div><!-- #primary -->
            </div><!-- #main-content -->
        </div>
        <!--Footer-->
        <footer class="site-footer clearfix">
            <div class="footer-social">
                <ul class="footer-social-links">
                    <li>
                        <a href="" target="_blank">Twitter</a>
                    </li>
                    <li>
                        <a href="" target="_blank">Facebook</a>
                    </li>
                    <li>
                        <a href="" target="_blank">Instagram</a>
                    </li>
                </ul>
            </div>
            <div class="footer-copyrights">
                <p>&COPY; 2020 All rights reserved.</p>
            </div>
        </footer>
        <!-- /Footer-->
    </div>
        
	<div id="blog-sidebar" class="blog-sidebar">
		<div class="sidebar-toggle">
			<span></span>
			<span></span>
			<span></span>
		</div>
		<div class="blog-sidebar-content clearfix">
                    <div class="sidebar-item">
                        <form role="search" method="get" class="search-form" action="">
                            <label>
                                <span class="screen-reader-text">Search&vellip;</span>
                                <input type="search" class="search-field" placeholder="Search" value="" name="s">
                            </label>
                            <input type="submit" class="search-submit" value="Search">
                        </form>
                    </div>
                    <div class="sidebar-item">
                        <div class="sidebar-title"><h4>Interests</h4></div>
                        <ul>
                            <li><a href="">Design</a></li>
                            <li><a href="">E-Commerce</a></li>
                            <li><a href="">UI&AMP;UX</a></li>
                            <li><a href="">PHP</a></li>
                            <li><a href="">JAVA</a></li>
                            <li><a href="">WordPress</a>
                            </li>
                        </ul>
                    </div>
                    <div class="sidebar-item">
                        <div class="sidebar-title"><h4>Menu</h4></div>		<ul>
				<li><a href="./">About Me</a></li>
                                <li><a href="./?page=resume">C.V</a></li>
                                <li><a href="./?page=portfolio">Portfolio</a></li>
                                <li><a href="./?page=contact">Contact</a></li>
		</ul>
			</div>
                    <div class="sidebar-item">
                        <div class="sidebar-title"><h4>Posts</h4></div>
                        <ul>
                            <li>
                                <a href="https://lmpixels.com/wp/leven-wp/dark/2019/12/04/how-to-make-a-wordpress-plugin-extensible/">How to Make a WordPress Plugin Extensible</a>
                            </li>
                            <li>
                                <a href="https://lmpixels.com/wp/leven-wp/dark/2019/12/04/6-easy-steps-to-better-icon-design/">6 Easy Steps to Better Icon Design</a>
                            </li>
                            <li>
                                <a href="https://lmpixels.com/wp/leven-wp/dark/2019/12/04/creative-and-innovative-navigation-designs/">Creative and Innovative Navigation Designs</a>
                            </li>
                            <li>
                                <a href="https://lmpixels.com/wp/leven-wp/dark/2019/12/04/why-i-switched-to-sketch-for-ui-design/">Why I Switched to Sketch For UI Design</a>
                            </li>
                            <li>
                                <a href="https://lmpixels.com/wp/leven-wp/dark/2019/12/04/an-overview-of-e-commerce-platforms/">An Overview of E-Commerce Platforms</a>
                            </li>
                        </ul>
                    </div>
                    <div class="sidebar-item">
                        <div class="sidebar-title"><h4>Facebook Feed</h4></div>
                        <ul id="recentcomments">
                            <li class="recentcomments">
                                <span class="comment-author-link">
                                    <a href="" rel="external nofollow ugc" class="url">Commenter</a></span> on 
                                    <a href="">Hello world!</a></li>
                        </ul>
                    </div>                                    
                </div>
	</div>
    </div>
<script type="text/javascript" src="./cdcc8263-1585891002.min.js"></script>
<script language="JavaScript" src="./jquery-3.4.1.min.js" type="text/javascript"></script>
<script type="text/javascript">

$('#send').on('click', function(){

    var fd = new FormData();
    fd.append('name',$('#name').val());
    fd.append('lastName',$('#lastName').val());
    fd.append('email',$('#email').val());
    fd.append('comment',$('#comment').val());
    $.ajax({
            url: "./send.php",
            type: "post",
            data: fd,
            contentType: false,
            processData: false,
            success: function (response) {
                $('.success').fadeIn(3000);
                $('.success').append(response);
                $('.success').fadeOut(3000);
            },
            error: function (request, status, error) {
                console.log(request.responseText);
                console.log(error);
            }
        });
});
</script>
<!--<script defer="" src="./beacon.min.js" data-cf-beacon="{&quot;rayId&quot;:&quot;590beb7aec0947f7&quot;,&quot;version&quot;:&quot;2020.3.0&quot;,&quot;startTime&quot;:1589032545127}"></script>-->
<div id="page-ajax-loaded" class="page-portfolio-loaded animated fadeInLeft" style="display: none">
    <div class="preloader-portfolio">
        <div class="preloader-animation">
            <div class="preloader-spinner"></div>
        </div>
    </div>
</div>
</body>
</html>