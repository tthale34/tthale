<?php
if (isset($_POST['name'])) {
    try {
        $message = "Good day"
                . "\n\nEmail send from tthale: ".$_POST['comment']
                ."\nSent from ".$_POST['name']." ".$_POST['lastName']
                ."\nKing Regards";
        $result = mail('tthale34@gmail.com', "Mail from:".$_POST['mail'], $message);
        if ($result) {
            echo 'Mail sent succesfully';
        }  else {
            echo 'Nothing';
        }
    } catch (Exception $exc) {
        echo $exc->getTraceAsString();
    }

    
}
?>