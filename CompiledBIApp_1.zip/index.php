
<!DOCTYPE html>
<?php
require 'config.php';
require 'DB.php';
session_start();
?>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>ThinkBI</title>
        <!-- Favicon-->
        <link rel="icon" type="image/png" href="assets/img/logo.png">
        <!-- Font Awesome icons (free version)-->
        <script src="https://use.fontawesome.com/releases/v5.13.0/js/all.js" crossorigin="anonymous"></script>
        <!-- Google fonts-->
        <link href="https://fonts.googleapis.com/css?family=Merriweather+Sans:400,700" rel="stylesheet" />
        <link href="https://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic" rel="stylesheet" type="text/css" />
        <!-- Third party plugin CSS-->
        <link href="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/magnific-popup.min.css" rel="stylesheet" />
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="./css/styles.css" rel="stylesheet"/>
        <link href="./css/jquery-ui.css" rel="stylesheet">
    </head>
    <body id="page-top">
        <!-- Navigation-->

        <nav class="navbar navbar-expand-lg navbar-light fixed-top py-3" id="mainNav">
            <div class="container">
                <a class="navbar-brand js-scroll-trigger" href="./">ZTQ Solutions</a>
                <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
                <?php if (isset($_SESSION['ID'])):
                    ?>
                    <div class="collapse navbar-collapse" id="navbarResponsive">
                        <ul class="navbar-nav ml-auto my-2 my-lg-0">
                            <li class="nav-item"><a class="nav-link js-scroll-trigger" href="./?page=dashboard">Dashboard</a></li>
                            <li class="nav-item"><a class="nav-link js-scroll-trigger" href="./?page=clients">Manage Client</a></li>
                            <!--<li class="nav-item"><a class="nav-link js-scroll-trigger" href="./?page=products">Manage Product</a></li>-->
                            <li class="nav-item"><a class="nav-link js-scroll-trigger" href="./?page=admin">Administrator</a></li>
                        </ul>
                    </div>
                <?php endif;
                ?>
            </div>
        </nav>
        <!-- Navigation-->
        <!-- Masthead-->
        <header class="masthead">
            <div class="container h-100">
                <div class="row h-100 align-items-center justify-content-center text-center">
                    
                    <?php
                    if (!isset($_SESSION['ID'])):
                        require './login.php';
                    elseif (isset($_SESSION['ID'])) :?>
                        <?php
                        if (isset($_GET['page']) && $_GET['page'] == "clients") {
                            require 'clients.php';
                        } elseif (isset($_GET['page']) && $_GET['page'] == "products") {
                            require 'products.php';
                        } elseif (isset($_GET['page']) && $_GET['page'] == "dashboard") {
                            require 'dashboard.php';
                        } elseif (isset($_GET['page']) && $_GET['page'] == "admin") {
                            require 'admin.php';
                        } elseif (isset($_GET['page']) && $_GET['page'] == "addClient") {
                            require 'addClient.php';
                        } elseif (isset($_GET['page']) && $_GET['page'] == "removeClient") {
                            require 'removeClient.php';
                        } elseif (isset($_GET['page']) && $_GET['page'] == "updateClient") {
                            require 'updateClient.php';
                        } elseif (isset($_GET['page']) && $_GET['page'] == "addComment") {
                            require 'clientComment.php';
                        } elseif (isset($_GET['page']) && $_GET['page'] == "viewAudit") {
                            require 'viewAudit.php';
                        } elseif (isset($_GET['page']) && $_GET['page'] == "addUser") {
                            require 'addUser.php';
                        } elseif (isset($_GET['page']) && $_GET['page'] == "updateUser") {
                            require 'updateUser.php';
                        } elseif (isset($_GET['page']) && $_GET['page'] == "deleteUser") {
                            require 'deleteUser.php';
                        }  else {
                            header("Refresh:1, Url=/?page=dashboard");
                        }
                    endif;
                    ?>

                </div>
            </div>
        </header>
        <!-- Footer-->
        <footer class="bg-light py-5">
            <div class="container"><div class="small text-center text-muted">Copyright © 2020 - ZTQ Solutions</div></div>
        </footer>

        <!-- Bootstrap core JS-->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.bundle.min.js"></script>
        <!-- Third party plugin JS-->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/jquery.magnific-popup.min.js"></script>
        <!-- Core theme JS-->
        <script src="js/scripts.js"></script>       
        <script type="text/javascript" src="js/jquery-3.4.1.min.js"></script>
        <script type="text/javascript" src="js/jquery-ui.min.js"></script>

        <script type="text/javascript">
            function setClientID(ID) {
                $('#setClientID').val(ID);
            }
            function setUserID(ID) {
                $('#setUserID').val(ID);
            }
            $('#addClient').on('click', function () {
                window.location.replace("http://" + document.location.host + "/?page=addClient");
            });
            $('#removeClient').on('click', function () {
                if($('#setClientID').val() === ""){
                    alert("Please select client you would like to delete.");
                }else{
                    window.location.replace("http://" + document.location.host + "/?page=removeClient&id="+$('#setClientID').val());
                }
            });
            $('#updateClient').on('click', function () {
                if($('#setClientID').val() === ""){
                    alert("Please select client you would like to update.");
                }else{
                    window.location.replace("http://" + document.location.host + "/?page=updateClient&id="+$('#setClientID').val());
                }
            });
            $('#addComment').on('click', function () {
                if($('#setClientID').val() === ""){
                    alert("Please select client you would like to add comment to.");
                }else{
                    window.location.replace("http://" + document.location.host + "/?page=addComment&id="+$('#setClientID').val());
                }
            });
            $('#viewAudit').on('click', function () {
                if($('#setClientID').val() === ""){
                    alert("Please select client you would like view audit log for.");
                }else{
                    window.location.replace("http://" + document.location.host + "/?page=viewAudit&id="+$('#setClientID').val());
                }
            });
//Popup link1 function for client actions, client update, client comment, client audit
            $("#clientUpdateDialog").dialog({
                width: 420,
                show: "slide",
                resizable: true,
                buttons: {
                    Update: function () {
                        $(this).dialog("close");
                    },
                    Close: function () {
                        $(this).dialog("close");
                    },
                },
                autoOpen: false,
            });
            $("#clientCommentDialog").dialog({
                width: 420,
                show: "slide",
                resizable: true,
                buttons: {
                    Update: function () {
                        alert($('#setClientID').val() + " : " + $('#cdCommentArea').val());
                        var fd = new FormData();
                        fd.append('clientID', $('#setClientID').val());
                        fd.append('comment', $('#cdCommentArea').val());
                        fd.append('submitType', "addComment");
                        $.ajax({
                            url: "./DB.php",
                            type: "post",
                            data: fd,
                            contentType: false,
                            processData: false,
                            success: function (response) {
                                if (response) {
                                    alert("Comment added sucessfully");
                                    $(this).dialog("close");
                                } else {
                                    alert(response);
                                }
                            },
                            error: function (request, status, error) {
                                if (error !== null) {
                                    $('.result_handler').show();
                                    $('.result_handler').text(error);
                                    $('.result_handler').delay(2000).fadeOut(2000);
                                }
                            }
                        });
                    },
                    Close: function () {
                        $(this).dialog("close");
                    },
                },
                autoOpen: false,
            });
            $("#clientAuditDialog").dialog({
                width: 720,
                show: "slide",
                resizable: true,
                buttons: {
                    Close: function () {
                        $(this).dialog("close");
                    },
                },
                autoOpen: false,
            });
            $("#userUpdateDialog").dialog({
                width: 400,
                show: "slide",
                resizable: true,
                buttons: {
                    
                    Add: function () {
                        window.location.replace("http://" + document.location.host + "/?page=addUser&id="+$('#setUserID').val());
                    },
                    Update: function () {
                        window.location.replace("http://" + document.location.host + "/?page=updateUser&id="+$('#setUserID').val());
                    },
                    Delete: function () {
                        window.location.replace("http://" + document.location.host + "/?page=deleteUser&id="+$('#setUserID').val());
                    },
                    Close: function () {
                        $(this).dialog("close");
                    },
                },
                autoOpen: false,
            });
            $("#addClientDialog").dialog({
                width: 400,
                show: "slide",
                resizable: true,
                buttons: {
                    Add: function () {
                        var fd = new FormData();
                        fd.append('name', $('#addCliName').val());
                        fd.append('surname', $('#addCliSur').val());
                        fd.append('company', $('#addCliCom').val());
                        fd.append('industry', $('#addCliInd').val());
                        fd.append('department', $('#addCliDep').val());
                        fd.append('email', $('#addCliEma').val());
                        fd.append('contact', $('#addCliCont').val());
                        fd.append('category', $('#addCliCat').val());
                        fd.append('lastdate', $('#addCliLast').val());
                        fd.append('comment', $('#addCliCom').val());
                        fd.append('submitType', "addClient");
                        $.ajax({
                            url: "./DB.php",
                            type: "post",
                            data: fd,
                            contentType: false,
                            processData: false,
                            success: function (response) {
                                if (response) {
                                    alert("Client created successfully");
                                    $('#addClientDialog').dialog("close");
                                } else {
                                    alert(response);
                                }
                            },
                            error: function (request, status, error) {
                                if (error !== null) {
                                    $('.result_handler').show();
                                    $('.result_handler').text(error);
                                    $('.result_handler').delay(2000).fadeOut(2000);
                                }
                            }
                        });
                    },
                    Close: function () {
                        $(this).dialog("close");
                    },
                },
                autoOpen: false,
            });
            $('#selectDialog').dialog({
                width: 300,
                show: "slide",
                resizable: true,
                buttons: {
                    Submit: function () {
                        //tested nad working fine
                        if ($('#selectFunction').val() === "comment") {
                            // $('#commentID').val($('#selectDialogInput').val());
                            // $(this).dialog("close");
                            // $('#clientCommentDialog').dialog('open');
                            alert('in comments');
                            $.post("./app_handler.php", {action: "addComment", id: $('#selectDialogInput').val()});
                        }
                        //Still need to set id to update client dialog, retrieve update information and submit update
                        if ($('#selectFunction').val() === "update") {
                            $(this).dialog("close");
                            $('#clientUpdateDialog').dialog('open');
                        }
                        //still trying to get record and push to next form
                        if ($('#selectFunction').val() === "audit") {
                            $(this).dialog("close");
                            $('#clientAuditDialog').dialog('open');

                            var fd = new FormData();
                            fd.append('userID', $('#setUserID').val());
                            fd.append('submitType', 'getAuditRecords');
                            $.ajax({
                                url: "./DB.php",
                                type: "post",
                                data: fd,
                                contentType: false,
                                processData: false,
                                success: function (response) {
                                    alert(response);
                                    $tmpEntryHolder = 0;
                                    for ($i = 0; $i < count($result); $i++) {
                                        print_r('<tr>');
                                        $j = 0;
                                        while ($j < count($result[0])) {
                                            print_r('<td class="client_col"><a>');
                                            print_r($result[$i][$tmpEntryHolder]);
                                            print_r('</a></td>');
                                            $j++;
                                            $tmpEntryHolder++;
                                        }
                                        print_r('</tr>');
                                    }

                                },
                                error: function (request, status, error) {
                                    if (error !== null) {
                                        $('.result_handler').show();
                                        $('.result_handler').text(error);
                                        $('.result_handler').delay(2000).fadeOut(2000);
                                    }
                                }
                            });

                        }
                        //this one is done and dusted
                        if ($('#selectFunction').val() === "delete") {
                            var fd = new FormData();
                            fd.append('userID', $('#setUserID').val());
                            fd.append('submitType', "deleteClient");
                            $.ajax({
                                url: "./DB.php",
                                type: "post",
                                data: fd,
                                contentType: false,
                                processData: false,
                                success: function (response) {
                                    if (response) {
                                        alert('Client successfully deleted');
                                        $(this).dialog("close");
                                    } else {
                                        alert(response);
                                    }
                                },
                                error: function (request, status, error) {
                                    if (error !== null) {
                                        $('.result_handler').show();
                                        $('.result_handler').text(error);
                                        $('.result_handler').delay(2000).fadeOut(2000);
                                    }
                                }
                            });
                        }
                        if ($('#selectFunction').val() === "addClient") {
                            $(this).dialog("close");
                            $('#addClientDialog').dialog('open');
                        }
                    },
                    Close: function () {
                        $(this).dialog("close");
                    },
                },
                autoOpen: false,
            });
//Below action happens when you set the ID check on the user table
            $('#userSelection').on('click', function () {
                $('#setUserID').val($('#userSelection').val());
            });
//Below action happens when you clik the client button
            $('#actionClient').on('click', function () {
                $('#selectDialogInput').val($('#setClientID').val());
                $('#selectDialog').dialog('open');
            });
//Below action happens when you clik the Administrator/user button
            $('#userUpdate').on('click', function (event) {
                if ($('#setUserID').val() === "") {
                    alert("Please check user before commencing with action");
                } else {
                    $('#userUpdateDialog').dialog('open');
                }
            });

        </script>

    </body>
</html>
