<?php

?>
<div class="forms">
    <?php
    if(isset($_SESSION['ID'])):
        ?><a class="logout" href="./app_handler.php/?action=logout">Logout</a>
    <?php endif;?>
    <div>
        <form action="./?page=addComment" method="post">
            <?php 
                if(isset($_GET['id'])){
                    $connection = DB::connectDB();
                    $result = DB::getClient($connection,$_GET['id']);
                    if($result):?>
                        <ul><h3>Add Comment to Client: <?php echo $result[0][0].' '.$result[0][1]?></h3>
                            <li class="add_client"><a><strong>Please enter client comment details below:</a></strong><br>
                            <textarea name="comment" cols="50" rows="5"></textarea>
                            </li>
                            <li class="add_client"><span><input type="submit"></span>
                            <span><input type="reset" value="Clear"></span></li>
                            <input type="hidden" name="clientid" value="<?php echo $_GET['id'];?>">
                        </ul>
                    <?php 
                    else:
                        echo 'Encountered error:<br>';
                        var_dump($result);
                    endif;
                }
                if(isset($_POST['comment'])){
                    $connection = DB::connectDB();
                    $result = DB::addComment($connection,$_POST['clientid'],$_POST['comment']);
                    if($result){
                        echo 'Comment has been added successfully.';
                        header("Refresh:4, Url=" . WEB_HOST."/?page=clients");
                    }else{
                        echo 'Encountered error:';
                        var_dump($result);
                    }
                }
            ?>        
            </form>
</div></div>