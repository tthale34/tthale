<?php ?>
<div class="forms">
    <?php
    if (isset($_SESSION['ID'])):
        ?><a class="logout" href="./app_handler.php/?action=logout">Logout</a>
    <?php endif; ?>
    <div>
        <?php
        if (isset($_GET['id'])):
            $connection = DB::connectDB();
            $result = DB::getAudits($connection, $_GET['id']);
            $client = DB::getClient($connection,$_GET['id']);
            ?><br><br>
            <a>Audit Log for client:<?php echo $client[0][0].' '.$client[0][1];?></a>
            <table border="5" style="border-radius: 5px;">
                <tr style="border-radius: 5px; color: black;">
                    <th class=""><a>Audit Type</a></th>
                    <th class=""><a>Previous Value</a></th>
                    <th class=""><a>New Value</a></th>
                    <th class=""><a>User Submitted</a></th>
                    <th class=""><a>Audit Date</a></th>
                </tr>
                <?php
                $tmpEntryHolder = 0;
                for ($i = 0; $i < count($result); $i++) {
                    print_r('<tr>');
                    $j = 0;
                    while ($j < count($result[0])) {
                        print_r('<td class="client_col"><a>');
                        print_r($result[$i][$tmpEntryHolder]);
                        print_r('</a></td>');
                        $j++;
                        $tmpEntryHolder++;
                    }
                    print_r('</tr>');
                }?>
            </table>
                <?php
            else:
                echo 'Encountered error:<br>';
                var_dump($result);
            endif;
            ?>        
    </div></div>