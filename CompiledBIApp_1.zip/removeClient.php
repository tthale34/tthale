<?php

?>
<div class="forms">
    <?php
    if(isset($_SESSION['ID'])):
        ?><a class="logout" href="./app_handler.php/?action=logout">Logout</a>
    <?php endif;?>
    <div>
        <form action="./?page=removeClient" method="post">
            <?php 
                if(isset($_GET['id'])){
//                    require 'config.php';
//                    require 'DB.php';
                    $connection = DB::connectDB();
                    $result = DB::deleteClient($connection,$_GET['id']);
                    if($result):
                        echo 'Client has been deleted succesfully';
                        header("Refresh:2, Url=". WEB_HOST . "/?page=clients");
                    else:
                        print_r('Error encountered: '.$result);
                    endif;
                }
            ?>
            </form>
</div></div>