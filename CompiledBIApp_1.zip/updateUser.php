<?php ?>
<div class="forms">
<?php
if (isset($_SESSION['ID'])):
    ?><a class="logout" href="./app_handler.php/?action=logout">Logout</a>
    <?php endif; ?>
    <div>
        <form action="./?page=updateUser" method="post">
<?php
if (isset($_GET['id'])) {
    $connection = DB::connectDB();
    $result = DB::getUser($connection, $_GET['id']);
    if ($result):
        ?>
                    <ul><h3>Update User Form</h3>
                        <li class="add_client"><a><strong>First Name:</strong></a><input class="" name="name" type="text" id="addCliName" value="<?php echo $result[0][0];?>"></li>
                        <li class="add_client"><a><strong>Last Name:</strong></a><input class="" name="surname" type="text" id="addCliSur" value="<?php echo $result[0][1];?>"></li>
                        <li class="add_client"><a><strong>Username:</strong></a><input class="" name="username" type="text" id="addCliCom" value="<?php echo $result[0][2];?>"></li>
                        <li class="add_client"><a><strong>Contact:</strong></a><input class="" name="contact" type="text" id="addCliCont" value="<?php echo $result[0][3];?>"></li>
                        <li class="add_client"><a><strong>Access Type:</strong></a><select class="" name="accessType" id="userAccessType" value="">
                                <option><?php echo $result[0][4];?></option>
                                <option>user</option>
                                <option>admin</option>
                            </select></li>
                        <li class="add_client"><a><strong>Status:</strong></a><select class="" name="status" id="userStatus" value="">
                                <option><?php echo $result[0][5];?></option>
                                <option>active</option>
                                <option>inactive</option>
                            </select></li>
                        <li class="add_client"><span><input type="submit"></span>
                            <input type="hidden" name="userid" value="<?php echo $_GET['id']; ?>">
                    </ul>
                    <?php
                else:
                    echo 'Encountered error:<br>';
                    var_dump($result);
                endif;
            }
            if (isset($_POST['userid'])) {
                $connection = DB::connectDB();
                $result = DB::updateUser($connection, $_POST['userid'], $_POST['name'], $_POST['surname'], $_POST['username'], $_POST['contact'], $_POST['accessType'], $_POST['status']);
                if ($result) {
                    echo 'Client information updated successfully';
                    header("Refresh:2, Url=/?page=admin");
                } else {
                    echo 'Encountered error:';
                    var_dump($result);
                }
            }
            ?>        
        </form>
    </div></div>