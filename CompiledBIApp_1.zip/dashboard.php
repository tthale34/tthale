<div class="forms">
    <?php
    if(isset($_SESSION['ID'])):
        ?><a class="logout" href="./app_handler.php/?action=logout">Logout</a>
    <?php endif;?>
    <span><a><strong>Select Report:</strong></a><select id="reportSelector"  class="my_btn">
                    <option>Category Report</option>
                    <option>Industry Report</option>
                    <option>Department Report</option>                    
        </select></span>
    <div id="reportHolder"><img src="assets/img/canvas1.JPG" id="img_src"  style="border-radius:10px;"></div>
</div>