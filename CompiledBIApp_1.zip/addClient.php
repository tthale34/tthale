<?php

?>
<div class="forms">
    
    <div>
        <form action="./?page=addClient" method="post">
            <?php 
                if(isset($_POST['name'])){
//                    require 'config.php';
//                    require 'DB.php';
                    $connection = DB::connectDB();
                    $result = DB::addClient($connection,$_POST['name'],$_POST['surname'],$_POST['company'],$_POST['industry'],$_POST['department'],$_POST['email'],$_POST['contact'],$_POST['category']);
                    if($result){
                        echo 'Client has been created successfully';
                    }else{
                        print_r('Error encountered: '.$result);
                    }
                }
            ?>
        <ul><h3>Add New Client Form</h3>
        <li class="add_client"><a><strong>First Name:</a></strong><input class="" name="name" type="text" id="addCliName" value=""></li>
        <li class="add_client"><a><strong>Last Name:</a></strong><input class="" name="surname" type="text" id="addCliSur" value=""></li>
        <li class="add_client"><a><strong>Company:</a></strong><input class="" name="company" type="text" id="addCliCom" value=""></li>
        <li class="add_client"><a><strong>Industry:</a></strong><input class="" name="industry" type="text" id="addCliInd" value=""></li>
        <li class="add_client"><a><strong>Department:</a></strong><input class="" name="department" type="text" id="addCliDep" value=""></li>
        <li class="add_client"><a><strong>Email Address:</a></strong><input class="" name="email" type="text" id="addCliEma" value=""></li>
        <li class="add_client"><a><strong>Contact:</a></strong><input class="" name="contact" type="text" id="addCliCont" value=""></li>
        <li class="add_client"><a><strong>Category:</a></strong><input class="" name="category" type="text" id="addCliCat" value=""></li>
        <li class="add_client"><span><input type="submit"></span>
            <span><input type="reset" value="Clear"></span></li>
    </ul>
            </form>
</div></div>