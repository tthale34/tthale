<?php
/** The name of the database $conn = oci_connect("username","pwd", "123.123.123.123:1521/foo");*/
define( 'DB_NAME', 'thale' );

/** MySQL database username */
define( 'DB_USER', 'thale' );

/** MySQL database password */
define( 'DB_PASSWORD', '' );

/** oracle hostname */
define( 'DB_HOST', 'localhost' );
/** Web hostname */
define( 'WEB_HOST', 'http://'.$_SERVER['HTTP_HOST'].'/thinkbi');