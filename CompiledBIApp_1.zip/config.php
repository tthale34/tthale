<?php
/** The name of the database $conn = oci_connect("username","pwd", "123.123.123.123:1521/foo");*/
define( 'DB_STRING', '10.0.0.6:1521/orcl' );

/** oracle database username */
define( 'DB_USER', 'bi_app' );

/** oracle database password */
define( 'DB_PASSWORD', 'ZTQpass_1' );

/** oracle hostname */
define( 'DB_HOST', 'localhost' );
/** Web hostname */
define( 'WEB_HOST', 'http://'.$_SERVER['HTTP_HOST']);