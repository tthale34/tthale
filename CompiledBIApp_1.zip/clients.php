<div class="forms">
    <?php
    if (isset($_SESSION['ID'])):
        ?><a class="logout" href="./app_handler.php/?action=logout">Logout</a>
    <?php endif; ?>
    <div class="result" style="display:none">Success:</div>
    <div>
        <!-- <input type="button" name="update" class="my_selectDialogbtn btn-outline-blue btn-lg cbtn" value="Perform client action" id="actionClient"/> -->
        <input type="button" name="add" class="my_selectDialogbtn btn-outline-blue btn-lg cbtn" value="Add Client" id="addClient"/>
        <input type="button" name="remove" class="my_selectDialogbtn btn-outline-blue btn-lg cbtn" value="Remove Client" id="removeClient"/>
        <input type="button" name="update" class="my_selectDialogbtn btn-outline-blue btn-lg cbtn" value="Update Client" id="updateClient"/>
        <input type="button" name="comment" class="my_selectDialogbtn btn-outline-blue btn-lg cbtn" value="Add Comment" id="addComment"/>
        <input type="button" name="audits" class="my_selectDialogbtn btn-outline-blue btn-lg cbtn" value="View Audit" id="viewAudit"/>
        <input type="hidden" id="setClientID" value=""/>
    </div>
    <div class="client_table">
        <table border="5" style="border-radius: 5px;">
            <tr style="border-radius: 5px; color: black;">
                <th class=""><a>ID</a></th>
                <th class="" style="padding:5px;border-radius: 5px;"><a>Status</a></th>
                <th class=""><a>Company</a></th>
                <th class=""><a>Industry</a></th>
                <th class=""><a>Department</a></th>
                <th class=""><a>Name</a></th>
                <th class=""><a>Surname</a></th>
                <th class=""><a>Email</a></th>
                <th class=""><a>Contact</a></th>
                <th class=""><a>Category</a></th>
                <th class=""><a>Last Date</a></th>
                <th class=""><a>Comments</a></th>
            </tr>        
            <?php
            $connection = DB::connectDB();
            $result = DB::getClients($connection);
            $tmpEntryHolder = 0;
            for ($i = 0; $i < count($result); $i++) {
                print_r('<tr>');
                $j = 0;
                while ($j < count($result[0])) {
                    if ($j == 0) {
                        print_r('<td class=""><a><input name="clients" type="radio" onclick="setClientID(' . $result[$i][$tmpEntryHolder] . ')"></a></td>');
                    } else {
                        print_r('<td class="client_col"><a>');
                        print_r($result[$i][$tmpEntryHolder]);
                        print_r('</a></td>');
                    }
                    $j++;
                    $tmpEntryHolder++;
                }
                print_r('</tr>');
            }
            ?>
        </table>
    </div>

    <!--Client Update Dialog-->
    <div id="clientUpdateDialog" title="Client Update Dialog">
        <span><a class="blue-text"><strong>Status: </strong><input class="inputs cinputs" type="text" id="cdstatus" value=""></a></span><br><br>
        <span><a class="blue-text"><strong>Industry: </strong><input class="inputs cinputs" type="text" id="cdindustry" value=""></a></span><br><br>
        <span><a class="blue-text"><strong>Department: </strong><input class="inputs cinputs" type="text" id="cddepartment" value=""></a></span><br><br>
        <span><a class="blue-text"><strong>Name: </strong><input class="inputs cinputs" type="text" id="cdname" value=""></a></span><br><br>
        <span><a class="blue-text"><strong>Surname: </strong><input class="inputs cinputs" type="text" id="cdsurname" value=""></a></span><br><br>
        <span><a class="blue-text"><strong>Email: </strong><input class="inputs cinputs" type="text" id="cdemail" value=""></a></span><br><br>
        <span><a class="blue-text"><strong>Contacts: </strong><input class="inputs cinputs" type="text" id="cdcontact" value=""></a></span><br><br>
        <span><a class="blue-text"><strong>Comment: </strong><input class="inputs cinputs" type="text" id="cdcomment" value=""></a></span><br><br>
        <span><a class="blue-text"><strong>Category: </strong><input class="inputs cinputs" type="text" id="cdcat" value=""></a></span><br><br>
        <span><a class="blue-text"><strong>Last Date: </strong><input class="inputs cinputs" type="text" id="cddate" value=""></a></span>
    </div>
    <!--Client Comment Dialog    -->
    <div id="clientCommentDialog" title="Client Comment Dialog">
        <span><strong>Please enter any new information received from the client: </strong></span><br><br>
        <span><a class="blue-text"><textarea class="inputs cinputs" type="text" id="cdCommentArea" value=""></textarea></a></span><br><br>
        <input type="hidden" value="" id="clientID">
    </div>
    <!-- End Of Client Comment Dialog    -->
    <!-- Client audit dialog -->
    <div id="clientAuditDialog" title="Client Audit Dialog">
        <!-- Audit Table Header -->
        <table border="5" style="border-radius: 5px;" id="auditTable">
            <tr style="border-radius: 5px; color: black;">
                <th><a class="audit_header">Audit Type </a></th>
                <th><a class="audit_header">Previous Value </a></th>
                <th><a class="audit_header">Post Value </a></th> 
                <th><a class="audit_header">Updated User</a></th>
                <th><a class="audit_header">Date Updated</a></th></tr>
            <!-- Audit Results -->
            <tr><td><a class="audentComment" id="clientAuditComment" value="">Comment </a></td>
                <td><a class="audit_entry">No Value </a></td>
                <td><a class="audit_entry">Awaiting Client</a></td>
                <td><a class="audit_entry">Tebogo</a></td>
                <td><a class="audit_entry">19/11/2020</a></td></tr>
        </table>
    </div>
    <!-- End of Client audit dialog -->
    <!-- Add Client -->
    <div id="addClientDialog" title="Add Client Dialog">
        <table border="5" style="border-radius: 5px;" id="auditTable">
            <tr style="border-radius: 5px; color: black;">
            <li class="userDialog"><a><strong>First Name:</a></strong><input class="" type="text" id="addCliName" value=""></li>
            <li class="userDialog"><a><strong>Last Name:</a></strong><input class="" type="text" id="addCliSur" value=""></li>
            <li class="userDialog"><a><strong>Company:</a></strong><input class="" type="text" id="addCliCom" value=""></li>
            <li class="userDialog"><a><strong>Industry:</a></strong><input class="" type="text" id="addCliInd" value=""></li>
            <li class="userDialog"><a><strong>Department:</a></strong><input class="" type="text" id="addCliDep" value=""></li>
            <li class="userDialog"><a><strong>Email Address:</a></strong><input class="" type="text" id="addCliEma" value=""></li>
            <li class="userDialog"><a><strong>Contact:</a></strong><input class="" type="text" id="addCliCont" value=""></li>
            <li class="userDialog"><a><strong>Category:</a></strong><input class="" type="text" id="addCliCat" value=""></li>
            <li class="userDialog"><a><strong>Last Date:</a></strong><input class="" type="text" id="addCliLas" value=""></li>
            <li class="userDialog"><a><strong>Comment:</a></strong><input class="" type="text" id="addCliComm" value=""></li>
            </tr>
        </table>
    </div>
    <!-- End Add Client -->
    <!-- Select dialog -->
    <div id="selectDialog" title="Select dialog">
        <span><strong>Please select action: </strong></span><br><br>
        <span><a class="blue-text"><select name="selectFunction" id="selectFunction">
                    <option value=""></option>
                    <option value="addClient">Add Client</option>
                    <option value="comment">Add Comment</option>
                    <option value="audit">View Audit Log</option>
                    <option value="update">Update Client</option>
                    <option value="delete">Delete Client</option>
                </select>
            </a></span><br><br>
        <span>ID:<input type="text" value="12" id="selectDialogInput" readonly></span><br>
    </div>
    <!--    End of Selection Dialog-->
</div>