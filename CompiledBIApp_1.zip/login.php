<!--Login form-->

<div class="forms">
    <?php if (isset($_GET['login']) && $_GET['login'] == 0): ?>
        <h5><a class="red-text"><strong>No users found matching entered credentials.</strong></a></h5>
    <?php elseif (isset($_GET['login']) && $_GET['login'] == 1): ?>
        <h5><a class="green"><strong>Login successful.</strong></a></h5>';
    <?php endif; ?>
    <form action="./app_handler.php" method="post">
        <span><a class="blue-text"><strong>Username: </strong><input class="inputs" type="text" name="username" value=""></a><br><br></span>
        <span><a class="blue-text"><strong>Password: </strong><input class="inputs" type="password" name="password" value=""></a><br><br></span>
        <input type="submit" name="submit" class="btn" value="Login" id="submitLogin">
        <input type="reset" name="clear" class="btn" value="Clear">
        <input type="hidden" name="submitType" value="login">
    </form>
</div>

<!--/Login form-->