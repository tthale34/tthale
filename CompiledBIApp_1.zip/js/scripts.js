
(function($) {
  "use strict"; // Start of use strict

  // Smooth scrolling using jQuery easing
  $('a.js-scroll-trigger[href*="#"]:not([href="#"])').click(function() {
    if (location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '') && location.hostname == this.hostname) {
      var target = $(this.hash);
      target = target.length ? target : $('[name=' + this.hash.slice(1) + ']');
      if (target.length) {
        $('html, body').animate({
          scrollTop: (target.offset().top - 72)
        }, 1000, "easeInOutExpo");
        return false;
      }
    }
  });

  // Closes responsive menu when a scroll trigger link is clicked
  $('.js-scroll-trigger').click(function() {
    $('.navbar-collapse').collapse('hide');
  });

  // Activate scrollspy to add active class to navbar items on scroll
  $('body').scrollspy({
    target: '#mainNav',
    offset: 75
  });

  // Collapse Navbar
  var navbarCollapse = function() {
    if ($("#mainNav").offset().top > 100) {
      $("#mainNav").addClass("navbar-scrolled");
    } else {
      $("#mainNav").removeClass("navbar-scrolled");
    }
  };
  // Collapse now if page is not at top
  navbarCollapse();
  // Collapse the navbar when page is scrolled
  $(window).scroll(navbarCollapse);

  // Magnific popup calls
  $('#portfolio').magnificPopup({
    delegate: 'a',
    type: 'image',
    tLoading: 'Loading image #%curr%...',
    mainClass: 'mfp-img-mobile',
    gallery: {
      enabled: true,
      navigateByImgClick: true,
      preload: [0, 1]
    },
    image: {
      tError: '<a href="%url%">The image #%curr%</a> could not be loaded.'
    }
  });
  //Submit login funtion
  $('#submitLogin').on('click',function (event){
    if($('#username').val() == ""){
        $('.result_handler').show();
        $('.result_handler').text("Please fill in the First Name field.");
        $('.result_handler').delay(2000).fadeOut(2000);
        return;
    }
    if($('#password').val() == ""){
        $('.result_handler').show();
        $('.result_handler').text("Please fill in the Last Name field.");
        $('.result_handler').delay(20000).fadeOut(20000);
        return;
    }
    var fd = new FormData();
    fd.append('username',$('#username').val());
    fd.append('password',$('#password').val());
    fd.append('submitType',"validateLogin");
    $.ajax({
        url: "./app_handler.php",
        type: "post",
        data: fd,
        contentType: false,
        processData: false,
        success: function(response) {
              $('.result_handler').show();              
              $('.result_handler').text(response);
              $('.result_handler').delay(20000).fadeOut(20000);
        },
        error: function (request, status, error) {
          if(error !== null){
            $('.result_handler').show();
            $('.result_handler').text(error);
            $('.result_handler').delay(2000).fadeOut(2000);
          }
        }
    });
});
//end of submit login
$('#reportSelector').on('change', function(){
    var src="";
    if($('#reportSelector').val() === "Category Report"){
        src="assets/img/canvas1.JPG";
    }
    if($('#reportSelector').val() === "Industry Report"){
        src="assets/img/canvas2.JPG";
    }
    if($('#reportSelector').val() === "Department Report"){
        src="assets/img/canvas3.JPG";
    }
    $('#img_src').fadeOut(2000,function(){
        $('#img_src').attr('src',src);
        $('#img_src').fadeIn(2000);
    });
});
$('.forms').fadeIn(2000);
$('.forms').on('load',function(){
    $('.forms').fadeIn(2000);
});
 
})(jQuery); // End of use strict
