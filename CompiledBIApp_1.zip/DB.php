<?php

if (isset($_POST['submitType']) && $_POST['submitType'] == "getAuditRecords") {
    require 'config.php';
    $connection = oci_connect(DB_USER, DB_PASSWORD, DB_STRING);
    $stid = oci_parse($connection, "SELECT AUDIT_TYPE,PREVIOUS_VALUE,CURRENT_VALUE,USER_SUBMIT,DATE_SUBMITTED FROM AUDITS WHERE CLIENTID = '" . $_POST['userID'] . "'");
    $exec = oci_execute($stid, OCI_DEFAULT);
    if ($exec) {
        $i = 0;
        $j = 0;
        $result = array();
        while ($row = oci_fetch_array($stid, OCI_ASSOC + OCI_RETURN_NULLS)) {
            foreach ($row as $item) {
                //$clients[$i] = array();
                $result[$i][$j] = $item;
                $j++;
            }
            $i++;
        }
    } else {
        $result = oci_error($statement, OCI_RETURN_NULLS + OCI_ASSOC);
        trigger_error(htmlentities($result['message'], ENT_QUOTES), E_USER_ERROR);
    }
    oci_close($connection);
    return $result;
}
if (isset($_POST['submitType']) && $_POST['submitType'] == "getUser") {
    require 'config.php';
    $connection = oci_connect(DB_USER, DB_PASSWORD, DB_STRING);
    $stid = oci_parse($connection, "select FIRSTNAME,LASTNAME,CONTACT_NUMBER,USERNAME,STATUS,ACCESSTYPE from BI_USERS where userid = " . $_POST['userID']);
    $exec = oci_execute($stid);
    if ($exec) {
        $result = oci_fetch_array($stid, OCI_RETURN_NULLS + OCI_ASSOC);
    } else {
        $result = oci_error($statement, OCI_RETURN_NULLS + OCI_ASSOC);
        trigger_error(htmlentities($result['message'], ENT_QUOTES), E_USER_ERROR);
    }
    return $result;
}
if (isset($_POST['submitType']) && $_POST['submitType'] == "addUser") {
    require 'config.php';
    $connection = oci_connect(DB_USER, DB_PASSWORD, DB_STRING);
    $stid = oci_parse($connection, "INSERT INTO BI_USERS (FIRSTNAME,LASTNAME,CONTACT_NUMBER,USERNAME,STATUS,ACCESSTYPE) VALUES "
            . "('" . $_POST['ufname'] . "','" . $_POST['ulname'] . "','" . $_POST['unumber'] . "','" . $_POST['uusername'] . "','" . $_POST['ustatus'] . "','" . $_POST['uaccess'] . "')");
    $exec = oci_execute($stid);
    if ($exec) {
        return true;
    } else {
        $result = oci_error($stid, OCI_RETURN_NULLS + OCI_ASSOC);
        trigger_error(htmlentities($result['message'], ENT_QUOTES), E_USER_ERROR);
    }
    return $result;
}
if (isset($_POST['submitType']) && $_POST['submitType'] == "addClient") {
    require 'config.php';
    $connection = oci_connect(DB_USER, DB_PASSWORD, DB_STRING);
    $stid = oci_parse($connection, "INSERT INTO CLIENT_ (CLIENTNAME,CLIENTLASTNAME,COMPANY,INDUSTRY,DEPARTMENT,EMAILADDRESS,CONTACTDETAILS,CATEGORY_,DATE_ ,COMMENTS) VALUES "
            . "('" . $_POST['name'] . "','" . $_POST['surname'] . "','" . $_POST['company'] . "','" . $_POST['industry'] . "','" . $_POST['department'] . "',"
            . "'" . $_POST['email'] . "','" . $_POST['contact'] . "','" . $_POST['category'] . "','" . $_POST['lastdate'] . "','" . $_POST['comment'] . "');");
    $exec = oci_execute($stid, OCI_DEFAULT);
    if ($exec) {
        $exec = oci_commit($connection);
        oci_free_statement($stid);
        oci_close($connection);
        return true;
    } else {
        $result = oci_error($stid, OCI_RETURN_NULLS + OCI_ASSOC);
        trigger_error(htmlentities($result['message'], ENT_QUOTES), E_USER_ERROR);
    }
    return $result;
}
if (isset($_POST['submitType']) && $_POST['submitType'] == "updateUser") {
    require 'config.php';
    $connection = oci_connect(DB_USER, DB_PASSWORD, DB_STRING);
    $stid = oci_parse($connection, "UPDATE BI_USERS SET (FIRSTNAME,LASTNAME,CONTACT_NUMBER,USERNAME,STATUS,ACCESSTYPE) VALUES "
            . "('" . $_POST['ufname'] . "','" . $_POST['ulname'] . "','" . $_POST['unumber'] . "','" . $_POST['uusername'] . "','" . $_POST['ustatus'] . "','" . $_POST['uaccess'] . "') WHERE USERID = " . $_POST['userID'] . ";");
    $exec = oci_execute($stid);
    if ($exec) {
        return true;
    } else {
        $result = oci_error($stid, OCI_RETURN_NULLS + OCI_ASSOC);
        trigger_error(htmlentities($result['message'], ENT_QUOTES), E_USER_ERROR);
    }
    return $result;
}
if (isset($_POST['submitType']) && $_POST['submitType'] == "deleteUser") {
    require 'config.php';
    $connection = oci_connect(DB_USER, DB_PASSWORD, DB_STRING);
    $stid = oci_parse($connection, "DELETE FROM BI_USERS WHERE USERID = '" . $_POST['userID'] . "';");
    $exec = oci_execute($stid);
    if ($exec) {
        $exec = oci_commit($connection);
        oci_free_statement($stid);
        oci_close($connection);
        return true;
    } else {
        $result = oci_error($stid, OCI_RETURN_NULLS + OCI_ASSOC);
        trigger_error(htmlentities($result['message'], ENT_QUOTES), E_USER_ERROR);
    }
    return $result;
}
if (isset($_POST['submitType']) && $_POST['submitType'] == "deleteClient") {
    require 'config.php';
    $connection = oci_connect(DB_USER, DB_PASSWORD, DB_STRING);
    $stid = oci_parse($connection, "DELETE FROM CLIENT_ WHERE ID = '" . $_POST['userID'] . "';");
    $exec = oci_execute($stid);
    if ($exec) {
        return true;
    } else {
        $result = oci_error($stid, OCI_RETURN_NULLS + OCI_ASSOC);
        trigger_error(htmlentities($result['message'], ENT_QUOTES), E_USER_ERROR);
    }
    return $result;
}
if (isset($_POST['submitType']) && $_POST['submitType'] == "auditTable") {
    require 'config.php';
    $connection = oci_connect(DB_USER, DB_PASSWORD, DB_STRING);
    $stid = oci_parse($connection, "Select * from audit");
    oci_execute($stid);
    $i = 0;
    $j = 0;
    $clients = array();
    while ($row = oci_fetch_array($stid, OCI_ASSOC + OCI_RETURN_NULLS)) {
        foreach ($row as $item) {
            //$clients[$i] = array();
            $clients[$i][$j] = $item;
            $j++;
        }
        $i++;
    }
    oci_close($connection);
    return $clients;
}
if (isset($_POST['submitType']) && $_POST['submitType'] == "addComment") {
    require 'config.php';
    $connection = oci_connect(DB_USER, DB_PASSWORD, DB_STRING);
    $stid = oci_parse($connection, "INSERT INTO AUDITS (AUDIT_TYPE,CURRENT_VALUE,USER_SUBMIT,DATE_SUBMITTED,CLIENTID) VALUES ('Comment','" . $_POST['comment'] . "','System','sysdate','" . $_POST['clientID'] . "')");
    $exec = oci_execute($stid);
    if ($exec) {
        return true;
    } else {
        $result = oci_error($stid, OCI_RETURN_NULLS + OCI_ASSOC);
        trigger_error(htmlentities($result['message'], ENT_QUOTES), E_USER_ERROR);
    }
    return $result;
}

class DB {

    public static function connectDB() {
        // Create connection
        $connection = oci_connect(DB_USER, DB_PASSWORD, DB_STRING);
        // Check connection
        if ($connection) {
            //echo 'connection sucessful...';
            return $connection;
        } else {
            $e = oci_error();
            trigger_error(htmlentities($e['message'], ENT_QUOTES), E_USER_ERROR);
        }
        return $connection;
    }

    public static function closeConnection($connection) {
        oci_close($connection);
    }

    public static function addClient($connection, $name, $surname, $company, $industry, $department, $email, $contact, $category) {
        //$connection = oci_connect(DB_USER,DB_PASSWORD, DB_STRING);
        $stid = oci_parse($connection, "INSERT INTO CLIENT_ (CLIENTNAME,CLIENTLASTNAME,COMPANY,INDUSTRY,DEPARTMENT,EMAILADDRESS,CONTACTDETAILS,CATEGORY_,COMMENTS) VALUES "
                . "('" . $name . "','" . $surname . "','" . $company . "','" . $industry . "','" . $department . "','" . $email . "','" . $contact . "','" . $category . "','New Client')");
        $exec = oci_execute($stid);
        if ($exec) {
            $exec = oci_commit($connection);
            oci_free_statement($stid);
            oci_close($connection);
            $result = true;
        } else {
            $result = oci_error($stid, OCI_RETURN_NULLS + OCI_ASSOC);
            trigger_error(htmlentities($result['message'], ENT_QUOTES), E_USER_ERROR);
        }
        return $result;
    }
    public static function addUser($connection, $username, $name, $surname, $contact, $accessType, $status) {
        $stid = oci_parse($connection, "INSERT INTO BI_USERS (USERNAME,FIRSTNAME,LASTNAME,CONTACT_NUMBER,ACCESSTYPE,STATUS) VALUES "
                . "('" . $username . "','" . $name . "','" . $surname . "','" . $contact . "','" . $accessType . "','" . $status . "')");
        $exec = oci_execute($stid);
        if ($exec) {
            $exec = oci_commit($connection);
            oci_free_statement($stid);
            oci_close($connection);
            $result = true;
        } else {
            $result = oci_error($stid, OCI_RETURN_NULLS + OCI_ASSOC);
            trigger_error(htmlentities($result['message'], ENT_QUOTES), E_USER_ERROR);
        }
        return $result;
    }
    public static function addComment($connection, $id, $comment) {
//        $connection = oci_connect(DB_USER,DB_PASSWORD, DB_STRING);
        $stid = oci_parse($connection, "INSERT INTO AUDITS (AUDIT_TYPE,CURRENT_VALUE,USER_SUBMIT,DATE_SUBMITTED,CLIENTID) VALUES ('Comment','" . $comment . "','" . $_SESSION['name'] . " " . $_SESSION['surname'] . "',sysdate,'" . $id . "')");
        $exec = oci_execute($stid);
        if ($exec) {
            $exec = oci_commit($connection);
            oci_free_statement($stid);
            oci_close($connection);
            $result = true;
        } else {
            $result = oci_error($stid, OCI_RETURN_NULLS + OCI_ASSOC);
            trigger_error(htmlentities($result['message'], ENT_QUOTES), E_USER_ERROR);
        }
        return $result;
    }

    public static function deleteClient($connection, $id) {
        $stid = oci_parse($connection, "DELETE FROM CLIENT_ WHERE ID =" . $id);
        $exec = oci_execute($stid);
        if ($exec) {
            $exec = oci_commit($connection);
            oci_free_statement($stid);
            oci_close($connection);
            $result = true;
        } else {
            $result = oci_error($stid, OCI_RETURN_NULLS + OCI_ASSOC);
            trigger_error(htmlentities($result['message'], ENT_QUOTES), E_USER_ERROR);
        }
        return $result;
    }
    public static function deleteUser($connection, $id) {
        $stid = oci_parse($connection, "DELETE FROM BI_USERS WHERE USERID =" . $id);
        $exec = oci_execute($stid);
        if ($exec) {
            $exec = oci_commit($connection);
            oci_free_statement($stid);
            oci_close($connection);
            $result = true;
        } else {
            $result = oci_error($stid, OCI_RETURN_NULLS + OCI_ASSOC);
            trigger_error(htmlentities($result['message'], ENT_QUOTES), E_USER_ERROR);
        }
        return $result;
    }

    public static function updateClient($connection, $id, $name, $surname, $company, $industry, $department, $email, $contact, $category, $status) {
        $stid = oci_parse($connection, "UPDATE CLIENT_ SET CLIENTNAME='" . $name . "',CLIENTLASTNAME='" . $surname . "',COMPANY='" . $company . "',INDUSTRY='" . $industry . "',DEPARTMENT='" . $department . "',EMAILADDRESS='" . $email . "',CONTACTDETAILS='" . $contact . "',CATEGORY_='" . $category . "',STATUS='" . $status . "' WHERE ID = '" . $id . "'");
        $exec = oci_execute($stid);
        if ($exec) {
            $exec = oci_commit($connection);
            oci_free_statement($stid);
            $stid = oci_parse($connection, "INSERT INTO AUDITS (AUDIT_TYPE,CURRENT_VALUE,USER_SUBMIT,DATE_SUBMITTED,CLIENTID) VALUES ('Client Update','" . $comment . "','" . $_SESSION['name'] . " " . $_SESSION['surname'] . "',sysdate,'" . $id . "')");
            $exec = oci_execute($stid);
            if ($exec) {
                $exec = oci_commit($connection);
                oci_free_statement($stid);
                oci_close($connection);
                $result = true;
            }
        } else {
            $result = oci_error($stid, OCI_RETURN_NULLS + OCI_ASSOC);
            trigger_error(htmlentities($result['message'], ENT_QUOTES), E_USER_ERROR);
        }
        return $result;
    }
    public static function updateUser($connection, $id, $name, $surname, $username, $contact, $accessType, $status) {
        $stid = oci_parse($connection, "UPDATE BI_USERS SET FIRSTNAME='" . $name . "',LASTNAME='" . $surname . "',USERNAME='" . $username . "',CONTACT_NUMBER='" . $contact . "',ACCESSTYPE='" . $accessType . "',STATUS='" . $status . "' WHERE USERID = '" . $id . "'");
        $exec = oci_execute($stid);
        if ($exec) {
            $exec = oci_commit($connection);
            oci_free_statement($stid);
            oci_close($connection);
            $result =true;
        } else {
            $result = oci_error($stid, OCI_RETURN_NULLS + OCI_ASSOC);
            trigger_error(htmlentities($result['message'], ENT_QUOTES), E_USER_ERROR);
        }
        return $result;
    }
    public static function login($connection, $username, $pass) {
        $my_query = "SELECT FIRSTNAME,LASTNAME,USERNAME FROM BI_USERS WHERE USERNAME = '" . $username . "' AND PASSWORD = '" . $pass . "'";
        $statement = oci_parse($connection, $my_query);
        $exec = oci_execute($statement);
        if ($exec) {
            $result = oci_fetch_array($statement, OCI_RETURN_NULLS + OCI_ASSOC);
        } else {
            $result = oci_error($statement, OCI_RETURN_NULLS + OCI_ASSOC);
            trigger_error(htmlentities($result['message'], ENT_QUOTES), E_USER_ERROR);
        }
        return $result;
    }

    public static function getClients($connection) {
        $stid = oci_parse($connection, "Select * from client_");
        oci_execute($stid);
        $i = 0;
        $j = 0;
        $clients = array();
        while ($row = oci_fetch_array($stid, OCI_ASSOC + OCI_RETURN_NULLS)) {
            foreach ($row as $item) {
                //$clients[$i] = array();
                $clients[$i][$j] = $item;
                $j++;
            }
            $i++;
        }
        oci_close($connection);
        return $clients;
    }

    public static function getClient($connection, $id) {
        $stid = oci_parse($connection, "Select CLIENTNAME,clientlastname,company,industry,department,emailaddress,contactdetails,category_,status from client_ where id = " . $id);
        oci_execute($stid);
        $i = 0;
        $j = 0;
        $clients = array();
        while ($row = oci_fetch_array($stid, OCI_ASSOC + OCI_RETURN_NULLS)) {
            foreach ($row as $item) {
                //$clients[$i] = array();
                $clients[$i][$j] = $item;
                $j++;
            }
            $i++;
        }
        oci_close($connection);
        return $clients;
    }

    public static function getUsers($connection) {
        $stid = oci_parse($connection, "Select userid,firstname,lastname,username,contact_number,accesstype,status from bi_users");
        oci_execute($stid);
        $i = 0;
        $j = 0;
        $clients = array();
        while ($row = oci_fetch_array($stid, OCI_ASSOC + OCI_RETURN_NULLS)) {
            foreach ($row as $item) {
                //$clients[$i] = array();
                $clients[$i][$j] = $item;
                $j++;
            }
            $i++;
        }
        oci_close($connection);
        return $clients;
    }

    public static function getUser($connection, $id) {
        $stid = oci_parse($connection, "SELECT FIRSTNAME,LASTNAME,USERNAME,CONTACT_NUMBER,ACCESSTYPE,STATUS FROM BI_USERS WHERE USERID=" . $id);
        oci_execute($stid);
        $i = 0;
        $j = 0;
        $clients = array();
        while ($row = oci_fetch_array($stid, OCI_ASSOC + OCI_RETURN_NULLS)) {
            foreach ($row as $item) {
                //$clients[$i] = array();
                $clients[$i][$j] = $item;
                $j++;
            }
            $i++;
        }
        oci_close($connection);
        return $clients;
    }

    public static function getAudits($connection, $id) {
        $stid = oci_parse($connection, "SELECT AUDIT_TYPE,PREVIOUS_VALUE,CURRENT_VALUE,USER_SUBMIT,DATE_SUBMITTED FROM AUDITS WHERE CLIENTID = '" . $id . "'");
        $exec = oci_execute($stid);
        if ($exec) {
            $i = 0;
            $j = 0;
            $result = array();
            while ($row = oci_fetch_array($stid, OCI_ASSOC + OCI_RETURN_NULLS)) {
                foreach ($row as $item) {
                    //$clients[$i] = array();
                    $result[$i][$j] = $item;
                    $j++;
                }
                $i++;
            }
        } else {
            $result = oci_error($statement, OCI_RETURN_NULLS + OCI_ASSOC);
            trigger_error(htmlentities($result['message'], ENT_QUOTES), E_USER_ERROR);
        }
        oci_close($connection);
        return $result;
    }

}
