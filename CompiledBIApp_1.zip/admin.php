<div class="forms">
    <input class="my_btn" type="button" value="Add / Update / Delete User" id="userUpdate"/>
<!--    <input class="my_btn" type="button" value="Execute SQL Query" id="exeSqlQuery"/><br><br>-->
    <div class="user_holder">
        <table border="5" style="border-radius: 5px;">
            <tr style="border-radius: 5px; color: black;">
                <th><a></a></th>
            <th><a><strong>First Name</strong></a></th>
            <th><a><strong>Last Name</strong></a></th>
            <th><a><strong>Username</strong></a></th>
            <th><a><strong>Contact Number</strong></a></th>
            <th><a><strong>Access Type</strong></a></th>
            <th><a><strong>Status</strong></a></th>
            </tr>
    <?php
             $connection = DB::connectDB();
             $result = DB::getUsers($connection);
             $tmpEntryHolder=0;
             for ($i=0; $i < count($result); $i++) {
                 echo '<tr>';
                 $j=0;
                 while ( $j < count($result[0])) {
                     if ($j == 0) {
                         print_r('<td class=""><a><input type="radio" name="users" onclick="setUserID('.$result[$i][$tmpEntryHolder].')"></a></td>');
                     }else {
                         print_r('<td class="client_col"><a>'.$result[$i][$tmpEntryHolder].'</a></td>');
                     }
                     $j++;
                     $tmpEntryHolder++;
                 }
                 echo '</tr>';
             }
        ?>
        </table>
        <input type="hidden" id="setUserID" value="">
    </div>
</div>
<div id="userUpdateDialog" title="Manage User">
    Please select required action by clicking the button.
</div>


