<?php

?>
<div class="forms">
    <?php
    if(isset($_SESSION['ID'])):
        ?><a class="logout" href="./app_handler.php/?action=logout">Logout</a>
    <?php endif;?>
    <div>
        <form action="./?page=addUser" method="post">
            <?php 
                if(isset($_POST['username'])){
//                    require 'config.php';
//                    require 'DB.php';
                    $connection = DB::connectDB();
                    $result = DB::addUser($connection,$_POST['username'],$_POST['name'],$_POST['surname'],$_POST['contact'],$_POST['accessType'],$_POST['status']);
                    if($result){
                        echo 'User has been created successfully';
                    }else{
                        print_r('Error encountered: '.$result);
                    }
                }
            ?>
        <ul><h3>Add New User Form</h3>
            <li class="add_client"><a><strong>First Name:</strong></a><input class="" name="name" type="text" id="addCliName" value=""></li>
            <li class="add_client"><a><strong>Last Name:</strong></a><input class="" name="surname" type="text" id="addCliSur" value=""></li>
            <li class="add_client"><a><strong>Username:</strong></a><input class="" name="username" type="text" id="addCliCom" value=""></li>
            <li class="add_client"><a><strong>Password:</strong></a><input class="" name="password" type="text" id="addUserPass" value=""></li>
            <li class="add_client"><a><strong>Re-enter Password:</strong></a><input class="" name="repass" type="text" id="addUserPassre" value=""></li>
            <li class="add_client"><a><strong>Contact:</strong></a><input class="" name="contact" type="text" id="addCliCont" value=""></li>
                    <li class="add_client"><a><strong>Access Type:</strong></a><select class="" name="accessType" id="userAccessType" value="">
                            <option></option>
                            <option>user</option>
                            <option>admin</option>
                </select></li>
                <li class="add_client"><a><strong>Status:</strong></a><select class="" name="status" id="userStatus" value="">
                            <option></option>
                            <option>active</option>
                            <option>inactive</option>
                </select></li>
        <li class="add_client"><span><input type="submit"></span>
            <span><input type="reset" value="Clear"></span></li>
    </ul>
            </form>
</div></div>