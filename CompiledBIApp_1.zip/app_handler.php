<?php

require 'config.php';
require 'DB.php';
session_start();

if (isset($_POST['name'])) {
    require 'config.php';
    require 'DB.php';
    $connection = DB::connectDB();
    $result = DB::addClient($connection, $_POST['name'], $_POST['surname'], $_POST['company'], $_POST['industry'], $_POST['department'], $_POST['email'], $_POST['contact'], $_POST['category']);
    if ($result) {
        echo 'Client has been created successfully';
    } else {
        print_r('Error encountered: ' . $result);
    }
}
if (isset($_POST['username']) && isset($_POST['password'])) {
    try {
        $conn = DB::connectDB();
        $results = DB::login($conn, $_POST['username'], $_POST['password']);
        if ($results) {
            $_SESSION['ID'] = session_id();
            $_SESSION['name'] = $results['FIRSTNAME'];
            $_SESSION['surname'] = $results['LASTNAME'];
            header("Refresh:1, Url=". WEB_HOST . "/?login=1");
        } else {
            header("Refresh:2, Url=" . WEB_HOST . "/?login=0");
        }
        DB::closeConnection($conn);
    } catch (Exception $e) {
        echo '<h5><a class="red-text"><strong>' . $e->getMessage() . '</strong></a></h5> ' . $e->getCode();
    }
}
if(isset($_GET['action']) && $_GET['action'] == "logout"){
    session_destroy();
    header("Location:". WEB_HOST);
}
?>