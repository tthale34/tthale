<?php

?>
<div class="forms">
    <?php
    if(isset($_SESSION['ID'])):
        ?><a class="logout" href="./app_handler.php/?action=logout">Logout</a>
    <?php endif;?>
    <div>
        <form action="./?page=updateClient" method="post">
            <?php 
                if(isset($_GET['id'])){
                    $connection = DB::connectDB();
                    $result = DB::getClient($connection,$_GET['id']);
                    if($result):?>
                        <ul><h3>Update Client Form</h3>
                            <li class="add_client"><a><strong>First Name:</a></strong>
                            <input class="" name="uname" type="text" id="addCliName" value="<?php print_r($result[0][0]);?>"></li>
                            <li class="add_client"><a><strong>Last Name:</a></strong>
                            <input class="" name="usurname" type="text" id="addCliSur" value="<?php print_r($result[0][1]);?>"></li>
                            <li class="add_client"><a><strong>Company:</a></strong>
                            <input class="" name="ucompany" type="text" id="addCliCom" value="<?php print_r($result[0][2]);?>"></li>
                            <li class="add_client"><a><strong>Industry:</a></strong>
                            <input class="" name="uindustry" type="text" id="addCliInd" value="<?php print_r($result[0][3]);?>"></li>
                            <li class="add_client"><a><strong>Department:</a></strong>
                            <input class="" name="udepartment" type="text" id="addCliDep" value="<?php print_r($result[0][4]);?>"></li>
                            <li class="add_client"><a><strong>Email Address:</a></strong>
                            <input class="" name="uemail" type="text" id="addCliEma" value="<?php print_r($result[0][5]);?>"></li>
                            <li class="add_client"><a><strong>Contact:</a></strong
                            ><input class="" name="ucontact" type="text" id="addCliCont" value="<?php print_r($result[0][6]);?>"></li>
                            <li class="add_client"><a><strong>Category:</a></strong>
                            <input class="" name="ucategory" type="text" id="addCliCat" value="<?php print_r($result[0][7]);?>"></li>
                            <li class="add_client"><a><strong>Status:</a></strong>
                            <select class="" name="ustatus" id="addCliSta">
                                <option><?php print_r($result[0][8]);?></option>
                                <option>Open</option>
                                <option>Attempt Contact</option>
                                <option>Working</option>
                                <option>Qualified</option>
                                <option>Converted without Opportunity</option>
                                <option>Not Engaged</option>
                            </select></li>
                            <input type="hidden" name="uclientid" value="<?php echo $_GET['id'];?>">
                            <li class="add_client"><span><input type="submit"></span></li>
                        </ul>
                    <?php 
                    else:
                        echo 'Encountered error:<br>';
                        var_dump($result);
                    endif;
                }
                if(isset($_POST['uname'])){
                    $connection = DB::connectDB();
                    $result = DB::updateClient($connection,$_POST['uclientid'],$_POST['uname'],$_POST['usurname'],$_POST['ucompany'],$_POST['uindustry'],$_POST['udepartment'],$_POST['uemail'],$_POST['ucontact'],$_POST['ucategory'],$_POST['ustatus']);
                    if($result){
                        echo 'Client information updated successfully';
                        header("Refresh:2, Url=/?page=clients");
                    }else{
                        echo 'Encountered error:';
                        var_dump($result);
                    }
                }
            ?>        
            </form>
</div></div>