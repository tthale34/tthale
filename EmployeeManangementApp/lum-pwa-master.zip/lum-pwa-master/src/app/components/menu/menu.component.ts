import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.scss']
})
export class menuComponent implements OnInit { 
  @Input() tittle: string ;
  @Input() navPath:string;
  constructor(private router:Router) { }

  ngOnInit(): void { 
  }

  goBack(){

  }
  navigate(route:string){
    this.router.navigate([route]);
    }
    

}
