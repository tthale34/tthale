import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { ApiGatewayService } from 'src/app/services/api-gateway.service';

@Component({
  selector: 'app-email-modal',
  templateUrl: './email-modal.component.html',
  styleUrls: ['./email-modal.component.scss']
})
export class EmailModalComponent implements OnInit {
  emailPayLoad = {
    mailMessage: '',
    subject: '',
    ccList: '',
    copyMe: false
  };
  constructor(private spinner: NgxSpinnerService, private _api: ApiGatewayService) { }

  ngOnInit(): void {
    this.emailPayLoad = {
      mailMessage: '',
      subject: '',
      ccList: '',
      copyMe: false
    };
  }

  isCopyMe(value) {
    this.emailPayLoad.copyMe = value;
  }

  async sendMail() {
    if (this.emailPayLoad.mailMessage.length < 2 || this.emailPayLoad.subject.length < 1) {
      alert('Message body and subject are required');
      return;
    }
    await this.spinner.show();
    await this._api.sendEmail(this.emailPayLoad).then(res => {
      if (res.Status) {
        alert(res.Message)
        document.getElementById('emailModal').style.display = 'none'
      }
      else
        alert('We could not process your claim, please try again')
      this.spinner.hide()
    }).catch(err => {
      alert('We could not process your claim, please try again')
      this.spinner.hide()
    })
    this.spinner.hide();

  }

}
