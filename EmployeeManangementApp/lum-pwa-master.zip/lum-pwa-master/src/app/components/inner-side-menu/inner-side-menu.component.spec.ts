import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InnerSideMenuComponent } from './inner-side-menu.component';

describe('InnerSideMenuComponent', () => {
  let component: InnerSideMenuComponent;
  let fixture: ComponentFixture<InnerSideMenuComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InnerSideMenuComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InnerSideMenuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
