import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from 'src/app/services/authentication.service';

@Component({
  selector: 'app-inner-side-menu',
  templateUrl: './inner-side-menu.component.html',
  styleUrls: ['./inner-side-menu.component.scss']
})
export class InnerSideMenuComponent implements OnInit {
  show_testUsers:boolean = false;
  brokerDashboardAccess:boolean = false;
  user: any = {
    Names: null,
    Surname: null,
    InsurerScheme: null,
    Insurer: null,
    Policy_ID: null,
    Premium: {
      ph_nett: null
    }
  };
  constructor(private router:Router,private _authApi: AuthenticationService) { }

  async ngOnInit() {
    this.user = JSON.parse(localStorage.getItem('currentUser')).Data;
    if(this.user.AccessLevel_ID != 6){
      this.show_testUsers = true;
    }else{
      this.show_testUsers = false;
    }
    if(this.user.AccessLevel_ID == 2 || this.user.AccessLevel_ID == 3){
      this.brokerDashboardAccess = true;
    }else{
      this.brokerDashboardAccess = false;
    }
  }
  sli(){ 
document.getElementById("d2").style.width = "250px";
document.getElementById("d2").style.float = "right";
//document.getElementById("d2").style.position = "absolute";
return; 
  }

  sideMenuNav(route?:any){ 
    if(route != undefined)
    this.router.navigate([route]);
  }

  navigate(ss:any){}
  closeNav(){}
  logOut(){
    localStorage.removeItem('jwt');
    localStorage.removeItem('userProfile');
    localStorage.removeItem('currentUser');
    localStorage.removeItem('lookUps');
    this._authApi.logout();
  }
}
