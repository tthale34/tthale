import { Component, OnInit } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';
import { ApiGatewayService } from 'src/app/services/api-gateway.service';

@Component({
  selector: 'app-query-mail',
  templateUrl: './query-mail.component.html',
  styleUrls: ['./query-mail.component.scss']
})
export class QueryMailComponent implements OnInit {
  mailMessage: string = ''
  constructor(private spinner: NgxSpinnerService, private _api: ApiGatewayService) { }

  ngOnInit(): void {
  }

  async sendMail() {
    if (this.mailMessage.length < 2) {
      alert('Enter a valid message body')
      return;
    }
    await this.spinner.show();
    let queryDetails = await JSON.parse(localStorage.getItem('claimQueryDets'));
    queryDetails.message = await this.mailMessage;
    await this._api.sendQueryEmail(queryDetails).then(res => {
      if (res.Status) {
        alert(res.Message);
        document.getElementById('emailQueryModal').style.display = 'none'
      }
      else
        alert("Could not process your request, try again")

      this.spinner.hide()
    }).catch(err => {
      this.spinner.hide()
      alert("Could not process your request, try again")
    })
    this.spinner.hide()
    localStorage.removeItem('claimQueryDets')
  }

}
