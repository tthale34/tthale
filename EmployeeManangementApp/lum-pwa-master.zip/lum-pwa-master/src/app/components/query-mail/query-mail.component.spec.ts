import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { QueryMailComponent } from './query-mail.component';

describe('QueryMailComponent', () => {
  let component: QueryMailComponent;
  let fixture: ComponentFixture<QueryMailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ QueryMailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QueryMailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
