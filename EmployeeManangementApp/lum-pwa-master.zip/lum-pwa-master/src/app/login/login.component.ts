import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  email: string;
  password: string;
  showError: boolean = false;
  constructor(private router: Router) { }

  ngOnInit(): void {
    if (window.PublicKeyCredential) {
      console.log("yes")
  }
  }

  login() {
    if (this.email && this.password)
      this.router.navigate(['welcome']);
    else
      this.showError = true
  }

  registerUser(){
    this.router.navigate(['register'])
  }

  resetPassword(){
    this.router.navigate(['forgot-password'])
  }

}
