import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ServiceWorkerModule } from '@angular/service-worker';
import { environment } from '../environments/environment';
import { WelcomeComponent } from './pages/welcome/welcome.component';
import { LoginComponent } from './pages/login/login.component';
import { RegisterComponent } from './pages/register/register.component';
import { ForgotPasswordComponent } from './pages/forgot-password/forgot-password.component';
import { HeaderComponent } from './components/header/header.component';
import { NgxSpinnerModule } from "ngx-spinner";
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { OtpPageComponent } from './pages/otp-page/otp-page.component';
import { AuthenticationService } from './services/authentication.service';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { FicaComponent } from './pages/fica/fica.component';
import { AppSettingsComponent } from './pages/app-settings/app-settings.component';
import { MyClaimsComponent } from './pages/my-claims/my-claims.component';
import {menuComponent} from './components/menu/menu.component';
import { InnerSideMenuComponent } from './components/inner-side-menu/inner-side-menu.component';
import { GyserComponent } from './pages/forms/claims/gyser/gyser.component';
import { VehicleComponent } from './pages/forms/claims/vehicle/vehicle.component'
import {DpDatePickerModule} from 'ng2-date-picker';
import { BuildingComponent } from './pages/forms/claims/building/building.component';
import { BrokerComponent } from './pages/broker/broker.component';
import { MyDocumentsComponent } from './pages/my-documents/my-documents.component';
import { MyFinancialsComponent } from './pages/my-financials/my-financials.component';
import { PaymentHistoryComponent } from './pages/my-financials/payment-history/payment-history.component';
import { EmailModalComponent } from './components/email-modal/email-modal.component';
import { HomeContentComponent } from './pages/forms/claims/home-content/home-content.component';
import { UnspecifiedRiskComponent } from './pages/forms/claims/unspecified-risk/unspecified-risk.component';
import { VehicleTheftComponent } from './pages/forms/claims/vehicle-theft/vehicle-theft.component';
import { WindscreenComponent } from './pages/forms/claims/windscreen/windscreen.component';
import {NgbModal, ModalDismissReasons, NgbModule} from '@ng-bootstrap/ng-bootstrap';
import { ClaimsHomeComponent } from './pages/claims-home/claims-home.component';
import {HistoryDocumentsComponent} from './pages/my-documents/history-documents/history-documents.component';
import { ItemInfoComponent } from './pages/item-info/item-info.component';
import { BankingDetailsComponent } from './pages/my-financials/banking-details/banking-details.component';
import { MyProfileComponent } from './pages/my-profile/my-profile.component';
import { MyPolicyComponent } from './pages/my-policy/my-policy.component';
import { QueryMailComponent } from './components/query-mail/query-mail.component';
import {SpecifiedRiskComponent} from './pages/forms/claims/specified-risk/specified-risk.component';
import { SosComponent } from './pages/sos/sos.component';
import { AlertComponent } from './components/alert/alert.component';
import {AlertService} from './components/alert/alertService/alert-service.service' ;
import {ErrorInterceptor} from './interceptors/error.interceptor';
import { FridgeFreezerComponent } from './pages/forms/claims/fridge-freezer/fridge-freezer.component';
import { SpecifiedAllRiskComponent } from './pages/forms/claims/specified-all-risk/specified-all-risk.component';
import { ClientClaimUploadComponent } from './pages/forms/claims/client-claim-upload/client-claim-upload.component'
import { MyAddVehicleComponent } from './pages/my-add-vehicle/my-add-vehicle.component';
import { AddItemsComponent } from './pages/add-items/add-items.component';
import { AddVehicleDetailsComponent } from './pages/add-vehicle-details/add-vehicle-details.component';
import { ChangeItemInfoComponent } from './pages/change-item-info/change-item-info.component';
import { AddressAmendmentQuestionaireComponent } from 'src/app/pages/address-amendment-questionaire/address-amendment-questionaire.component';
import { BrokerAdvisorViewComponent } from './pages/broker-advisor-view/broker-advisor-view.component';
import { BrokerDashboardComponent } from './pages/broker-dashboard/broker-dashboard.component';
import { ScrollTopComponent } from './components/scroll-top/scroll-top.component';
import { UploadDocumentsComponent } from './pages/upload-documents/upload-documents.component';
import { RemoveItemComponent } from './pages/remove-item/remove-item.component';
import { MotorcycleComponent } from './pages/forms/claims/motorcycle/motorcycle.component';
import { CaravanTrailerComponent } from './pages/forms/claims/caravan-trailer/caravan-trailer.component';
import { LightVesselsComponent } from './pages/forms/claims/light-vessels/light-vessels.component';
import { PersonalComputerComponent } from './pages/forms/claims/personal-computer/personal-computer.component';
import { HashLocationStrategy, LocationStrategy  } from '@angular/common';
import { HelpchatComponent } from './pages/helpchat/helpchat.component';
import { UploadchatdocumentComponent } from './pages/uploadchatdocument/uploadchatdocument.component';


@NgModule({
  declarations: [
    AppComponent,
    WelcomeComponent,
    LoginComponent,
    RegisterComponent,
    ForgotPasswordComponent,
    HeaderComponent,
    OtpPageComponent,
    FicaComponent,
    AppSettingsComponent,
    MyClaimsComponent,
    menuComponent, InnerSideMenuComponent, GyserComponent, VehicleComponent, BuildingComponent, BrokerComponent, MyDocumentsComponent, MyFinancialsComponent, PaymentHistoryComponent, EmailModalComponent, HomeContentComponent, UnspecifiedRiskComponent, VehicleTheftComponent, WindscreenComponent, ClaimsHomeComponent,HistoryDocumentsComponent, ItemInfoComponent, BankingDetailsComponent, MyProfileComponent, MyPolicyComponent, QueryMailComponent,
    SpecifiedRiskComponent, SosComponent, AlertComponent, FridgeFreezerComponent, SpecifiedAllRiskComponent, ClientClaimUploadComponent, MyAddVehicleComponent, AddItemsComponent, AddVehicleDetailsComponent, ChangeItemInfoComponent, AddressAmendmentQuestionaireComponent, BrokerAdvisorViewComponent, BrokerDashboardComponent, ScrollTopComponent, UploadDocumentsComponent, RemoveItemComponent, MotorcycleComponent, CaravanTrailerComponent, LightVesselsComponent, PersonalComputerComponent, HelpchatComponent, UploadchatdocumentComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    NgxSpinnerModule,
    BrowserAnimationsModule,
    HttpClientModule,
    DpDatePickerModule ,
    NgbModule,
    ServiceWorkerModule.register('ngsw-worker.js', { enabled: environment.production, registrationStrategy: 'registerImmediately' }),
    //ServiceWorkerModule.register('ngsw-worker.js', { enabled: environment.production })
  ],
  providers: [
    AuthenticationService,
    AlertService,
    {provide : LocationStrategy , useClass: HashLocationStrategy},
    {provide:HTTP_INTERCEPTORS,useClass:ErrorInterceptor,multi:true},
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
