import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-otp-page',
  templateUrl: './otp-page.component.html',
  styleUrls: ['./otp-page.component.scss']
})
export class OtpPageComponent implements OnInit {
  optNum: string="";
  validOTP: string = "1234";
  otpValid: boolean = true;
  resent: boolean = false;
  user:any;
  constructor(private router: Router) { }

  ngOnInit(): void {
    this.user = JSON.parse(localStorage.getItem('user'));
    console.log(this.user)
  }

  validateOTP() {
    if (this.optNum == this.validOTP) {
      this.otpValid = true
      this.router.navigate(['welcome'])
    }
    else {
      this.resent = false;
      this.otpValid = false
    }
  }

  resendOtp() {
    this.resent = true;
    this.otpValid = true;
    this.optNum=""
  }

}
