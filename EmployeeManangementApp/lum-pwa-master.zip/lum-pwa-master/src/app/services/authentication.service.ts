import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable, from } from 'rxjs';
import { map } from 'rxjs/operators';
import { GlobalService } from '../helpers/globals';
import { User } from '../models/app-models'
import { Router } from '@angular/router';
import { ApiGatewayService } from 'src/app/services/api-gateway.service';

@Injectable({ providedIn: 'root' })
export class AuthenticationService {
  private currentUserSubject: BehaviorSubject<User>;
  public currentUser: Observable<User>;
  private globalService = new GlobalService()

  constructor(private http: HttpClient, private router: Router,private _api: ApiGatewayService) {
    this.currentUserSubject = new BehaviorSubject<User>(JSON.parse(localStorage.getItem('currentUser')));
    this.currentUser = this.currentUserSubject.asObservable();
  }

  public get currentUserValue(): User {
    return this.currentUserSubject.value;
  }

  login(user: string, pass: string) {
    return this.http.post<any>(`${this.globalService.baseUrl}/api/login.php`, { user, pass })
      .pipe(map(user => { 
        //console.log(user)
        localStorage.setItem('jwt', user.jwt); 
        // store user details and basic auth credentials in local storage to keep user logged in between page refreshes
        //  user.authdata = window.btoa(username + ':' + password);
        localStorage.setItem('currentUser', JSON.stringify(user.Result)); 
        localStorage.setItem('token', user.jwt); 
        this.currentUserSubject.next(user);
        return user;
      }));
  }
  jwt_login(jwt: string) {
    return this.http.post<any>(`${this.globalService.baseUrl}/api/jwt_login.php`, { jwt })
      .pipe(map(user => { 
        console.log(user)
        localStorage.setItem('jwt', user.jwt); 
        // store user details and basic auth credentials in local storage to keep user logged in between page refreshes
        //  user.authdata = window.btoa(username + ':' + password);
        localStorage.setItem('currentUser', JSON.stringify(user.Result)); 
        localStorage.setItem('token', user.jwt); 
        this.currentUserSubject.next(user);
        return user;
      }));
  }
  changeUserAccount(userid,PolicyID,authToken){
    return this.http.post<any>(`${this.globalService.baseUrl}/api/brokerAdvisor.php`, { userid,PolicyID,authToken })
      .pipe(map(user => {        
        localStorage.setItem('jwt', user.jwt); 
        // store user details and basic auth credentials in local storage to keep user logged in between page refreshes
        localStorage.setItem('currentUser', JSON.stringify(user.Result)); 
        localStorage.setItem('token', user.jwt);
        this._api.getLookUps().then(res => {
          localStorage.setItem('lookUps', JSON.stringify(res));
        });
        this.currentUserSubject.next(user);
        this._api.refreshUserJwt_();
        return user;
      })); 
  }

  async logout() {
    // remove user from local storage to log user out
    const usersString = await localStorage.getItem('users') || null;
    const authMethod = await localStorage.getItem("authMethod") || null;
   //console.log('logout');
   //console.log(localStorage.getItem("jwt"));
    //await localStorage.clear();
    // if (usersString != null)
    //   localStorage.setItem("users", usersString); 
    // if (authMethod != null)
    //   localStorage.setItem("authMethod", authMethod)
    await this.currentUserSubject.next(null);
    await this.router.navigate(['/']);
  }
}