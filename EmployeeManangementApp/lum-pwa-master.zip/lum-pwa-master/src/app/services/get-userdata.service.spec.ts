import { TestBed } from '@angular/core/testing';

import { GetUserdataService } from './get-userdata.service';

describe('GetUserdataService', () => {
  let service: GetUserdataService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(GetUserdataService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
