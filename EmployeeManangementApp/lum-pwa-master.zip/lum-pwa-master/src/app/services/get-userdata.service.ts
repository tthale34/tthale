import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class GetUserdataService {
  specifiedAllRiskPolicyItems:any;
  policySectionID:any;

  constructor() { }

  setSpecifiedAllRiskPolicyItems(data:any[]){
    this.specifiedAllRiskPolicyItems = data;
  }
  getSpecifiedAllRiskPolicyItems(){
    return this.specifiedAllRiskPolicyItems;
  }
  setPolicySectionID(data:any = null){
    console.log('seting in service: ');
    this.policySectionID = data;
  }
  getPolicySectionID(){
    return this.policySectionID;
  }
}
