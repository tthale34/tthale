import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { BehaviorSubject, Observable, from } from 'rxjs';
import { map } from 'rxjs/operators';
import { GlobalService } from '../helpers/globals';
@Injectable({
  providedIn: 'root'
})

// const headersUrl = 'http://localhost:3000/';
// const headersTop = new Headers;
      // let header = new HttpHeaders();
      // header.set('Access-Control-Allow-Origin', '*');

export class ApiGatewayService {
  private global_service = new GlobalService();
  private AuthToken: string = localStorage.getItem('jwt');




  constructor(private http: HttpClient,) {
    if (localStorage.getItem('jwt') != null || localStorage.getItem('jwt') != undefined) {
      this.AuthToken = localStorage.getItem('jwt') || localStorage.getItem('token');
    }

  //console.log('========== api construct -------------------');
  //console.log(this.AuthToken);
  //console.log('============================================');


  }
  refreshUserJwt_(){
    this.AuthToken = localStorage.getItem('jwt');
  }

  clearAuthToken() {
    this.AuthToken = null;
  }
  registerUser(user: string, pass: string): Observable<any> {
    return this.http.post(this.global_service.baseUrl + "/api/register.php", {
      user: user,
      pass: pass
    })
  }

  verifyFicaDetails(): Observable<any> {
    let jwt = this.AuthToken;
    return this.http.post(this.global_service.baseUrl + "/api/fica.php", {
      jwt
    })
  }

  getClaimsDetails(): Observable<any> {
    let jwt = this.AuthToken;
    return this.http.post(this.global_service.baseUrl + '/api/claim.motor.accident.php',
      { jwt }
    )
  }

  validateOTP(jwt, otp, user, pass): Observable<any> {
    return this.http.post(this.global_service.baseUrl + '/api/register.php',
      { user, otp, pass, jwt }
    )
  }

  async updateBankDetails(payLoad): Promise<any> {
    if (this.AuthToken == null || this.AuthToken == undefined) {
      this.AuthToken = await localStorage.getItem('jwt')
    }
    let jwt = this.AuthToken;
    payLoad.jwt = jwt;
    try {
      let res = fetch(this.global_service.baseUrl + '/api/bank.update.php', {
        method: 'POST',
        body: JSON.stringify(payLoad)
      }).then(response => response.json()).catch(err => {
        // this.alertProvider.presentAlert(this._generals.getGeneralError()["heading"], this._generals.getGeneralError()["mainMessage"]);
      })

      return res;
    } catch (error) {
    }

  }

  async getClientDocumentHistory(): Promise<any> {
  //console.log('========== documents auth token XX -------------------');
//  console.log(this.AuthToken);
  //console.log('======================================================');
    if (this.AuthToken == null || this.AuthToken == undefined) {
      this.AuthToken = await localStorage.getItem('jwt')
    }
    let jwt = this.AuthToken;

  //console.log('========== documents auth token -------------------');
  //console.log(this.AuthToken);
  //console.log(jwt);
  //console.log('===================================================');


    try {
      let res = fetch(this.global_service.baseUrl + '/api/policy.documents.php?jwt=' + jwt, {
        method: 'get'
      }).then(response => response.json()).catch(err => {
        // this.alertProvider.presentAlert(this._generals.getGeneralError()["heading"], this._generals.getGeneralError()["mainMessage"]);
      })

      return res;
    } catch (error) {
    }
  }

  async getClientFinancials(): Promise<any> {
    if (this.AuthToken == null || this.AuthToken == undefined) {
      this.AuthToken = await localStorage.getItem('jwt')
    }
    let jwt = await this.AuthToken;
    try {
      let res = fetch(this.global_service.baseUrl + '/api/financials.php?jwt=' + jwt, {
        method: 'get'
      }).then(response => response.json()).catch(err => {
        // this.alertProvider.presentAlert(this._generals.getGeneralError()["heading"], this._generals.getGeneralError()["mainMessage"]);
      })

      return res;
    } catch (error) {
    }
  }

  async callMe(): Promise<any> {
    if (this.AuthToken == null || this.AuthToken == undefined) {
      this.AuthToken = await localStorage.getItem('jwt')
    }
    let jwt = this.AuthToken;
    try {
      let res = fetch(this.global_service.baseUrl + '/api/broker.call.client.php', {
        method: 'POST',
        body: JSON.stringify({ 'jwt': jwt })
      }).then(response => response.json()).catch(err => { })

      return res;
    } catch (error) {
    }

  }

  async callMeBack(): Promise<any> {
    if (this.AuthToken == null || this.AuthToken == undefined) {
      this.AuthToken = await localStorage.getItem('jwt')
    }
    let jwt = this.AuthToken;
    try {
      let payLoad = await jwt;
      let res = fetch(this.global_service.baseUrl + '/api/client.please.callme.php', {
        method: 'POST',
        body: JSON.stringify({jwt:payLoad})
      }).then(response => response.json()).catch(err => { })

      return res;
    } catch (error) {
    }

  }

  async callMeForClaimQuery(payLoad): Promise<any> {
    if (this.AuthToken == null || this.AuthToken == undefined) {
      this.AuthToken = await localStorage.getItem('jwt')
    }
    let jwt = this.AuthToken;
    try {
      payLoad.jwt = await jwt;
      let res = fetch(this.global_service.baseUrl + '/api/claim.client.callme.php', {
        method: 'POST',
        body: JSON.stringify(payLoad)
      }).then(response => response.json()).catch(err => { })

      return res;
    } catch (error) {
    }

  }

  async submitClaim(payLoad): Promise<any> {
    if (this.AuthToken == null || this.AuthToken == undefined) {
      this.AuthToken = await localStorage.getItem('jwt')
    }
    let jwt = this.AuthToken;
    try {
      payLoad.jwt = jwt;
      let res = fetch(this.global_service.baseUrl + '/api/claim.php', {
        method: 'POST',
        body: JSON.stringify(payLoad)
      }).then(response => response.json()).catch(err => { })

      return res;
    } catch (error) {
    }

  }
  async chatUpload(payload): Promise<any> {
    console.log(payload);
    let formData: FormData = new FormData();
    formData.append('jwt', payload.jwt);
    formData.append('PolicyID', payload.PolicyID);
    formData.append('numberFiles', payload.documentList.length);
    formData.append('documents', payload.documentList);


    for (let index = 0; index < payload.documentList.length; index++) {
      formData.append('file' + index, payload.documentList[index].doc, payload.documentList[index].doc.name);
      formData.append('fileType' + index, payload.documentList[index].docType);
    }
    console.log(formData);
    try {
      let res = fetch(this.global_service.baseUrl + '/api/chat.uploadClientFile.php', {
        method: 'POST',
        body: formData
      }).then(response => response.json()).catch(err => { });
      console.log(res);
      return res;
    } catch (error) { console.log(error) }

  }
  async postUpload(payload): Promise<any>{
    console.log(payload);
    const formData: FormData = new FormData();
    formData.append('quoteValue',payload.quoteValue);
    formData.append('sapsRefNum',payload.sapsRefNum);
    formData.append('OriginalSupplier',payload.OriginalSupplier);
    formData.append('HirePurchaseRefNumber',payload.HirePurchaseRefNumber);
    formData.append('jwt',payload.jwt);
    formData.append('ClaimID',payload.ClaimID);
    formData.append('numberFiles',payload.documentList.length);
    formData.append('documents',payload.documentList);


    for (let index = 0; index < payload.documentList.length; index++) {
      formData.append('file'+index,payload.documentList[index].doc,payload.documentList[index].doc.name);
      formData.append('fileType'+index,payload.documentList[index].docType);
    }
    console.log(formData);
    try{
      let res = fetch(this.global_service.baseUrl + '/api/uploadClientFile.php', {
        method: 'POST',
        body: formData
      }).then(response => response.json()).catch(err => { });
      console.log(res);
      return res;
    }catch(error){console.log(error)}

  }
  submitQuestionaire(payLoad):Promise<any>{
    const formData: FormData = new FormData();
    formData.append('answers_0',payLoad.answers_0);
    formData.append('answers_1',payLoad.answers_1);
    formData.append('answers_2',payLoad.answers_2);
    formData.append('answers_3',payLoad.answers_3);
    formData.append('answers_4',payLoad.answers_4);
    formData.append('answers_5',payLoad.answers_5);
    formData.append('answers_6',payLoad.answers_6);
    formData.append('unoccupied',payLoad.unoccupied);
    formData.append('informal',payLoad.informal);
    formData.append('rank',payLoad.rank);
    formData.append('stand',payLoad.stand);
    formData.append('building',payLoad.building);
    formData.append('highway',payLoad.highway);
    formData.append('open',payLoad.open);
    formData.append('burglar',payLoad.burglar);
    formData.append('gates',payLoad.gates);
    formData.append('system',payLoad.system);
    formData.append('manufacture',payLoad.manufacture);
    formData.append('armed',payLoad.armed);
    formData.append('memory',payLoad.memory);
    formData.append('farm',payLoad.farm);
    formData.append('field',payLoad.field);
    formData.append('brigade',payLoad.brigade);
    formData.append('walled',payLoad.walled);
    formData.append('material',payLoad.material);
    formData.append('electrified',payLoad.electrified);
    formData.append('distance',payLoad.distance);
    formData.append('town',payLoad.town);
    formData.append('fire',payLoad.fire);
    formData.append('jwt',payLoad.jwt);
    try{
      let res = fetch(this.global_service.baseUrl + '/api/addressamendnotify_new.php', {
        method: 'POST',
        body: formData
      }).then(response => response.json()).catch(err => {console.log(err); });
      console.log(res);
      return res;
    }catch(error){console.log(error)}
  }

  async callTowTruck(payLoad): Promise<any> {
    if (this.AuthToken == null || this.AuthToken == undefined) {
      this.AuthToken = await localStorage.getItem('jwt')
    }
    let jwt = await this.AuthToken;
    try {
      payLoad.jwt = jwt;
      let res = fetch(this.global_service.baseUrl + '/api/claim.need.towing.php', {
        method: 'POST',
        body: JSON.stringify(payLoad)
      }).then(response => response.json()).catch(err => { })

      return res;
    } catch (error) {
    }

  }
  async saveRegDetails(payLoad){
    if (this.AuthToken == null || this.AuthToken == undefined) {
      this.AuthToken = await localStorage.getItem('jwt')
    }
    let jwt = this.AuthToken;
    const formData: FormData = new FormData();
    formData.append('jwt',jwt);
    formData.append('function_name','save_vehicle_details');
    formData.append('VehicleRegistrationNumber',payLoad.VehicleRegistrationNumber);
    formData.append('VehicleVIN',payLoad.VehicleVIN);
    formData.append('VehicleEngineNumber',payLoad.VehicleEngineNumber);
    formData.append('Bank_ID',payLoad.Bank_ID);
    formData.append('FinanceAccountNumber',payLoad.FinanceAccountNumber);
    formData.append('DateCoverStart',payLoad.DateCoverStart);
    formData.append('Policy_ID',payLoad.Policy_ID);
    formData.append('PolicySectionID',payLoad.PolicySectionID);
    try {
      var url = this.global_service.baseUrl + '/api/addVehicleFunctions.php' ;
      let res = fetch(url, {
        method: 'POST',
        body: formData
      }).then(response => response.json()).catch(err => { console.log(err);})
      console.log(res);
      return res;
    } catch (error) {console.log(error);
    }

  }

  async submitVehicle(payLoad,userObject){
    if (this.AuthToken == null || this.AuthToken == undefined) {
      this.AuthToken = await localStorage.getItem('jwt')
    }
    let jwt = this.AuthToken;
    const formData: FormData = new FormData();
    formData.append('jwt',jwt);
    formData.append('function_name','add_vehicle');
    for (const field in payLoad.form.controls) { // 'field' is a string
      formData.append(field , payLoad.form.controls[field].value);
    }
    for (let key of Object.keys(userObject)) {
      let itemvalue = userObject[key];
      formData.append("user_"+key,itemvalue);
    }
    try {
      payLoad.jwt = jwt;
      var url = this.global_service.baseUrl + '/api/addVehicleFunctions.php' ; // Your login session expired.
      let res = fetch(url, {
        method: 'POST',
        body: formData
      }).then(response => response.json()).catch(err => { })
      console.log(res);
      return res;
    } catch (error) {console.log(error);
    }
 }







  async submitVehicle1(payLoad,userObject){
    var url:string = "";
    if (this.AuthToken == null || this.AuthToken == undefined) {
      this.AuthToken = await localStorage.getItem('jwt');
    }
    let jwt = this.AuthToken;
    payLoad.append('jwt',jwt);

    const formData: FormData = new FormData();
    formData.append('function_name','add_vehicle');
    formData.append('jwt',jwt);
    for (const field in payLoad.form.controls) { // 'field' is a string
      formData.append(field,payLoad.form.controls[field].value);
    }
    for (let key of Object.keys(userObject)) {
      let itemvalue = userObject[key];
      formData.append("user_"+key,itemvalue);
    }
    url = this.global_service.baseUrl + '/api/addVehicleFunctions.php';
    try {
      let res = fetch(url, {
        method: 'POST',
        body: formData,
      }).then(response => response.json()).catch(err => {console.log(err) })

      console.log("ADD VEHICLE RESULT:");
      console.log(res);
      return res;
    } catch (error) {console.log(error);}


  }



  async saveVehicle(payLoad, userObject, PolicySectionID,isquote:boolean=false)
  {
    var url:string = "";
    if (this.AuthToken == null || this.AuthToken == undefined) {
      this.AuthToken = await localStorage.getItem('jwt');
    }
    let jwt = this.AuthToken;
    const formData: FormData = new FormData();
    formData.append('jwt',jwt);
    formData.append("PolicySectionID" ,PolicySectionID);
    formData.append("function_name" ,'save_vehicle');
    if(isquote == true){
      formData.append("IsQuoteYN" ,'Y');
      formData.append("DeletedYN" ,'N');
    }
    for (const field in payLoad.form.controls) { // 'field' is a string
      formData.append(field,payLoad.form.controls[field].value);
    }

    console.log(userObject);

    for (let key of Object.keys(userObject)) {
      let itemvalue = userObject[key];
      formData.append("user_"+key,itemvalue);
    }
    url = this.global_service.baseUrl + '/api/addVehicleFunctions.php';

    try {
      let res = fetch(url, {
        method: 'POST',
        body: payLoad
      }).then(response => response.json()).catch(err => {console.log(err) })

      console.log("RES:");
      console.log(res);
      return res;
    } catch (error) {console.log(error);}
  }

// save_add_policy
async SaveAddPolicy(payLoad, userObject, PolicySectionID)
{
  // alert('Save vehicle code');

  var url:string = "";
  // setTimeout(() => {  console.log("Timeout"); }, 20000);
  if (this.AuthToken == null || this.AuthToken == undefined) {
    this.AuthToken = await localStorage.getItem('jwt');
  }
  let jwt = this.AuthToken;
  const formData: FormData = new FormData();
  formData.append('jwt',jwt);
  formData.append("PolicySectionID" ,PolicySectionID);
  formData.append("function_name" ,'save_add_policy');

  for (const field in payLoad.form.controls) { // 'field' is a string
    formData.append(field,payLoad.form.controls[field].value);
  }
  console.log(userObject);
  for (let key of Object.keys(userObject)) {
    let itemvalue = userObject[key];
    formData.append("user_"+key,itemvalue);
  }
  url = this.global_service.baseUrl + '/api/addVehicleFunctions.php';

  try {
    let res = fetch(url, {
      method: 'POST',
      body: payLoad
    }).then(response => response.json()).catch(err => {console.log(err) })

    console.log("RES:");
    console.log(res);
    return res;
  } catch (error) {console.log(error);}
}
// cancel_vehicle
async cancelVehicle(payLoad, userObject, PolicySectionID)
{
  var url:string = "";
  if (this.AuthToken == null || this.AuthToken == undefined) {
    this.AuthToken = await localStorage.getItem('jwt');
  }
  let jwt = this.AuthToken;
  const formData: FormData = new FormData();
  formData.append('jwt',jwt);
  formData.append("PolicySectionID" ,PolicySectionID);
  formData.append("function_name" ,'cancel_vehicle');
  for (const field in payLoad.form.controls) { // 'field' is a string
    formData.append(field,payLoad.form.controls[field].value);
  }
  console.log(userObject);
  for (let key of Object.keys(userObject)) {
    let itemvalue = userObject[key];
    formData.append("user_"+key,itemvalue);
  }
  url = this.global_service.baseUrl + '/api/addVehicleFunctions.php';
  try {
    let res = fetch(url, {
      method: 'POST',
      body: formData
    }).then(response => response.json()).catch(err => {console.log(err) })

    console.log("RES:");
    console.log(res);
    return res;
  } catch (error) {console.log(error);}
}
// keep_quote
keepQuote(payLoad, userObject, PolicySectionID){
  var url:string = "";
  if (this.AuthToken == null || this.AuthToken == undefined) {
    this.AuthToken = localStorage.getItem('jwt');
  }
  let jwt = this.AuthToken;
  console.log("JWTTOKEN:");
  console.log(jwt);

  const formData: FormData = new FormData();
  formData.append('jwt',jwt);
  formData.append("PolicySectionID" ,PolicySectionID);
  formData.append("function_name" ,'keep_quote');

  for (const field in payLoad.form.controls) { // 'field' is a string
    formData.append(field,payLoad.form.controls[field].value);
  }
  console.log(userObject);
  for (let key of Object.keys(userObject)) {
    let itemvalue = userObject[key];
    formData.append("user_"+key,itemvalue);
  }
  var url = this.global_service.baseUrl + '/api/addVehicleFunctions.php';
  try {
    let res = fetch(url, {
      method: 'POST',
      body: formData
    }).then(response => response.json()).catch(err => {console.log(err) })
    console.log(res);
    return res;
  } catch (error) {console.log(error);}
}
  async sendComms(payLoad, userObject, PolicySectionID, commsAction, message)
  {
    var url:string = "";
    if (this.AuthToken == null || this.AuthToken == undefined) {
      this.AuthToken = await localStorage.getItem('jwt');
    }
    let jwt = this.AuthToken;
    const formData: FormData = new FormData();
    formData.append('jwt',jwt);
    formData.append("PolicySectionID" ,PolicySectionID);
    formData.append("commsAction", commsAction);
    formData.append("message", message);
    formData.append("function_name", commsAction);
    for (const field in payLoad.form.controls) { // 'field' is a string
      formData.append(field,payLoad.form.controls[field].value);
    }
    for (let key of Object.keys(userObject)) {
      let itemvalue = userObject[key];
      formData.append("user_"+key,itemvalue);
    }
    url = this.global_service.baseUrl + '/api/addVehicleFunctions.php';
    try {
      let res = fetch(url, {
        method: 'POST',
        body: formData
      }).then(response => response.json()).catch(err => {console.log(err) })

      console.log("RES:");
      console.log(res);
      return res;
    } catch (error) {console.log(error);}


  }

  async saveFourFields(payLoad, userObject, PolicySectionID){
    var url:string = "";
    if (this.AuthToken == null || this.AuthToken == undefined) {
      this.AuthToken = await localStorage.getItem('jwt');
    }
    let jwt = this.AuthToken;
    const formData: FormData = new FormData();
    formData.append('jwt',jwt);
    formData.append("PolicySectionID" ,PolicySectionID);
    formData.append("function_name" ,'save_four_fields');

    for (const field in payLoad.form.controls) { // 'field' is a string
      formData.append(field,payLoad.form.controls[field].value);
    }
    console.log(userObject);
    for (let key of Object.keys(userObject)) {
      let itemvalue = userObject[key];
      formData.append("user_"+key,itemvalue);
    }
    url = this.global_service.baseUrl + '/api/addVehicleFunctions.php';
    try {
      let res = fetch(url, {
        method: 'POST',
        body: formData
      }).then(response => response.json()).catch(err => {console.log(err) })
      console.log("RES:");
      console.log(res);
      return res;
    } catch (error) {console.log(error);}
  }
  getClaims(apiLink): Observable<any> {
    if (this.AuthToken == null || this.AuthToken == undefined) {
      this.AuthToken =  localStorage.getItem('jwt')
    }
    let jwt = this.AuthToken;

    try {
      if (apiLink == 'openClaims')
        return this.http.post<any>(this.global_service.baseUrl + '/api/claims.open.php', { jwt })
      if (apiLink == 'historyClaims')
        return this.http.post<any>(this.global_service.baseUrl + '/api/claims.all.php', { jwt })
    } catch (error) {

    }
  }
  removePolicyItem(payload,coverStartDate): Observable<any>{
    if (this.AuthToken == null || this.AuthToken == undefined) {
      this.AuthToken =  localStorage.getItem('jwt')
    }
    let jwt = this.AuthToken;
    try {
      return this.http.post<any>(this.global_service.baseUrl + '/api/remove.policyitem.php', { jwt,payload,coverStartDate});
    } catch (error) {
      console.log(error);
    }
  }
  removePolicyItemHousecontentFailed(payload,coverStartDate): Observable<any>{
    if (this.AuthToken == null || this.AuthToken == undefined) {
      this.AuthToken =  localStorage.getItem('jwt')
    }
    let jwt = this.AuthToken;
    try {
      return this.http.post<any>(this.global_service.baseUrl + '/api/remove.policyitem.failed.php', { jwt,payload,coverStartDate});
    } catch (error) {
      console.log(error);
    }
  }
  removePolicyItemBuildingFailed(payload,coverStartDate): Observable<any>{
    if (this.AuthToken == null || this.AuthToken == undefined) {
      this.AuthToken =  localStorage.getItem('jwt')
    }
    let jwt = this.AuthToken;
    try {
      return this.http.post<any>(this.global_service.baseUrl + '/api/remove.policyitemhousoldcontentcheck.failed.php', { jwt,payload,coverStartDate});
    } catch (error) {
      console.log(error);
    }
  }
  getBrokerDetails(payLoad,lastYearClients = false,claimID = 0,note=''): Observable<any> {
    if (this.AuthToken == null || this.AuthToken == undefined) {
      this.AuthToken =  localStorage.getItem('jwt')
    }
    let jwt = this.AuthToken;
    // console.log(jwt);
    try {
      return this.http.post<any>(this.global_service.baseUrl + '/api/broker.claims.php',
                                  { jwt,payLoad,lastYearClients,claimID,note});
    } catch (error) {
      console.log("Caught error in getBrokerClaims: "+error);
    }
  }
  addClaimNote(payLoad): Observable<any>{
    if (this.AuthToken == null || this.AuthToken == undefined) {
      this.AuthToken =  localStorage.getItem('jwt')
    }
    let jwt = this.AuthToken;
    try {
      return this.http.post<any>(this.global_service.baseUrl + '/api/broker.claims.php', {jwt, payLoad});
    } catch (error) {
      console.log("Caught error in add claim note: "+error);
    }
  }
  getVehicleMake(){
        try {
          let res = fetch(this.global_service.baseUrl + '/api/getVehicles.php', {
            method: 'GET',
          }).then(response => response.json()).catch(err => { })

          return res;
          }
          catch (error) {}
  }
  getDocuments(apiLink: string, additionalData?: any): Observable<any> {
    let jwt = this.AuthToken;
    let corsHeaders = new HttpHeaders({
      'Content-Type': 'application/json',
      'Accept': 'application/json',
    });

    try {
      let endPoint = null;
      switch (apiLink) {
        case 'generateSchedule':
          endPoint = 'generate.schedule.php?jwt='
          break;
        case 'claimHistory':
          endPoint = 'generate.claimstats.letter.php?jwt='
          break;
        case 'borderLetter':
          endPoint = 'generate.border.letter.php?fromDate=' + additionalData.dateFrom + '&toDate=' + additionalData.dateTo + '&dataKey=' + additionalData.dataKey + '&jwt='
          break;
        case 'taxPolicy':
          endPoint = 'generate.taxpolicy.letter.php?fromDate=' + additionalData.dateFrom + '&toDate=' + additionalData.dateTo + '&jwt='
          break;
        case 'taxItem':
          endPoint = 'generate.taxitem.letter.php'//?fromDate=' + additionalData.dateFrom + '&toDate=' + additionalData.dateTo + '&jwt='
          if(apiLink=='taxItem'){
            additionalData.jwt = jwt;
            //console.log(additionalData)

            return this.http.post<any>(this.global_service.baseUrl + '/api/' + endPoint,
           additionalData

          )
          }
          break;
        case 'coverConfirmation':
          endPoint = 'generate.confirmation.buildings.php?dataKey=' + additionalData.dataKey + '&jwt='
          break;
        case 'coverConfirmationVeh':
          endPoint = 'generate.confirmation.motor.php?dataKey=' + additionalData.dataKey + '&jwt='
          break;
        case 'coverConfirmationMotorcycle':
          endPoint = 'generate.confirmation.motorcycle.php?dataKey=' + additionalData.dataKey + '&jwt='
          break;
        case 'coverConfirmationcaravantrailer':
          endPoint = 'generate.confirmation.trailercaravan.php?dataKey=' + additionalData.dataKey + '&jwt='
          break;



        default:
          break;
      }

      return this.http.get<any>(this.global_service.baseUrl + '/api/' + endPoint + jwt,
        {
          headers: corsHeaders
        }
      )
    } catch (error) {
    }
  }
  async updateProfile(payLoad): Promise<any> {
    if (this.AuthToken == null || this.AuthToken == undefined) {
      this.AuthToken = await localStorage.getItem('jwt')
    }
    let jwt = await this.AuthToken;
    payLoad.jwt = jwt;
    try {
      let res = fetch(this.global_service.baseUrl + '/api/client.update.php', {
        method: 'POST',
        body: JSON.stringify(payLoad)
      }).then(response => response.json()).catch(err => { })

      return res;
    } catch (error) {
    }
  }
  refreshUserData(jwt){
    const formData: FormData = new FormData();
    formData.append('jwt',jwt);
    try{
      return this.http.get<any>(this.global_service.baseUrl + '/api/refresh.user.object.php?jwt='+jwt)
      .pipe(map(user => {
        // console.log(user);
        localStorage.setItem('currentUser', JSON.stringify(user.Result));
        return user;
      }));
    }catch(error){console.log(error)}
  }
  async getBankList(){
    if (this.AuthToken == null || this.AuthToken == undefined) {
      this.AuthToken = await localStorage.getItem('jwt')
    }
    let jwt = await this.AuthToken;
    const formData: FormData = new FormData();
    formData.append('jwt',jwt);
    formData.append('function_name','get_bank_list');
        var url = this.global_service.baseUrl + '/api/addVehicleFunctions.php';
        try {
          let res = fetch(url, {
            method: 'POST',
            body: formData
          }).then(response => response.json()).catch(err => { })

          return res;
          }
          catch (error) {}
  }
  async getSuburbName(suburbId){
    var url = this.global_service.baseUrl + '/api/addVehicleFunctions.php';
    if (this.AuthToken == null || this.AuthToken == undefined) {
      this.AuthToken = localStorage.getItem('jwt')
    }
    let jwt = this.AuthToken;
    const formData: FormData = new FormData();
    formData.append('jwt',jwt);
    formData.append('suburbId',suburbId);
    formData.append('function_name','get_suburb_id');
    try {
      let res = fetch(url, {
        method: 'POST',
        body: formData
      }).then(response => response.json()).catch(err => { })

      return res;
      }
      catch (error) {}

  }
  async getPolicySection(PolicySectionID){
    if (this.AuthToken == null || this.AuthToken == undefined) {
      this.AuthToken = await localStorage.getItem('jwt')
    }
    let jwt = await this.AuthToken;
    const formData: FormData = new FormData();

    formData.append('jwt',jwt);
    formData.append('PolicySection_ID',PolicySectionID);
    formData.append('function_name','get_policy_section');
    // console.log(formData);
    var url = this.global_service.baseUrl + '/api/addVehicleFunctions.php';
    try {
      let res = fetch(url, {
        method: 'POST',
        body: formData
      }).then(response => response.json()).catch(err => { })

      return res;
      }
      catch (error) {}

  }
  async getPolicyItem(payLoad): Promise<any> {
    const formData: FormData = new FormData();
    formData.append('jwt',payLoad);
    formData.append('function_name','get_policy_section_jwt');
    console.log(payLoad);
    try {
      let res = fetch(this.global_service.baseUrl + '/api/addVehicleFunctions.php', {
        method: 'POST',
        body: formData
      }).then(response => response.json()).catch(err => {console.log(err);});
      return res;
    } catch (error) {console.log(error);}
  }
  async getLookUps() {
   if (this.AuthToken == null || this.AuthToken == undefined) {
      this.AuthToken = await localStorage.getItem('jwt')
   }
   let jwt = await this.AuthToken;
    try {
      let res = fetch(this.global_service.baseUrl + '/api/getlookups.php?jwt=' + jwt, {
        method: 'GET',
      }).then(response => response.json()).catch(err => { })

      return res;
    } catch (error) {
    }
  }
  async sendNoVehicleEmail(payLoad): Promise<any> { //sends query mail to broker
    if (this.AuthToken == null || this.AuthToken == undefined) {
      this.AuthToken = await localStorage.getItem('jwt')
    }
    let jwt = await this.AuthToken;
    payLoad.jwt = jwt;
    try {
      let res = fetch(this.global_service.baseUrl + '/api/claim.novehicle.email.php', {
        method: 'POST',
        body: JSON.stringify(payLoad)
      }).then(response => response.json()).catch(err => { })

      return res;
    } catch (error) {
    }
  }

  async sendQueryEmail(payLoad): Promise<any> { //sends query mail to broker
    if (this.AuthToken == null || this.AuthToken == undefined) {
      this.AuthToken = await localStorage.getItem('jwt')
    }
    let jwt = await this.AuthToken;
    payLoad.jwt = jwt;
    try {
      let res = fetch(this.global_service.baseUrl + '/api/claim.query.email.php', {
        method: 'POST',
        body: JSON.stringify(payLoad)
      }).then(response => response.json()).catch(err => { })

      return res;
    } catch (error) {
    }
  }


  async sendEmail(payLoad): Promise<any> {
    if (this.AuthToken == null || this.AuthToken == undefined) {
      this.AuthToken = await localStorage.getItem('jwt')
    }
    let jwt = await this.AuthToken;
    payLoad.jwt = jwt;
    try {
      let res = fetch(this.global_service.baseUrl + '/api/client.email.broker.php', {
        method: 'POST',
        body: JSON.stringify(payLoad)
      }).then(response => response.json()).catch(err => { })

      return res;
    } catch (error) {
    }

  }

  async modifyItems(payLoad: any, action: string) {
    if (this.AuthToken == null || this.AuthToken == undefined) {
      this.AuthToken = await localStorage.getItem('jwt')
    }
    let jwt = await this.AuthToken;
    let api = await null;
    payLoad.jwt = await jwt;
    switch (action) {
      case 'remove':
        api = await '/api/item.remove.php';
        break;
      case 'add':
        api = await '/api/item.add.php';
        break;

      default:
        api = await '/api/item.update.php';
        break;
    }
    try {
      let res = fetch(this.global_service.baseUrl + api, {
        method: 'POST',
        body: JSON.stringify(payLoad)
      }).then(response => response.json()).catch(err => {console.log(err); })

      return res;
    } catch (error) {
    }

  }

  async logAssistCall() {
    if (this.AuthToken == null || this.AuthToken == undefined) {
      this.AuthToken = await localStorage.getItem('jwt')
    }
    let jwt = await this.AuthToken;
    try {
      let res = fetch(this.global_service.baseUrl + '/api/client.called.assist.php?jwt=' + jwt, {
        method: 'GET',
      }).then(response => response.json()).catch(err => { })

      return res;
    } catch (error) {
    }
  }
  async getVehicleInfo(payLoad){
    const formData: FormData = new FormData();

    if (this.AuthToken == null || this.AuthToken == undefined) {
      this.AuthToken = await localStorage.getItem('jwt')
    }
    let jwt = await this.AuthToken;

    formData.append('function_name','get_vehicle_info');
    formData.append('jwt',jwt);
    formData.append('VehicleMakeID',payLoad.VehicleMakeID);
    formData.append('VehicleYear',payLoad.VehicleYear);
    formData.append('VehicleModelID',payLoad.VehicleModelID);
    payLoad.jwt = jwt;
    try {
      let res = fetch(this.global_service.baseUrl + '/api/addVehicleFunctions.php', {
        method: 'POST',
        body: formData
      }).then(response => response.json()).catch(err => { })

      return res;
    } catch (error) {
    }
  }
  async  getPostalAdd(policyId,action,content = null){
    if (this.AuthToken == null || this.AuthToken == undefined) {
      this.AuthToken = await localStorage.getItem('jwt')
    }
    let jwt = await this.AuthToken;
    let payload:any;
    payload = {
      jwt:jwt,
      Policy_ID:policyId,
      Action:action,
      Content:content
    };
    // console.log(payload);
    try {
      let res = fetch(this.global_service.baseUrl + '/api/addressAmend.php', {
        method: 'POST',
        body: JSON.stringify(payload)
      }).then(response => response.json()).catch(err => { })

      return res;
    } catch (error) {
    }

  }
  async getAccidentDamageAmount(policySectionId){
    if (this.AuthToken == null || this.AuthToken == undefined) {
      this.AuthToken = await localStorage.getItem('jwt')
    }
    let jwt = await this.AuthToken;
    let payload:any;
    payload = {
      jwt:jwt,
      PolicySection_ID:policySectionId
    };
    console.log(payload);
    try {
      let res = fetch(this.global_service.baseUrl + '/api/getAccidentDamage.php', {
        method: 'POST',
        body: JSON.stringify(payload)
      }).then(response => response.json()).catch(err => { })

      return res;
    } catch (error) {
    }
  }

}
