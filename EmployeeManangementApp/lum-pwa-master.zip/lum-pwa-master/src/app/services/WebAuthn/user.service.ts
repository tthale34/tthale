import { Injectable } from '@angular/core'; 

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor() { }

  getUser(email: string): any {
    return this.getUsers().find(u => u.email === email);
  }

  getUsers(): any[] {
    const usersString  = localStorage.getItem('users');
    return usersString ? JSON.parse(usersString) : [];
  }

  saveUsers(users: any[]) {
    return localStorage.setItem('users', JSON.stringify(users));
  }

  addUser(user: any) {
    const users = [...this.getUsers(), user];
    this.saveUsers(users);
  }

  removeUser(email: string) {
    const filteredUsers = this.getUsers().filter(user => user.email !== email);
    this.saveUsers(filteredUsers);
  }
}
