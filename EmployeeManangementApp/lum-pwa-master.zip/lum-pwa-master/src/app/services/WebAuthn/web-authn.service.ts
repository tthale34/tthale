import { Injectable } from '@angular/core'; 
import { ServerMockService } from './server-mock.service';

@Injectable({
  providedIn: 'root'
})
export class WebAuthnService {

  constructor(private serverMockService: ServerMockService) { }

  webAuthnSignup(user: any): Promise<any> {
    const publicKeyCredentialCreationOptions: PublicKeyCredentialCreationOptions = {
      // Challenge shoulda come from the server
      challenge: this.serverMockService.getChallenge(),
      rp: {
        name: 'WebAuthn Test',
        // id: 'localhost:4200',
      },
      user: {
        // Some user id coming from the server
        id: Uint8Array.from(user.id, c => c.toString().charCodeAt(0)),
        name: user.email,
        displayName: user.email,
      },
      pubKeyCredParams: [{ alg: -7, type: 'public-key' }],
      authenticatorSelection: {
        authenticatorAttachment: 'platform',
        // requireResidentKey: true,
      },
      timeout: 60000,
      attestation: 'direct'
    };

    return navigator.credentials.create({
      publicKey: publicKeyCredentialCreationOptions,
    });

  }

  webAuthnSignin(user: any): Promise<any> {
    console.log(user) 
    const allowCredentials: PublicKeyCredentialDescriptor[] = user.credentials.map(c => { 
      return { type: 'public-key', id: Uint8Array.from(Object.values(c.credentialId)) };
    });
 

    const credentialRequestOptions: PublicKeyCredentialRequestOptions = {
      challenge: this.serverMockService.getChallenge(),
      allowCredentials,
    };

    return navigator.credentials.get({
      publicKey: credentialRequestOptions,
    });
  }
}
