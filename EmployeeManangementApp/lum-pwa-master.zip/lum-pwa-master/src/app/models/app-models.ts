export class User {
    id: number;
    username: string;
    password: string;
    firstName: string;
    lastName: string;
    authdata?: string;
    token:string;
}
export interface IBaseResponse{
    status:boolean;
    data:[];
}

export interface IAuth extends IBaseResponse{
    jwt:string;
    message:string;
}

export interface DecodedAttestionObj {
    attStmt: {
      alg: number;
      sig: Uint8Array;
    };
    authData: Uint8Array;
    fmt: string;
  }

  export interface ClientDataObj {
    challenge: string;
    origin: string;
    type: string;
  }
  
  