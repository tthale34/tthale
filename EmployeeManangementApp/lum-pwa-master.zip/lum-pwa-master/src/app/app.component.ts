import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms'
import { ApiGatewayService } from './services/api-gateway.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  loginForm: FormGroup;
  loading = false;
  submitted = false;
  returnUrl: string;


  constructor(private formBuilder: FormBuilder,
    private _api: ApiGatewayService,
    private router: Router,) {

  }

  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      username: ['', Validators.required],
      password: ['', Validators.required]
    });

    window.addEventListener('beforeinstallprompt', (e) => {
      console.log("ddddd");
      // Prevent the mini-infobar from appearing on mobile
      //e.preventDefault();
      // Stash the event so it can be triggered later.
      //deferredPrompt = e;
      // Update UI notify the user they can install the PWA
      //  showInstallPromotion();
    });
  }


  onSubmit(){
    this.router.navigateByUrl('welcome');
  }






}
