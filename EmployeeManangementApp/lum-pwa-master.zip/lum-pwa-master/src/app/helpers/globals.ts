export class GlobalService {
    private serverPort: number = 0;
    public baseUrl: string;
    private claimIDs: any = {};
    constructor() {
       // this.baseUrl = 'https://cors-anywhere.herokuapp.com/'+'http://mypolicy.lum.co.za/api';
         this.baseUrl = 'https://mypolicy.lum.co.za/api';

    }

    private setClaimIDs(): void {
        this.claimIDs = {
            windScreen: 1,
            vehicleTheft: 5,
            geyser: 46,
            vehicleAccident: 8
        }
    }

    public getClaimIDs(): iC {
        this.setClaimIDs()
        return this.claimIDs;
    }


}

interface iC {
    windScreen: number,
    vehicleTheft: number,
    geyser: number,
    vehicleAccident: number
}
