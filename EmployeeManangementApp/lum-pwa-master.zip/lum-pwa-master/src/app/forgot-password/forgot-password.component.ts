import { Component, OnInit } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.scss']
})
export class ForgotPasswordComponent implements OnInit {
idNumber:string="";
cellNumber:string="";
  constructor(private spinner: NgxSpinnerService,) { }

  ngOnInit(): void {
  }
  submitReset() { 
    this.spinner.show();

    setTimeout(() => { 
      this.spinner.hide(); 

    }, 5000);
  }

}
