import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { WelcomeComponent } from './pages/welcome/welcome.component';
import { LoginComponent } from './pages/login/login.component';
import { RegisterComponent } from './pages/register/register.component';
import { ForgotPasswordComponent } from './pages/forgot-password/forgot-password.component';
import { OtpPageComponent } from './pages/otp-page/otp-page.component';
import { AuthGuard } from './helpers/auth-guard.service';
import { FicaComponent } from './pages/fica/fica.component';
import { AppSettingsComponent } from './pages/app-settings/app-settings.component';
import { MyClaimsComponent } from './pages/my-claims/my-claims.component';
import { GyserComponent } from './pages/forms/claims/gyser/gyser.component';
import { FridgeFreezerComponent } from './pages/forms/claims/fridge-freezer/fridge-freezer.component';
import { SpecifiedAllRiskComponent } from './pages/forms/claims/specified-all-risk/specified-all-risk.component';
import { VehicleComponent } from './pages/forms/claims/vehicle/vehicle.component';
import { BuildingComponent } from './pages/forms/claims/building/building.component';
import { BrokerComponent } from './pages/broker/broker.component';
import { MyDocumentsComponent } from './pages/my-documents/my-documents.component';
import { MyFinancialsComponent } from './pages/my-financials/my-financials.component';
import { PaymentHistoryComponent } from './pages/my-financials/payment-history/payment-history.component';
import { HomeContentComponent } from './pages/forms/claims/home-content/home-content.component';
import { UnspecifiedRiskComponent } from './pages/forms/claims/unspecified-risk/unspecified-risk.component';
import { VehicleTheftComponent } from './pages/forms/claims/vehicle-theft/vehicle-theft.component';
import { WindscreenComponent } from './pages/forms/claims/windscreen/windscreen.component';
import { ClaimsHomeComponent } from './pages/claims-home/claims-home.component';
import { HistoryDocumentsComponent } from './pages/my-documents/history-documents/history-documents.component';
import { ItemInfoComponent } from './pages/item-info/item-info.component';
import { BankingDetailsComponent } from './pages/my-financials/banking-details/banking-details.component';
import { MyProfileComponent } from './pages/my-profile/my-profile.component';
import { MyPolicyComponent } from './pages/my-policy/my-policy.component';
import { SpecifiedRiskComponent } from './pages/forms/claims/specified-risk/specified-risk.component';
import { SosComponent } from './pages/sos/sos.component';
import { ClientClaimUploadComponent } from './pages/forms/claims/client-claim-upload/client-claim-upload.component'
import { MyAddVehicleComponent } from './pages/my-add-vehicle/my-add-vehicle.component';
import { AddItemsComponent } from './pages/add-items/add-items.component';
import { AddVehicleDetailsComponent } from './pages/add-vehicle-details/add-vehicle-details.component';
import { ChangeItemInfoComponent } from './pages/change-item-info/change-item-info.component';
import { AddressAmendmentQuestionaireComponent } from 'src/app/pages/address-amendment-questionaire/address-amendment-questionaire.component';
import { BrokerAdvisorViewComponent } from './pages/broker-advisor-view/broker-advisor-view.component';
import { BrokerDashboardComponent } from './pages/broker-dashboard/broker-dashboard.component';
import { UploadDocumentsComponent } from './pages/upload-documents/upload-documents.component';
import { RemoveItemComponent } from './pages/remove-item/remove-item.component';
import { MotorcycleComponent } from './pages/forms/claims/motorcycle/motorcycle.component';
import { CaravanTrailerComponent } from './pages/forms/claims/caravan-trailer/caravan-trailer.component';
import { LightVesselsComponent } from './pages/forms/claims/light-vessels/light-vessels.component';
import { PersonalComputerComponent } from './pages/forms/claims/personal-computer/personal-computer.component';
import { HelpchatComponent } from './pages/helpchat/helpchat.component';
import { UploadchatdocumentComponent } from './pages/uploadchatdocument/uploadchatdocument.component';

const routes: Routes = [
  { path: '', component: LoginComponent },
  { path: 'welcome', component: WelcomeComponent, canActivate: [AuthGuard] },
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'forgot-password', component: ForgotPasswordComponent },
  { path: 'optpage', component: OtpPageComponent },
  { path: 'fica', component: FicaComponent },
  { path: 'app-settings', component: AppSettingsComponent },
  { path: 'claims-home', component: ClaimsHomeComponent },
  { path: 'my-claims', component: MyClaimsComponent },
  { path: 'gyser-form', component: GyserComponent },
  { path: 'fridge-freezer', component: FridgeFreezerComponent },
  { path: 'specified-all-risk', component: SpecifiedAllRiskComponent },
  { path: 'light-vessel', component: LightVesselsComponent },
  { path: 'personal-computer', component: PersonalComputerComponent },
  { path: 'vehicle-form', component: VehicleComponent },
  { path: 'building-form', component: BuildingComponent },
  { path: 'my-broker', component: BrokerComponent },
  { path: 'my-documents', component: MyDocumentsComponent },
  { path: 'my-financials', component: MyFinancialsComponent },
  { path: 'payment-history', component: PaymentHistoryComponent },
  { path: 'home-content', component: HomeContentComponent },
  { path: 'uspecified-risk', component: UnspecifiedRiskComponent },
  {path:  'specified-risk',component:SpecifiedRiskComponent},
  { path: 'vehicle-theft', component: VehicleTheftComponent },
  { path: 'windscreen', component: WindscreenComponent },
  { path: 'document-history', component: HistoryDocumentsComponent },
  { path: 'item-info', component: ItemInfoComponent },
  { path: 'my-add-vehicle', component: MyAddVehicleComponent },
  { path: 'add-vehicle-details', component: AddVehicleDetailsComponent },
  { path: 'change-item-info', component: ChangeItemInfoComponent },
  { path: 'address-amendment-questionaire', component: AddressAmendmentQuestionaireComponent },
  { path: 'broker-advisor-view', component: BrokerAdvisorViewComponent },
  { path: 'broker-dashboard', component: BrokerDashboardComponent },
  { path: 'add-items', component: AddItemsComponent },
  { path: 'banking-details', component: BankingDetailsComponent },
  { path: 'sos', component: SosComponent },
  { path: 'my-profile', component: MyProfileComponent },
  { path: 'my-policy', component: MyPolicyComponent },
  { path: 'client-claim-upload', component: ClientClaimUploadComponent },
  { path: 'upload-documents', component: UploadDocumentsComponent },
  { path: 'upload-documents/?', component: UploadDocumentsComponent },
  { path: 'upload-chatdocuments', component: UploadchatdocumentComponent },
  { path: 'upload-chatdocuments/?', component: UploadchatdocumentComponent },
  { path: 'remove-item', component: RemoveItemComponent },
  { path: 'motorcycle', component: MotorcycleComponent },
  { path: 'caravan-trailer', component: CaravanTrailerComponent },
  { path: 'helpchat', component: HelpchatComponent },
  // otherwise redirect to home
  { path: '**', redirectTo: '' }
];
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
