import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ApiGatewayService } from 'src/app/services/api-gateway.service';

@Component({
  selector: 'app-otp-page',
  templateUrl: './otp-page.component.html',
  styleUrls: ['./otp-page.component.scss']
})
export class OtpPageComponent implements OnInit {
  otpNum: string = "";
  validOTP: string = "1234";
  otpValid: boolean = true;
  resent: boolean = false;
  user: any;
  creds: any;
  password: string
  constructor(private router: Router, private _api: ApiGatewayService) { }

  async ngOnInit() {
    this.user = await JSON.parse(localStorage.getItem('user'));
    this.creds = await JSON.parse(localStorage.getItem('userCredentials'));
    console.log(this.creds)
    if(this.creds == null){
      this.router.navigate(['login']);
      return;
    }
  
  }

  validateOTP() {
    this._api.validateOTP(this.creds.jwt, this.otpNum, this.creds.userName, this.creds.password).subscribe(res => {
      if (res.Status) {
        localStorage.setItem('jwt',this.creds.jwt);
        localStorage.removeItem('userCredentials');
        console.log(res.Result)
        localStorage.setItem('userProfile',JSON.stringify(res.Result)) 
        this.router.navigate(['fica']);
      }
      else
        this.otpValid = false;
    })
  }

  resendOtp() {
    this.resent = true;
    this.otpValid = true;
    // this.otpNum=""
  }

}
