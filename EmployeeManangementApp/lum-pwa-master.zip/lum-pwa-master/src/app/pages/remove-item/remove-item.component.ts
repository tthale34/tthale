import { isDefined } from '@angular/compiler/src/util';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { ApiGatewayService } from 'src/app/services/api-gateway.service';

@Component({
  selector: 'app-remove-item',
  templateUrl: './remove-item.component.html',
  styleUrls: ['./remove-item.component.scss']
})
export class RemoveItemComponent implements OnInit {
  insureItems:Array<any> =[];
  householdOrBuildingContents:Array<any> =[];
  householdContentsList:Array<any> =[];
  buildingContentsList:Array<any> =[];
  unspecifiedAllRiskItems:Array<any> = [];
  CoverStartDate=new Date().toISOString().slice(0, 10);
  constructor(private router: Router,private _api: ApiGatewayService,private spinner: NgxSpinnerService) { }

  async ngOnInit() {
    for (let i = 1; i <= 9; i++){
      let item = await JSON.parse(localStorage.getItem('currentUser')).Data.PolicyItems[i];
      console.log(item);
      if (JSON.parse(localStorage.getItem('currentUser')).Data.PolicyItems[i] != undefined) {
        for (let j = 0; j < item.length; j++) {
          this.insureItems.push(item[j]);
          console.log(item[j].PolicySection_ID);
        }
      }
    }


  }
  navigate(route) {
    console.log(route);
    this.router.navigate([route]);
  }
  preventKeyPress(event:any){
    alert("Please use date select button to update the date");
    this.CoverStartDate=new Date().toISOString().slice(0, 10);
  }
  setItemCheck(value){
    if(this.insureItems[value].DeletedYN == "N"){
      this.insureItems[value].DeletedYN = "Y";
    }else{
      this.insureItems[value].DeletedYN = "N";
    }
  }
  // this.insureItems.forEach(element => {
  //   if (element.PolicySection_ID == 9 || element.PolicySection_ID == 1 && element.DeletedYN == "N") {
  //     this.householdOrBuildingContents.push(element);
  //   }
  // });

  async submit(){
    this.insureItems.forEach(element => {
      if ((element.PolicySection_ID == 9 || element.PolicySection_ID == 1) && element.DeletedYN == "N" ) {
        this.householdOrBuildingContents.push(element);
      }
    });
    
    this.insureItems.forEach(element => {
      if (element.PolicySection_ID == 9 && element.DeletedYN == "N" ) {
        this.householdContentsList.push(element);
      }
    });

    this.insureItems.forEach(element => {
      if (element.PolicySection_ID == 1 && element.DeletedYN == "N" ) {
        this.buildingContentsList.push(element);
      }
    });

    this.insureItems.forEach(element => {
      if (element.ItemType_ID == 26 && element.DeletedYN == "N" ) {
        this.unspecifiedAllRiskItems.push(element);
      }
    });

    if (this.householdOrBuildingContents.length < 1) {
      await this.spinner.show();
      this._api.removePolicyItemHousecontentFailed(this.insureItems,this.CoverStartDate).subscribe(res1 => {
          this.spinner.hide();
          this.router.navigate(['welcome']);
          alert("Please note that this action can't be completed, it has been referred to your Broker for assistance.");
      }, err => {
        this.spinner.hide();
        alert("Could not process your request now, Please try again later:"+err);
      });
    } else if(this.householdContentsList.length < 1 && this.buildingContentsList.length > 0 && this.unspecifiedAllRiskItems.length > 0) {
      await this.spinner.show();
      this._api.removePolicyItemBuildingFailed(this.insureItems,this.CoverStartDate).subscribe(res1 => {
          this.spinner.hide();
          this.router.navigate(['welcome']);
          alert("Please note that this action can't be completed, it has been referred to your Broker for assistance.");
      }, err => {
        this.spinner.hide();
        alert("Could not process your request now, Please try again later:"+err);
      });
    } else {
      await this.spinner.show();
      this._api.removePolicyItem(this.insureItems,this.CoverStartDate).subscribe(res1 => {
        console.log('remove: ' + res1);
        if (res1.Status) {
          this.spinner.hide();
          alert(res1.Message);
          this.router.navigate(['welcome']);
        }
        else{
          this.spinner.hide();
          alert(res1.Message);
        }
      }, err => {
        this.spinner.hide();
        alert("Could not process your request now, Please try again later:"+err);
      });
    }


  }

}
