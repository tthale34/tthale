import { HelpchatComponent } from './../helpchat/helpchat.component';
import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthenticationService } from '../../services/authentication.service';
import { IAuth } from 'src/app/models/app-models';
import { NgxSpinnerService } from 'ngx-spinner';
import { ServerMockService } from '../../services/WebAuthn/server-mock.service';
import { WebAuthnService } from '../../services/WebAuthn/web-authn.service';

@Component({
	selector: 'app-login',
	templateUrl: './login.component.html',
	styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
	// email: string = 'elich@lum.co.za';  //email and pass to be handled somehow using local storage
	// password: string = 'test';
	// @ViewChild(HelpchatComponent) helpchat;
	jwt: any;
	email: string = '';  //email and pass to be handled somehow using local storage
	password: string = '';
	showError: boolean = false;
	authMethod: string = null;
	users: any;
	convidparamsfromurl: any = "";
	conditionmettogotoconv: any = false;
	webAuthnAvailable = !!navigator.credentials && !!navigator.credentials.create;
	convidparamurl: string;
	constructor(private serverMockService: ServerMockService, private webAuthnService: WebAuthnService, private spinner: NgxSpinnerService, private router: Router, private route: ActivatedRoute, private auth_api: AuthenticationService) {

	}

	async ngOnInit() {
		await localStorage.clear()
		await localStorage.removeItem('userProfile');
		await localStorage.removeItem('jwt')
		this.authMethod = await localStorage.getItem("authMethod");
		this.users = await localStorage.getItem('users');
		this.convidparamurl = this.route.snapshot.queryParamMap.get('convid');
		if (this.route.snapshot.queryParamMap.get('jwt')) {
			console.log("JWT:" + this.route.snapshot.queryParamMap.get('jwt'));
			await this.auth_api.jwt_login(this.route.snapshot.queryParamMap.get('jwt')).subscribe((res) => {
				console.log(res);
				if (res.Status) {
					localStorage.setItem('jwt', res.jwt);
					localStorage.setItem('token', res.jwt);
					let x = localStorage.getItem('jwt');
					if (res.Result.Data.AccessLevel_ID == 6) {
						if (this.route.snapshot.queryParamMap.get('convid')) {
							//set convid, userid for chat
							//show chat window

							localStorage.setItem('convidurl', this.convidparamurl);
							console.log(this.convidparamurl);
							this.router.navigate(['helpchat']);
						} else {
							this.router.navigate(['welcome']);
						}


					} else if (res.Result.Data.AccessLevel_ID == 2 || res.Result.Data.AccessLevel_ID == 3) {
						this.router.navigate(['broker-dashboard']);
					} else {
						this.router.navigate(['broker-advisor-view']);
					}
				} else {
					localStorage.removeItem('jwt');
					localStorage.removeItem('token');
					alert(res.Message);
				}
			}, err => {
				alert("Could not log you in at the moment, try again")
			})

		}
		if (this.authMethod != 'deviceAuth' || this.users == undefined) {
			this.email = ''
			this.password = ''
		}
	}

	async login(loginType: string) {
		await this.spinner.show()
		if (loginType == 'deviceAuth') {
			this.webAuthSignin();
			//return;
		} else {
			await this.auth_api.login(this.email, this.password).subscribe((res) => {
				//console.log('========= RES ===============');
				console.log(res);
				if (res.Status) {
					localStorage.setItem('jwt', res.jwt);
					localStorage.setItem('token', res.jwt);
					//console.log('========= local ===============');
					let x = localStorage.getItem('jwt');
					//console.log(x);
					//console.log('--------- local ---------------');
					if (res.Result.Data.AccessLevel_ID == 6) {
						this.router.navigate(['welcome']);
					} else if (res.Result.Data.AccessLevel_ID == 2 || res.Result.Data.AccessLevel_ID == 3) {
						this.router.navigate(['broker-dashboard']);
					} else {
						this.router.navigate(['broker-advisor-view']);
					}
				} else {
					localStorage.removeItem('jwt');
					localStorage.removeItem('token');
					alert(res.Message);
				}
			}, err => {
				alert("Could not log you in at the moment, try again")
			})

		}
		this.spinner.hide();
	}

	registerUser() {
		this.router.navigate(['register'])
	}

	resetPassword() {
		this.router.navigate(['forgot-password'])
	}

	async webAuthSignin() {
		await this.spinner.show();
		const user = await this.serverMockService.getUser(this.email);
		await this.webAuthnService.webAuthnSignin(user).then((response) => {
			this.auth_api.login(this.email, this.password).subscribe((res) => {
				if (res.Status)
					this.router.navigate(['welcome']);
				else
					alert("Could not log you in. Try again later");
			}, err => {
				alert("Could not log you in. Try again later")
			})
		})
			.catch((error) => {
				alert('Sorry :( Invalid credentials!');
				//console.log('FAIL', error);
			});
		this.spinner.hide()
	}

}
