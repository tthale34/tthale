import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddressAmendmentQuestionaireComponent } from './address-amendment-questionaire.component';

describe('AddressAmendmentQuestionaireComponent', () => {
  let component: AddressAmendmentQuestionaireComponent;
  let fixture: ComponentFixture<AddressAmendmentQuestionaireComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddressAmendmentQuestionaireComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddressAmendmentQuestionaireComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
