import { FormBuilder } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { ApiGatewayService } from 'src/app/services/api-gateway.service';

@Component({
  selector: 'app-address-amendment-questionaire',
  templateUrl: './address-amendment-questionaire.component.html',
  styleUrls: ['./address-amendment-questionaire.component.scss']
})
export class AddressAmendmentQuestionaireComponent implements OnInit {
  answers = {
    answers_0:'',
    answers_1:'',
    answers_2:'',
    answers_3:'',
    answers_4:'',
    answers_5:'',
    answers_6:'',
    unoccupied:'',
    informal:'',
    rank:'',
    stand:'',
    building:'',
    highway:'',
    open:'',
    burglar:'',
    gates:'',
    system:'',
    manufacture:'',
    armed:'',
    memory:'',
    farm:'',
    field:'',
    brigade:'',
    walled:'',
    material:'',
    electrified:'',
    distance:'',
    town:'',
    fire:'',
    jwt:'',
  }

  constructor(private route: ActivatedRoute,private spinner: NgxSpinnerService,private formBuilder:FormBuilder,private httpClient:HttpClient,private _api: ApiGatewayService) { }

  ngOnInit(): void {
    this.route.queryParams.subscribe(params=>{
      this.answers.jwt =params['jwt'];
    });
    localStorage.setItem('jwt',this.answers.jwt);
    localStorage.setItem('token',this.answers.jwt);
    let x = localStorage.getItem('jwt');
    console.log(x);
    console.log(this.route.queryParams);
  }

  async onSubmit(){
    await this.spinner.show();
      this._api.submitQuestionaire(this.answers).then(res => {
        console.log(res);
        if(res.Status){
          alert(res.Message)
          this.spinner.hide();
        }else{
          alert(res.Message)
          this.spinner.hide();
        }
      }).catch(err=>{
        this.spinner.hide();
        console.log(err);
        alert(err);
      });
  }

}
