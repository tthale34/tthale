import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-policy',
  templateUrl: './my-policy.component.html',
  styleUrls: ['./my-policy.component.scss']
})
export class MyPolicyComponent implements OnInit {
user:any={};
rootObj:any={}
  constructor() { }

  async ngOnInit() {
    this.user = await JSON.parse(localStorage.getItem('currentUser')).Data;
    // console.log(this.user);
    for (var key in this.user.PolicyItems) {
      if (this.user.PolicyItems.hasOwnProperty(key)) {
        this.rootObj.push(this.user.PolicyItems[key]);
      }   console.log(this.rootObj)
    }
  }

  submit(){

  }

  nav(){}

}
