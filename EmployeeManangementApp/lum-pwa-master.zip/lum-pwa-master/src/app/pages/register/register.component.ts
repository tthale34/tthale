import { Component, OnInit } from '@angular/core';
import { NgxSpinnerService } from "ngx-spinner";
import { Router } from '@angular/router';
import { ApiGatewayService } from '../../services/api-gateway.service';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent implements OnInit {
  userName: string = "";
  password: string = ""
  password2:string ="";
  constructor(private spinner: NgxSpinnerService, private router: Router, private _api: ApiGatewayService) { }

  ngOnInit(): void {
  }

  submitForm() {
    if(this.password != this.password2){
      alert("Password Mismatch");
      return;
    }
    if(this.userName.length == 0){
      alert("Username cannot be empty");
      return;
    }
    
    this.spinner.show(); 
    setTimeout(() => {
      /** spinner ends after 5 seconds */
      this._api.registerUser(this.userName, this.password).subscribe((res) => {
        if (res.Status) {
          localStorage.removeItem('userCredentials')
          localStorage.setItem('userCredentials', JSON.stringify({'jwt':res.jwt, 'userName': this.userName, 'password': this.password }))
  
          this.router.navigate(['optpage']);
        }
        else {
          this.spinner.hide();
          alert(res.Message);
        }


      })
      this.spinner.hide();

    }, 5000);
  }



}
