import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient} from '@angular/common/http';
import { NgxSpinnerService } from "ngx-spinner";
import { ApiGatewayService } from 'src/app/services/api-gateway.service';
import { AuthenticationService } from '../../services/authentication.service';

@Component({
  selector: 'app-broker-advisor-view',
  templateUrl: './broker-advisor-view.component.html',
  styleUrls: ['./broker-advisor-view.component.scss']
})
export class BrokerAdvisorViewComponent implements OnInit {

  PolicyCode:'';
  clientUserID:'';
  clientPolicyID:'';
  Surname:'';
  Initials:'';
  ID_Number:'';
  user:any;
  clientList:Array<any> = [];
  AuthToken:any;

  constructor(private _api: ApiGatewayService,private router: Router,private http: HttpClient,private spinner: NgxSpinnerService,private auth_api: AuthenticationService) { }

  async ngOnInit() {
    this.user = await JSON.parse(localStorage.getItem('currentUser')).Data;
    console.log(this.user);

    if (this.AuthToken == null || this.AuthToken == undefined) {
      this.AuthToken = await localStorage.getItem('jwt');
    }
  }
  nav() {
    this.router.navigate(['welcome']);
  }
  clear(){
    this.PolicyCode='';
    this.Surname='';
    this.Initials='';
    this.ID_Number='';
    this.clientList = [];
  }
  async search(){
    await this.spinner.show();
    if(this.Surname == undefined){
      this.Surname='';
    }
    if(this.Initials == undefined){
      this.Initials='';
    }
    if(this.PolicyCode == undefined){
      this.PolicyCode='';
    }
    if(this.ID_Number == undefined){
      this.ID_Number='';
    }
    let url = "https://mypolicy.lum.co.za/api/api/brokerAdvisor.php?policyCode=" + this.PolicyCode + "&surname="+this.Surname+"&initials="+ this.Initials+"&idnumber=" + this.ID_Number+"&jwt="+this.AuthToken;
      await this.http.get(url).toPromise().then(data => {
        if(data){
          this.addUserDetails(data);
        }else{
          alert("Please enter valid policy number.");
        }        
      }); 

    this.spinner.hide();
  }
  async goToClient(value,policyID){
    await this.spinner.show();
    await this.auth_api.changeUserAccount(value,policyID,this.AuthToken).subscribe((res) => {
      if (res.Status) {
        localStorage.setItem('jwt',res.jwt); 
        localStorage.setItem('token',res.jwt);
        let x =  localStorage.getItem('jwt');
        
        this.router.navigate(['welcome']);        
      } else {       
        alert(res.Message);
      }
    }, err => {
      alert("Could not change to client account.");
    });
    await this.spinner.hide();
  }
  addUserDetails(data){
    let pc,n,s,id,clte,ps;
    this.clientList = [];

    if (data.length != undefined) {
      for (let i = 0; i < data.length; i++) {
        pc = data[i].PolicyCode
        n = data[i].Names;
        s = data[i].Surname;
        id = data[i].IDNumber;
        clte = data[i].ClientEmail;
        ps = data[i].PolicyStatus;
        this.clientUserID = data[i].User_ID;
        this.clientPolicyID = data[i].PolicyID;
        this.clientList.push({policyCode:pc,clientName:n,clientSurname:s,idNumber:id,email:clte,status:ps,clientUserID:data[i].User_ID,policyID:data[i].PolicyID});
      }
    }else{
      for (let key in data){
        if (data.hasOwnProperty(key)){       
          if (key == "PolicyCode") {
            pc = data[key];
          }if (key == "Names") {
            n = data[key];
          }if (key == "Surname") {
            s = data[key];
          }if (key == "IDNumber") {
            id = data[key];
          }if (key == "ClientEmail") {
            clte = data[key];
          }if (key == "PolicyStatus") {
            ps = data[key];
          }if (key == "User_ID") {
            this.clientUserID = data[key];
          }if (key == "PolicyID") {
            this.clientPolicyID = data[key];
          }
        }
      }
      this.clientList.push({policyCode:pc,clientName:n,clientSurname:s,idNumber:id,email:clte,status:ps,clientUserID:this.clientUserID,policyID:this.clientPolicyID});
    }    
  }
}
