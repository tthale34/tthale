import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BrokerAdvisorViewComponent } from './broker-advisor-view.component';

describe('BrokerAdvisorViewComponent', () => {
  let component: BrokerAdvisorViewComponent;
  let fixture: ComponentFixture<BrokerAdvisorViewComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BrokerAdvisorViewComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BrokerAdvisorViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
