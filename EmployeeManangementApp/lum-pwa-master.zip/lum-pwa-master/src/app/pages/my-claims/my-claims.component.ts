import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { ApiGatewayService } from 'src/app/services/api-gateway.service';
import { GetUserdataService } from 'src/app/services/get-userdata.service';

@Component({
  selector: 'app-my-claims',
  templateUrl: './my-claims.component.html',
  styleUrls: ['./my-claims.component.scss']
})
export class MyClaimsComponent implements OnInit {
  show_testUsers:boolean = false;
  usersId:any;
  user:any;
  tempPolicyItems: Array<any> = [];
  policyItems: Array<any> = [];
  itemTypeForSpecAllRsk= ['1','12','19','21','23','1045','1051','1053','1059','22','8','10','11','4','7','28','1038','1043','1044','1058','1063','27','6',
  '34','35','13','17','20','1042','1047','1049','1052','1057','1085','1084','1083','1082','1081','1080','1079','1078','1076','1075','1074','1073','1072','1071',
  '1070','1069','1068','1067','1092'];
  newClaims: boolean = false;
  openClaims: boolean = false;
  historyClaims: boolean = false;
  userItems: any;
  myClaims: Array<any> = [];
  constructor(private spinner: NgxSpinnerService, private router: Router, private activatedRoute: ActivatedRoute, private _api: ApiGatewayService,private _userData: GetUserdataService) {
    if (!this.activatedRoute.snapshot.queryParamMap.has('section')) {
      alert("Something went wrong");
      this.router.navigate(['claims-home']);
      return;
    }
  }
  async ngOnInit() {
    this.user = await JSON.parse(localStorage.getItem('currentUser')).Data;
    console.log(this.user);
    if (this.user.User_ID == 16726 || this.user.User_ID == 16971 || this.user.User_ID == 17847) {
      this.show_testUsers = true;
    }
    switch (this.activatedRoute.snapshot.queryParamMap.get('section')) {
      case 'newClaims':
        this.newClaims = await true;
        break;
      case 'historyClaims':
        this.historyClaims = await true;
        await this._api.getClaims('historyClaims').subscribe(res => {
          console.log(res)
          if (res.Status) {
            this.myClaims = res.Result.Data;
          }
          else
            alert("Could not process your request now, Please try again later")
        }, err => {
          alert("Could not process your request now, Please try again later")
        })
        break;
      default:
        this.openClaims = await true;
        await this._api.getClaims('openClaims').subscribe(res => {
          console.log(res)
          if (res.Status) {
            this.myClaims = res.Result.Data;
          }
          else
            alert("Could not process your request now, Please try again later")
        }, err => {
          alert("Could not process your request now, Please try again later")
        })
        break;
    }
    this.userItems = await JSON.parse(localStorage.getItem('currentUser')).Data.PolicyItems;
  }

  async getClaims() {
    if (this.historyClaims)
      await this._api.getClaims('historyClaims').subscribe(res => { console.log(res) })
    else if (this.openClaims)
      await this._api.getClaims('openClaims').subscribe(res => { console.log(res) })

  }

  mailQuery(claimIdx) {
    document.getElementById('emailQueryModal').style.display = 'block';
    localStorage.setItem('claimQueryDets', JSON.stringify({
      ClaimID: this.myClaims[claimIdx].PID,
      claimCode: this.myClaims[claimIdx].ClaimCode, ResponsiblePerson: this.myClaims[claimIdx].ResponsiblePersonEmail,
      ResponsiblePersonEmail: this.myClaims[claimIdx].ResponsiblePersonEmail
    }))
  }

  async callMe(claimIdx) {
    let callMeDetails = {
      ClaimID: this.myClaims[claimIdx].PID,
      claimCode: this.myClaims[claimIdx].ClaimCode, ResponsiblePerson: this.myClaims[claimIdx].ResponsiblePersonEmail,
      ResponsiblePersonEmail: this.myClaims[claimIdx].ResponsiblePersonEmail
    }
    await this.spinner.show();
    await this._api.callMeForClaimQuery(callMeDetails).then(res => {
      if (res.Status) {
        this.spinner.hide()
        alert(res.Message);
        return;
      }
      alert("Could not process your request, try again")
      this.spinner.hide()
    }).catch(err => {
      alert("Could not process your request, try again")
      this.spinner.hide()
    })
  }

  openSection(claimSection) {
    if (claimSection == 'newClaims') {
      this.newClaims = true
      this.openClaims = false
      this.historyClaims = false
    }
    else if (claimSection == 'openClaims') {
      this.newClaims = false
      this.openClaims = true
      this.historyClaims = false
    }
    else if (claimSection == 'historyClaims') {
      this.newClaims = false
      this.openClaims = false
      this.historyClaims = true
    }
  }
  async goToForm(route) {
    if (route == 'specified-all-risk') {
      this.tempPolicyItems = await JSON.parse(localStorage.getItem('currentUser')).Data.PolicyItems[6];
      for (let index = 0; index < this.tempPolicyItems.length; index++) {
        for (let i = 0; i < this.itemTypeForSpecAllRsk.length; i++) {
          if (this.itemTypeForSpecAllRsk[i] == this.tempPolicyItems[index].ItemType_ID) {
            this.policyItems[this.policyItems.length] = this.tempPolicyItems[index];
          }
        }
      }
      if (this.policyItems.length == 0) {
        alert("You do not have any specified all risk items insured on your policy.");
        return
      }else{
        this._userData.setSpecifiedAllRiskPolicyItems(this.policyItems);
      }
    }
    if (route == 'vehicle-form' || route == 'vehicle-theft' || route == 'windscreen') {
      if (this.userItems['2'] == undefined) {
        alert('You Do Not Have Any Vehicles Insured On Your Policy');
        return
      }
    }
    this.router.navigate([route]);
  }
}
