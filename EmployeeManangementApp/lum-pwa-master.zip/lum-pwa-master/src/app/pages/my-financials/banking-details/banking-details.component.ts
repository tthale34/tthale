import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { ApiGatewayService } from 'src/app/services/api-gateway.service';

@Component({
  selector: 'app-banking-details',
  templateUrl: './banking-details.component.html',
  styleUrls: ['./banking-details.component.scss']
})
export class BankingDetailsComponent implements OnInit {
  bankDetails = {
    bankName: '',
    accountHolder: '',
    accountNumber: '',
    branchCode: ''
  }
  user: any = {}
  constructor(private spinner: NgxSpinnerService,private router: Router, private _api: ApiGatewayService) { }

  async ngOnInit() {
    this.user = await JSON.parse(localStorage.getItem('currentUser')).Data;
    this.bankDetails.bankName = this.user.bankname;
    this.bankDetails.accountNumber = this.user.accountnumber;
    this.bankDetails.branchCode = this.user.branchcode;
    this.bankDetails.accountHolder = this.user.accountname
    console.log(this.user)

  }
  async submit() {
    await this.spinner.show();
    if (this.bankDetails.accountHolder.length < 4 || this.bankDetails.accountNumber.length < 5 || this.bankDetails.bankName.length < 3) {
      alert("Fields marked with * cannot be empty")
      return;
    }

    this._api.updateBankDetails(this.bankDetails).then(res => {
      if (res.Status) {
        alert(res.Message)
        this.router.navigate(['my-financials']);
      } else
        alert('We could not process your request now, try again')
        this.spinner.hide();
    }).catch(err => {
      this.spinner.hide();
      alert('We could not process your request now, try again')
    })


  }

  nav() {
    this.router.navigate(['my-financials']);

  }
}
