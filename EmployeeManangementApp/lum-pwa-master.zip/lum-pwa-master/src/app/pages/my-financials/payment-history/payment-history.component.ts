import { Component, OnInit } from '@angular/core';
import { ApiGatewayService } from 'src/app/services/api-gateway.service';
import { Router } from '@angular/router';
import { NgxSpinnerService } from "ngx-spinner";
@Component({
  selector: 'app-payment-history',
  templateUrl: './payment-history.component.html',
  styleUrls: ['./payment-history.component.scss']
})
export class PaymentHistoryComponent implements OnInit {

  myFinancials: Array<any> = [];
  loading: boolean = true;
  constructor(private spinner: NgxSpinnerService, private _api: ApiGatewayService, private router: Router) { }

  async ngOnInit() {
    await this.spinner.show();
    await this._api.getClientFinancials().then(res => {
      if (res.Status) {
        this.myFinancials = res.Result.Data;
        this.loading = false;
      }
      else {
        alert("Could not retrive your payment history now, try again later");
        this.router.navigate(['my-financials']);
      }
    }).catch(err => {
      alert("Could not retrive your payment history now, try again later");
      this.router.navigate(['my-financials']);
    })
    this.spinner.hide();
  }

  re

}
