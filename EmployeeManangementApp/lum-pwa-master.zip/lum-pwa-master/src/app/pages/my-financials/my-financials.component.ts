import { Component, OnInit } from '@angular/core';
import { ApiGatewayService } from 'src/app/services/api-gateway.service';
import { Router } from '@angular/router';
import { NgxSpinnerService } from "ngx-spinner";
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
@Component({
  selector: 'app-my-financials',
  templateUrl: './my-financials.component.html',
  styleUrls: ['./my-financials.component.scss']
})
export class MyFinancialsComponent implements OnInit {
  myFinancials:any; 
  docType:any;
  selectedGroupProduct:string = 'motorVehicle'
  additionalData={
    dateFrom: '',
    dateTo: '',
    buildingID:0,
    vehId:0,
    itemID:0,
    dataKey: 0,
    isBuidlingConfirmationCover:true 
  }
  motorVehicles: Array<any> = [];
  myBuildings: Array<any> = [];
  constructor(private spinner: NgxSpinnerService,private modalService: NgbModal,private router: Router, private _api:ApiGatewayService) { }

  async ngOnInit() { 
    let items = await JSON.parse(localStorage.getItem('currentUser'))
    this.motorVehicles = await items.Data.PolicyItems['2'];
    this.myBuildings = await items.Data.PolicyItems['1']; 
    this.additionalData.vehId = this.motorVehicles[0].PID;
    this.additionalData.buildingID = this.myBuildings[0].PID;
    this.additionalData.itemID = this.additionalData.buildingID
    this.additionalData.dataKey = this.additionalData.buildingID;
  }
  goToForm(route){
    this.router.navigate([route]) ;
  }

  async open(content) {
    this.modalService.open(content, { ariaLabelledBy: 'modal-basic-title' }).result.then((result) => {
      //this.closeResult = `Closed with: ${result}`; 
      let apiCall = null;
      delete this.additionalData.vehId
      delete this.additionalData.buildingID
      delete this.additionalData.isBuidlingConfirmationCover
      apiCall = this._api.getDocuments(this.docType, this.additionalData); 
      this.spinner.show()
      apiCall.subscribe(res => {
          if (res.Status) {
            alert(res.Message)
           this.spinner.hide();
          }
          else {
            alert(res.Message)
           this.spinner.hide(); 
          }
        }, err => {
          alert('Could not process your request');
        this.spinner.hide();
        })
    }, (reason) => {
      this.spinner.hide();
    });
  }

  generateDocuments(value){
    if (value == 'taxPolicy' || value == 'borderLetter' || value == 'taxItem' || value == 'coverConfirmation') {
      this.selectedGroupProduct = 'motorVehicle'
      this.docType = value;
      if (value == 'borderLetter') {
        this.additionalData.dataKey = this.motorVehicles[0].PID;
        this.additionalData.itemID = this.motorVehicles[0].PID; 
      }
      document.getElementById('finmod').click();
      return;
    }
  }

  
  
  onItemChange(value) {
    this.selectedGroupProduct = value;
    if (value == 'buidling') {
      this.additionalData.isBuidlingConfirmationCover = true;
      this.additionalData.dataKey = this.myBuildings[0].PID;
      this.additionalData.itemID = this.myBuildings[0].PID;
    }
    else {
      this.additionalData.dataKey = this.motorVehicles[0].PID;
      this.additionalData.itemID = this.motorVehicles[0].PID;
      this.additionalData.isBuidlingConfirmationCover = false;
    }

  }

  myBuidlingItemChange(value) {
    this.additionalData.buildingID = value;
    this.additionalData.itemID = value;
    this.additionalData.dataKey = value;
  }

  vehicleChange(value) {
    this.additionalData.vehId = value;
    this.additionalData.itemID = value;
    this.additionalData.dataKey = value;
  }
 
}
