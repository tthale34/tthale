import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ServerMockService } from '../../services/WebAuthn/server-mock.service';
import { WebAuthnService } from '../../services/WebAuthn/web-authn.service';
import { NgxSpinnerService } from 'ngx-spinner';
@Component({
  selector: 'app-app-settings',
  templateUrl: './app-settings.component.html',
  styleUrls: ['./app-settings.component.scss']
})
export class AppSettingsComponent implements OnInit {
  settingsForm: FormGroup;
  webAuthnAvailable = !!navigator.credentials && !!navigator.credentials.create;
  email:string = 'elich@lum.co.za';
  users: any[];
  password:string = "test";
  appAuth:string;
  constructor(private spinner: NgxSpinnerService,private fb: FormBuilder,private serverMockService: ServerMockService, private webAuthnService: WebAuthnService) {
    this.settingsForm = fb.group({
      authMethod: ['', Validators.required],
      appSchemes: []
    });
  }



  ngOnInit(): void { 
    this.appAuth = localStorage.getItem("authMethod")
    if( this.appAuth  == null){
       localStorage.setItem('authMethod','appPassword');
       this.appAuth = localStorage.getItem("authMethod")
    }
    
  }


  submitForm() {  
    if(this.settingsForm.controls['authMethod'].value == 'deviceAuth'){ 
      this.enableDeviceAuth();
    }  
    else{
      localStorage.removeItem('users');;
      localStorage.setItem('authMethod',this.settingsForm.controls['authMethod'].value);
      alert("App Password has been set as authentication method")
    }
  }

 async enableDeviceAuth(){ 
    //localStorage.removeItem("users")  
    const prevUser = await this.serverMockService.getUser(this.email);
    if (prevUser) {
      alert('🚫 User already exists with this email address');
      return;
    }
    this.spinner.show();
    const user: any   = await this.serverMockService.addUser({ email: this.email, password: this.password, credentials: [] });
    this.users = await this.serverMockService.getUsers();
 
    if (this.webAuthnAvailable) {
     await  localStorage.setItem("authMethod", this.settingsForm.controls['authMethod'].value)
     await this.webAuthnService.webAuthnSignup(user)
        .then((credential: PublicKeyCredential) => {
          console.log('credentials.create RESPONSE', credential);
          const valid = this.serverMockService.registerCredential(user, credential);
          this.users = this.serverMockService.getUsers();
          this.spinner.hide();
          alert("You Biometric Login has been enabled");
        }).catch((error) => {
          this.spinner.hide();
          alert('credentials.create ERROR'+ error);
        });
    }else{
    alert("Device does not support biometric authentication")
    }
    this.spinner.hide();
  }

}
