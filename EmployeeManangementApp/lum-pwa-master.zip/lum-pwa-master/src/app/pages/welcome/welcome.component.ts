import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthenticationService } from 'src/app/services/authentication.service';
import { GlobalService } from 'src/app/helpers/globals';
import { ApiGatewayService } from 'src/app/services/api-gateway.service';
import { NgxSpinnerService } from "ngx-spinner";
import { GetUserdataService } from 'src/app/services/get-userdata.service';


@Component({
	selector: 'app-welcome',
	templateUrl: './welcome.component.html',
	styleUrls: ['./welcome.component.scss']
})
export class WelcomeComponent implements OnInit {
	private global_service: GlobalService;
	loggedInAs: boolean = false;
	brokerDashboardAccess: boolean = false;
	user: any = {
		Names: null,
		Surname: null,
		InsurerScheme: null,
		Insurer: null,
		Policy_ID: null,
		Premium: {
			ph_nett: null
		}
	};
  showpopup: boolean = true;
	rootObj: Array<any> = [];
	rootObjQuotes: Array<any> = [];
	AuthToken: any;
	show_testUsers: boolean = false;
  constructor(private activatedRoute: ActivatedRoute,private router: Router, private _authApi: AuthenticationService, private spinner: NgxSpinnerService, private _api: ApiGatewayService, private _userData: GetUserdataService) { }
	async ngOnInit() {
		this.user = await JSON.parse(localStorage.getItem('currentUser')).Data;
		console.log(this.user);

		if (this.user.UserName_New) {
			this.loggedInAs = true;
		} else {
			this.loggedInAs = false;
		}
		if (this.user.AccessLevel_ID != 6) {
			this.show_testUsers = true;
		} else {
			this.show_testUsers = false;
		}
		if (this.user.AccessLevel_ID == 2 || this.user.AccessLevel_ID == 3) {
			this.brokerDashboardAccess = true;
		} else {
			this.brokerDashboardAccess = false;
		}
		for (var key in this.user.PolicyItems) {
			if (this.user.PolicyItems.hasOwnProperty(key)) {
				this.rootObj.push(this.user.PolicyItems[key]);
			}
		}
		for (var key in this.user.QuoteItems) {
			if (this.user.QuoteItems.hasOwnProperty(key)) {
				this.rootObjQuotes.push(this.user.QuoteItems[key]);
			}
		}
		//await this.delete();
		await this.getLookUps();


    // if (this.showpopup = false) {
    //   document.getElementById("chatpopupbut").style.display = "none";
    //   document.getElementById("promptchatyes").style.display = "none";
    // }

		// if (this.AuthToken == null || this.AuthToken == undefined) {
		//   this.AuthToken = await localStorage.getItem('jwt');
		// }
		// //Refresh users data after removing
		// await this.spinner.show();
		// await this._api.refreshUserData(this.AuthToken).subscribe((res) => {
		// console.log(res);
		// this.spinner.hide();
		// }, err => {
		//   alert("Errors encountered"+err);
		// });
	}
	delete() { //temp solution
		if (this.activatedRoute.snapshot.queryParamMap.has('deleted')) {
			this.activatedRoute.snapshot.queryParamMap.get('pid')
			for (let i = 0; i < this.rootObj.length; i++) {
				for (let j = 0; j < this.rootObj[i].length; j++) {
					if (this.rootObj[i][j].PID == this.activatedRoute.snapshot.queryParamMap.get('pid')) {
						this.rootObj[i].splice(0, 2)
						var snapshot = this.activatedRoute.snapshot;
						const params = { ...snapshot.queryParams };
						delete params.pos
					}
				}
			}
		}

	}
	getMyPolicySection(PolicySectionID) {
		this._userData.setPolicySectionID(PolicySectionID);
		console.log('seting in welcome: ');
		this.router.navigate(['my-add-vehicle']);
	}
	callMeBack() {
		this._api.callMeBack().then(res => {
			if (res.Status)
				alert(res.Message)
			else {
				alert("Could not initiate your process, try again")
			}
		}).catch(err => {
			alert("Could not initiate your process, try again")
		})
	}

	async logOut() {
		localStorage.removeItem('email');
		localStorage.removeItem('token');
		localStorage.removeItem('userProfile');
		localStorage.removeItem('currentUser');
		localStorage.removeItem('lookUps');
		this._api.clearAuthToken()
		this._authApi.logout();
	}


	openNav() {
		document.getElementById("mySidenav").style.width = "250px";
		document.getElementById("main").style.marginLeft = "250px";
		document.body.style.backgroundColor = "rgba(0,0,0,0.4)";
	}

	closeNav() {
		document.getElementById("mySidenav").style.width = "0";
		document.getElementById("main").style.marginLeft = "0";
		document.body.style.backgroundColor = "white";

	}

	navigate(route: string) {
		this.router.navigate([route]);
		document.body.style.backgroundColor = "rgba(0,0,0,0.0)";
	}

	navigateEditQuote(PolicySectionID) {
		// alert(PolicySectionID);
		// this.router.navigate([route]);
		// document.body.style.backgroundColor = "rgba(0,0,0,0.0)";
	}

	moreItemInfo(item: any) {
		if (item == null) {
			this.router.navigate(['item-info'],
				{
					queryParams: { newItem: true }
				})
			return;
		}
		this.router.navigate(['item-info']
		).then(res => {
			localStorage.setItem('insuredItem', JSON.stringify(item));
		});
	}

	getLookUps() {
		// if(localStorage.getItem('lookUps') != undefined){
		this._api.getLookUps().then(res => {
			localStorage.setItem('lookUps', JSON.stringify(res));

			// var ask = confirm("Do you want to chat with us?");
			// if (ask) {
			// 	this.router.navigate(['helpchat']);

			// }
		})
		// }

	}
  chatFunctionYes() {
    this.showpopup = false;
    document.getElementById("chatpopupbut").style.display = "none";
    document.getElementById("promptchatyes").style.display = "none";
    this.router.navigate(['helpchat']);

  }
  chatFunctionNo() {
    this.showpopup = false;
    document.getElementById("chatpopupbut").style.display = "none";
    document.getElementById("promptchatyes").style.display = "none";
    this.router.navigate(['welcome']);

  }
	changeItemInfo() {
		this.router.navigate(['change-item-info']);
	}
	switchUser() {
		this.router.navigate(['broker-advisor-view']);
	}


}
