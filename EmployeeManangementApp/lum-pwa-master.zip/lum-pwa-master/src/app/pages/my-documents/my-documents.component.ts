import { Component, OnInit } from '@angular/core';
import { ApiGatewayService } from 'src/app/services/api-gateway.service';
import { NgxSpinnerService } from "ngx-spinner";
import { Router } from '@angular/router';
import { ModalDismissReasons, NgbModal } from '@ng-bootstrap/ng-bootstrap';
@Component({
  selector: 'app-my-documents',
  templateUrl: './my-documents.component.html',
  styleUrls: ['./my-documents.component.scss']
})
export class MyDocumentsComponent implements OnInit {
  myDocuments: any;

  additionalData = {
    dateFrom: '',
    dateTo: '',
    vehId: 0,
    buildingID: 0,
    trailerCaravanID: 0,
    motorcycleID: 0,
    isBuidlingConfirmationCover: true,
    itemID: 0,
    dataKey: 0
  }
  closeResult = '';
  motorVehicles: Array<any> = [];
  myBuildings: Array<any> = [];
  myMotorcycles: Array<any> = [];
  trailerCaravans: Array<any>= [];
  docType: string;
  selectedGroupProduct: string = 'buidling';
  constructor(private modalService: NgbModal, private spinner: NgxSpinnerService, private _api: ApiGatewayService, private router: Router) { }

  async ngOnInit() {
    let items = await JSON.parse(localStorage.getItem('currentUser'))
    this.motorVehicles = await items.Data.PolicyItems['2'];
    this.myBuildings = await items.Data.PolicyItems['1'];
    this.trailerCaravans = await items.Data.PolicyItems['8'];
    this.myMotorcycles = await items.Data.PolicyItems['3'];
    this.additionalData.vehId = this.motorVehicles[0].PID;
    this.additionalData.buildingID = this.myBuildings[0].PID;
    this.additionalData.trailerCaravanID = this.trailerCaravans[0].PID;
    this.additionalData.motorcycleID = this.myMotorcycles[0].PID;

    this.additionalData.itemID = this.additionalData.buildingID;
    this.additionalData.dataKey = this.additionalData.buildingID;

    /*
    await this.spinner.show();
    await this._api.getClientDocuments().then(res => {
      if (res.Status)
        this.myDocuments = res.Result.Data;
      else {
        alert("Could not retrive your documents, try again later");
        this.router.navigate(['welcome']);
      }
    }).catch(err => {
      alert("Could not retrive your documents, try again later");
      this.router.navigate(['welcome']);
    })
    await this.spinner.hide();*/
  }

  open(content) {
    this.modalService.open(content, { ariaLabelledBy: 'modal-basic-title' }).result.then((result) => {
      //this.closeResult = `Closed with: ${result}`;
      this.closeResult = result;
      let apiCall = null;

      delete this.additionalData.vehId
      delete this.additionalData.buildingID
      delete this.additionalData.isBuidlingConfirmationCover
      // this.additionalData.dataKey = result.dataKey;
      //console.log(this.additionalData)


      apiCall = this._api.getDocuments(this.docType, this.additionalData);
      if (this.selectedGroupProduct == 'motorVehicle' && this.docType != "taxItem") {
        apiCall = this._api.getDocuments('coverConfirmationVeh', this.additionalData);
      } else if (this.selectedGroupProduct == 'caravanTrailer' && this.docType != "taxItem") {
        apiCall = this._api.getDocuments('coverConfirmationcaravantrailer', this.additionalData);
      } else if (this.selectedGroupProduct == 'motorcycle' && this.docType != "taxItem") {
        apiCall = this._api.getDocuments('coverConfirmationMotorcycle', this.additionalData);
      }

      this.spinner.show();
      apiCall.subscribe(res => {
          if (res.Status) {
            alert(res.Message)
            this.spinner.hide();
          }
          else {
            alert(res.Message)
            this.spinner.hide();
          }
        }, err => {
          alert('Could not process your request');
          this.spinner.hide();
        })
    }, (reason) => {
      this.spinner.hide();
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }

  onItemChange(value) {
    this.selectedGroupProduct = value;
    if (value == 'buidling') {
      this.additionalData.dataKey = 0;
      // this.additionalData.dataKey = this.myBuildings[0].PID;
      this.additionalData.itemID = this.myBuildings[0].PID;
      this.additionalData.isBuidlingConfirmationCover = true;
    }else if(value == 'caravanTrailer') {
      this.additionalData.dataKey = 0;
      // this.additionalData.dataKey = this.trailerCaravans[0].PID;
      this.additionalData.itemID = this.trailerCaravans[0].PID;
      this.additionalData.isBuidlingConfirmationCover = false;
    }else if(value == 'motorcycle') {
      this.additionalData.dataKey = 0;
      // this.additionalData.dataKey = this.myMotorcycles[0].PID;
      this.additionalData.itemID = this.myMotorcycles[0].PID;
      this.additionalData.isBuidlingConfirmationCover = false;
    }else {
      this.additionalData.dataKey = 0;
      // this.additionalData.dataKey = this.motorVehicles[0].PID;
      this.additionalData.itemID = this.motorVehicles[0].PID;
      this.additionalData.isBuidlingConfirmationCover = false;
    }

  }

  caravanTrailerItemChange(value) {
    this.additionalData.trailerCaravanID = value;
    this.additionalData.itemID = value
    this.additionalData.dataKey = value
  }

  motorcycleChange(value) {
    this.additionalData.motorcycleID = value;
    this.additionalData.itemID = value;
    this.additionalData.dataKey = value;
  }

  myBuidlingItemChange(value) {
    this.additionalData.buildingID = value;
    this.additionalData.itemID = value
    this.additionalData.dataKey = value
  }

  vehicleChange(value) {
    this.additionalData.vehId = value;
    this.additionalData.itemID = value;
    this.additionalData.dataKey = value;
  }

  async goToDocs(value) {
    if (value == 'taxPolicy' || value == 'borderLetter' || value == 'taxItem' || value == 'coverConfirmation') {
      this.docType = value;
      this.selectedGroupProduct = 'buidling'
      if (value == 'borderLetter') {
        this.additionalData.dataKey = this.motorVehicles[0].PID;
        this.additionalData.itemID = this.motorVehicles[0].PID;
      }
      document.getElementById('mod').click();
      return;
    }
    if (value == 'document-history') {
      this.router.navigate(['document-history']);
      return;
    }

    await this.spinner.show();
    await this._api.getDocuments(value).subscribe(res => {
      if (res.Status) {
        alert(res.Message)
        this.spinner.hide();
      }
      else {
        alert(res.Message)
        this.spinner.hide();
      }
    }, err => {
      alert('Could not process your request');
      this.spinner.hide();
    })


  }

}
