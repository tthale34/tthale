import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { ApiGatewayService } from 'src/app/services/api-gateway.service';

@Component({
  selector: 'app-history-documents',
  templateUrl: './history-documents.component.html',
  styleUrls: ['./history-documents.component.scss']
})
export class HistoryDocumentsComponent implements OnInit {
  myDocuments:any;
  constructor(private router:Router,private _api:ApiGatewayService,private spinner: NgxSpinnerService) { }

  async ngOnInit() {
    await this.spinner.show();
    await this._api.getClientDocumentHistory().then(res=>{
      if(res.Status)
      console.log(this.myDocuments =  res.Result.Data)
      //console.log('got docs')
      else
      alert(res.Message) 
      this.spinner.hide()
    }).catch(err=>{
      this.router.navigate(['my-documentsS']);
      alert('Could not process your request, please try again')
      this.spinner.hide()
    })
    this.spinner.hide()
  }

}
