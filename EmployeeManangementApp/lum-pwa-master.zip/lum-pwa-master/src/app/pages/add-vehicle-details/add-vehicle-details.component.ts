import { Component, OnInit } from '@angular/core';
import { ApiGatewayService } from 'src/app/services/api-gateway.service';
import { NgxSpinnerService } from "ngx-spinner";
import { ActivatedRoute,Router } from '@angular/router';
import { ReturnStatement } from '@angular/compiler';

@Component({
  selector: 'app-add-vehicle-details',
  templateUrl: './add-vehicle-details.component.html',
  styleUrls: ['./add-vehicle-details.component.scss']
})
export class AddVehicleDetailsComponent implements OnInit {
  bankList = [];
  bankListObj: any = {};
  vehicleRegDet = {
    VehicleRegistrationNumber:'',
    VehicleVIN:'',
    VehicleEngineNumber:'',
    Bank_ID:0,
    FinanceAccountNumber:'',
    DateCoverStart:new Date().toISOString().slice(0, 10),
    PolicySectionID:0,
    Policy_ID:0,
  };
  constructor(private _api: ApiGatewayService,private router: Router,private route: ActivatedRoute,private spinner: NgxSpinnerService) { }

  async ngOnInit() {
    if(this.route.snapshot.queryParamMap.get('jwt')){
      await this.spinner.show();
      await this._api.getPolicyItem(this.route.snapshot.queryParamMap.get('jwt')).then(res => {
        this.vehicleRegDet.PolicySectionID = res.PolicySectionID;
        this.vehicleRegDet.Policy_ID = res.Policy_ID;
        console.log('Item is: '+this.vehicleRegDet.PolicySectionID );
        console.log(res);
        }).catch(err => {console.log(err);});
      this.spinner.hide();
    }

    this.spinner.show();
    await this._api.getBankList().then(res => {
      console.log(res);
      this.bankListObj = res;
      for (let key in this.bankListObj){
        if (this.bankListObj.hasOwnProperty(key)){
          this.bankList.push(this.bankListObj[key]);
        }
      }
    console.log(this.bankList);
    this.spinner.hide();
    }).catch(err => {
    alert(err);
    this.spinner.hide();
    })
    console.log("Bank List Object:");
    console.log(this.bankListObj);
    
  }
  async SaveVehicle(){
    console.log(this.vehicleRegDet);
    if(this.vehicleRegDet.VehicleRegistrationNumber =="" || 
      this.vehicleRegDet.VehicleVIN=="" || 
      this.vehicleRegDet.VehicleEngineNumber=="" || 
      this.vehicleRegDet.Bank_ID ==0 ||
      this.vehicleRegDet.FinanceAccountNumber ==""){
        alert("Please make sure you have entered all fields.");
        return;
    }
      await this.spinner.show();
      await this._api.saveRegDetails(this.vehicleRegDet).then(res => {
        console.log(res);
          }).catch(err => {
          alert(err);
        })
        alert('Your vehicle details have been saved.');
      this.spinner.hide();
      this.router.navigate(['welcome']);
    // }else{
    //   alert('Please select a valid cover start date.');
    // }
    this.spinner.hide();
  }
  nav(){
    this.router.navigate(['welcome'])
  }
}
