import { Component, OnInit } from '@angular/core';
import { AlertService } from 'src/app/components/alert/alertService/alert-service.service';
import { ApiGatewayService } from 'src/app/services/api-gateway.service';
@Component({
  selector: 'app-sos',
  templateUrl: './sos.component.html',
  styleUrls: ['./sos.component.scss']
})
export class SosComponent implements OnInit {
  sosTel: any = '';
  namolaTel: any = '0872503190';
  user: any;
  constructor(private confirmationDialogService: AlertService, private _api: ApiGatewayService) { }

  async ngOnInit() {
    this.user = await JSON.parse(localStorage.getItem('currentUser')).Data;
    if (this.user.AssistYN == 'Y')
      this.sosTel = await this.user.AssistTel;
  }

  async requestSOS(sosType: string) {
    
    this._api.logAssistCall();
    
    if (this.user.AssistYN != 'Y') {
      await this.confirmationDialogService.confirm('Please confirm', 'You are not a member, but we will gladly assist. Costs may be incurred.Proceed with call?')
        .then((confirmed) => {
          if (confirmed){ 
            document.location.href = "tel:" + this.user.AssistTel
        }
          else { 
            return;
          }
        })
        .catch(() => console.log('User dismissed the dialog (e.g., by using ESC, clicking the cross icon, or clicking outside the dialog)'));
    }
    else {
      document.location.href = "tel:" + this.user.AssistTel
    }
  }
}
