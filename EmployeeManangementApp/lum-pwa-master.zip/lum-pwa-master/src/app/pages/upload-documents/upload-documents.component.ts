import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ApiGatewayService } from 'src/app/services/api-gateway.service';
import { NgxSpinnerService } from 'ngx-spinner';


@Component({
  selector: 'app-upload-documents',
  templateUrl: './upload-documents.component.html',
  styleUrls: ['./upload-documents.component.scss']
})
export class UploadDocumentsComponent implements OnInit {
  params = {
    jwt:'',
    fileToUpload: File = null,
    doctype:'',
    ClaimID:0,
    documentList:[],
  }

  constructor(private spinner: NgxSpinnerService,private router: Router,private route: ActivatedRoute,private _api: ApiGatewayService) { }

  ngOnInit(): void {
    this.route.queryParams.subscribe(params=>{
      this.params.jwt =params['jwt'];
      this.params.ClaimID =params['ClaimID'];
    });
  }
  onFileSelect(event) {
    this.params.fileToUpload= event.target.files[0];
  }
  async onSubmit() {
    if (this.params.documentList.length == 0) {
      alert("Please make sure you have add the documents");
      return;
    }

    await this.spinner.show();
    console.log("params");
    console.log(this.params);
      this._api.postUpload(this.params).then(res => {
        console.log(res)
        if(res.Status){
          alert(res.Message);
          this.spinner.hide();
          this.router.navigate(['welcome']);
        }
        else{
          this.spinner.hide();
          alert(res.Message)
        }
      }).catch(err=>{
        this.spinner.hide();
        console.log(err);
        alert(err);
      });
  }
  validateDoc(){
    if (this.params.fileToUpload == null) {
      alert("Please make sure you have selected a file");
      return false;
    }
    if (this.params.doctype == "") {
      alert("Please make sure you have selected a document type");
      return false;
    }
    return true;
  }
  addDocument(){
    if(this.validateDoc()){
      this.params.documentList.push({id:this.params.documentList.length,doc:this.params.fileToUpload,docName:this.params.fileToUpload.name,docType:this.params.doctype});
      this.params.fileToUpload = null;
      this.params.doctype = '';
    }
  }
  removeDocument(id){
    this.params.documentList = this.params.documentList.filter(item => item.id !== id);
  }
}
