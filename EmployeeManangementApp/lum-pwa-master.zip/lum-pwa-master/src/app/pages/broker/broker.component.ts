import { Component, OnInit } from '@angular/core';
import { ApiGatewayService } from 'src/app/services/api-gateway.service';
import { NgxSpinnerService } from "ngx-spinner";
@Component({
  selector: 'app-broker',
  templateUrl: './broker.component.html',
  styleUrls: ['./broker.component.scss']
})
export class BrokerComponent implements OnInit {
  brokerDetails: any;
  constructor(private spinner: NgxSpinnerService, private _api: ApiGatewayService) { }

  ngOnInit(): void {
    this.brokerDetails = JSON.parse(localStorage.getItem('currentUser'))
    this.brokerDetails = this.brokerDetails.Data; 
    console.log(this.brokerDetails)
  }

  async contactAction(action?) {
    await this.spinner.show();
    switch (action) {
      case 'callMe':
        await this._api.callMe().then(res => {
          console.log(res)
          if (res.Status)
            alert(res.Message)
          else
            alert("Could not process your request, please try again later")
        })
        this.spinner.hide()
        break;
      case 'email': 
          document.getElementById('emailModal').style.display=  'block' ; 
        this.spinner.hide()
        break;
      default:
        this.spinner.hide()
        break;
    }

  }

}
