import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { ApiGatewayService } from 'src/app/services/api-gateway.service';

@Component({
  selector: 'app-my-profile',
  templateUrl: './my-profile.component.html',
  styleUrls: ['./my-profile.component.scss']
})
export class MyProfileComponent implements OnInit {
  user: any = {};
  editDetails = {
    cellNumber: '',
    emailAddress: ''
  }
  constructor(private spinner: NgxSpinnerService, private router: Router, private _api: ApiGatewayService) { }

  async ngOnInit() {
    this.user = await JSON.parse(localStorage.getItem('currentUser')).Data || null;
    if (this.user == null) {
      this.router.navigate(['welcome']);
      return;
    }
    console.log(this.user)
  }

  async submit() {
    await this.spinner.show();
    this.editDetails.cellNumber = await this.user.ClientCell;
    this.editDetails.emailAddress = await this.user.ClientEmail;

    this._api.updateProfile(this.editDetails).then(res => {
      if (res.Status) {
        alert(res.Message)
        this.router.navigate(['welcome']);
      } else
        alert('We could not process your request now, try again') 
      this.spinner.hide()

    }).catch(err => {
      this.spinner.hide()
      alert('We could not process your request now, try again')
    })


  }

  nav() {
    this.router.navigate(['welcome']);

  }
}
