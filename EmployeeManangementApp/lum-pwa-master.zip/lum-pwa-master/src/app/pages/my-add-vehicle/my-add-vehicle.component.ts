import { Component, OnInit, Renderer2, ViewChild , ElementRef } from '@angular/core';
import { ApiGatewayService } from 'src/app/services/api-gateway.service';
import { ActivatedRoute,Router } from '@angular/router';
import { NgxSpinnerService } from "ngx-spinner";
import { HttpBackend, HttpClient ,HttpParameterCodec} from '@angular/common/http';
import { GetUserdataService } from 'src/app/services/get-userdata.service';

import { GlobalService } from '../../helpers/globals';
import { NgForm } from '@angular/forms';
import {formatDate} from '@angular/common';

@Component({
  selector: 'app-my-add-vehicle',
  templateUrl: './my-add-vehicle.component.html',
  styleUrls: ['./my-add-vehicle.component.scss']
})
export class MyAddVehicleComponent implements OnInit {
  @ViewChild('dent') dent: ElementRef;
  @ViewChild('credit') credit: ElementRef;
  @ViewChild('luxuryCover') luxuryCover: ElementRef;
  @ViewChild('locksKeys') locksKeys: ElementRef;
  @ViewChild('carSound') carSound: ElementRef;
  @ViewChild('carHire') carHire: ElementRef;

  private global_service = new GlobalService();
  PolicySectionIDEdit ="";

  vehicleDetails = {
    currentYear:'2007',
    user: {"ID":"1","Value":"Test"},
    regName:'Reg',
    Suburb:'Pretoria',
  };
  TrackerCompany_ID:0;
  ElectronicTrackerManufacturer:'';
  Make:'';
  AdditionalOtherDesc:'';
  showLCPrefixFields:boolean=false;
  vehicleMakes = [];
  vehicleYear = [];
  vehicleModels = [];
  bankList = [];
  bankListObj: any = {};
  policySectiontObj: any = {};
  policySectionEdit = [];
  currentYear:Date;
  user: any = {};
  regName:string =""
  Suburb = "";
  Suburbs = [];
  CitiesIDs = [];
  Cities = [];
  showRegOwner = false;
  showRegDriver = false;
  showCarRadioAmount = false;
  showLocksAmount = false;
  showCSAmount = false;
  monthlyPremium ="";
  reCalculatePremium = false;
  showFinalSteps= false;
  showFinalFields=false;
  showAdditionals = false;
  showSubmitBottom = false;
  showSubmit =false;
  currentDate=Date.now();
  currentDateString= "";
  DriverofVehicle:string ="";
  DriverInitials:string ="";
  DriverBirthDate:string ="";
  DriverLicenceIssueDate:string ="";
  formVals = [];
  retailValue:string = "";
  retailValueArray:any = {};
  retailCounter:number = 0;
  soundInsuredMin="5000";
  lockInsuredMin="7500";
  suburID = "0";
  excessArray = [];
  showCarHire = false;
  showSound = false;
  showLocks = false;
  show4x4 =false;
  showCS = false;
  showDent = false;
  showCarHireStyle= "btn btn-danger";
  showSoundStyle = "btn btn-danger";
  showLocksStyle = "btn btn-danger";
  show4x4Style = "btn btn-danger";
  showCSStyle = "btn btn-danger";
  showDentStyle = "btn btn-danger";
  PreQuoteClaimsCountMotor:0;
  emailPayLoad = {
    mailMessage: '',
    subject: '',
    ccList: '',
    copyMe: false
  };
  newItem = {
    itemDescNewItem: null,
    itemAMTNewItem: null,
    itemType: 'Motor Vehicle'
  }
  PolicySectionID =0;
  showCantFind = true;
  formaction = "Add";
  edit_sub_name:string="";
  edit_veh_make= ""; //"20079"
  edit_veh_model ="";
  edit_veh_year ="";
  edit_IsPolicyHolderYN="";
  edit_VehicleRegisteredInNameOf="";
  edit_IsRegularDriverYN = "Y";
  FinancingYN= "N";
  edit_DriverLicenceIssueYear ="";
  DriverLicenceIssueYear ="";
  edit_CoverType_ID = "";
  edit_VehiclePurpose_ID ="";
  edit_OverNightParking_ID = "";
  edit_ElectronicTrackerYN ="";
  ElectronicTrackerYN ="";
  edit_city_id = "";
  LuxuryOr4x4Cover_ID="N";
  CarRentalYN="";
  edit_M1Option_ID ="";
  edit_VehicleRadioYN = "";
  VehicleRadioYN = "N";
  edit_LocksKeysYN ="";
  LocksKeysYN ="";
  edit_OMI4x4And4x2YN ="";
  OMI4x4And4x2YN ="N";
  edit_creditShortfallCS = "";
  creditShortfallCS = "";
  edit_R_OutStandingHirePurchaseAmount ="";
  R_OutStandingHirePurchaseAmount ="";
  R_MotorvehicleKeysAmount="";
  R_RadioInsuredAmount ="";
  edit_SmartOption_ID = "";
  SmartOption_ID="";
  LastClaim_ID="";
  edit_R_AdditionalOtherAmount = 0;
  edit_ExcessOption_ID:number = 2500;
  ExcessOption_ID:10;
  ExcessRand:number=3;
  edit_suburbIDLIST = [];
  url = 'https://mypolicy.lum.co.za/api/api/getVehicleMakes.php';
  extraItems:Array<any> =[];
  TrackingCompanies:Array<any> =[];
  extraItem:any;
  extraValue:any;
  extrasTotal:number=0;
  User_ID:0;
  Policy_ID:0;
  AuthToken:any;
  MMCode:any;
  showAdditionOtherDesc:boolean = false;
  getVehicleInfo= {
    VehicleMakeID:0,
    VehicleYear:0, 
    VehicleModelID:0
  }
  myPolicySectionID:0;
  constructor(private http: HttpClient, private _api: ApiGatewayService, private router: Router,private _userData: GetUserdataService,private renderer: Renderer2, private spinner: NgxSpinnerService, private route: ActivatedRoute) {
      this.http.get(this.url).toPromise().then(
        data => {
          console.log(data);
          for (let key in data)
            if (data.hasOwnProperty(key))
              this.vehicleMakes.push(data[key]);
        }
      );
      var d = new Date();
      var n = d.getFullYear();
      this.currentDateString = formatDate(new Date(), 'yyyy-MM-dd', 'en');
      for (let yearval = n; yearval >= 1960; yearval--){
        this.vehicleYear.push(yearval);
      }
      this.excessArray.push('2000');
      for (let excessVal = 5000; excessVal <= 10000; excessVal+=2500){
        this.excessArray.push(excessVal);
      }
   }
   async ngOnInit() {
    this.TrackingCompanies = await JSON.parse( localStorage.getItem('lookUps')).l_trackercompany;
    this.myPolicySectionID= await this._userData.getPolicySectionID();
    if(this.route.snapshot.queryParamMap.get('jwt')){
      await this.spinner.show();
      await this._api.getPolicyItem(this.route.snapshot.queryParamMap.get('jwt')).then(res => {
        this.myPolicySectionID = res.PolicySectionID;
        this.setEditFormValues();
          if (res.Status) {
            console.log(res.Message);
          }
        }).catch(err => {console.log(err);});
      this.spinner.hide();
    }else{
      if(this.myPolicySectionID != null){
        this.setEditFormValues();
      }
    }
    this.user = await JSON.parse(localStorage.getItem('currentUser')).Data;
    
    this.User_ID = this.user.User_ID;
    this.Policy_ID = this.user.Policy_ID;
    console.log(this.user);
    if(this.user.Insurer_ID == "1") // Santam
    {
        this.soundInsuredMin="5000";
        this.lockInsuredMin="7500";
    }
    if(this.user.Insurer_ID == "2") // Hollard
    {
      this.soundInsuredMin="5000";
      this.lockInsuredMin="7500";
    }
    this.renderer.setStyle(this.carHire.nativeElement, 'display', 'none');
    this.renderer.setStyle(this.carSound.nativeElement, 'display', 'none');
    this.renderer.setStyle(this.locksKeys.nativeElement, 'display', 'none');
    this.renderer.setStyle(this.luxuryCover.nativeElement, 'display', 'none');
    this.renderer.setStyle(this.credit.nativeElement, 'display', 'none');
    this.renderer.setStyle(this.dent.nativeElement, 'display', 'none');
    this.showAddOtherDesc();
    if(JSON.parse(localStorage.getItem('currentUser')).Data.PolicyPrefix === "LC"){
      this.showLCPrefixFields= true;
    }else{
      this.showLCPrefixFields= false;
    }
  }
  showAddOtherDesc(){
    if (this.edit_R_AdditionalOtherAmount > 0) {
      this.showAdditionOtherDesc = true;
    } else {
      this.showAdditionOtherDesc = false;
    }
  }
  uploadTrackingCert(){
    if (this.AuthToken == null || this.AuthToken == undefined) {
      this.AuthToken = localStorage.getItem('jwt');
    } 
    window.open(this.global_service.baseUrl.substring(0,this.global_service.baseUrl.length-4)+"/upload-documents?jwt="+this.AuthToken);
  }
   // this fuction will get the variables from the policy section id
   async setEditFormValues(){
    let PolicySectionID = this.myPolicySectionID;
      this.formaction = "Edit";
      await this._api.getPolicySection(PolicySectionID).then(res => {
        this.policySectiontObj = res;
        this.PolicySectionIDEdit = ""+PolicySectionID;
        this.getSuburbName(res[PolicySectionID].InsuredAddressSuburb_ID);
        this.edit_veh_make = res[PolicySectionID].VehicleMake_ID;
        this.edit_veh_year = res[PolicySectionID].YearModel;
        this.edit_veh_model = res[PolicySectionID].VehicleModel_ID;
        this.setVehicleModels(this.edit_veh_make, this.edit_veh_year);
        this.setRetailValue(this.edit_veh_make,this.edit_veh_year,this.edit_veh_model);
        this.edit_IsPolicyHolderYN = res[PolicySectionID].IsPolicyHolderYN;
        this.edit_VehicleRegisteredInNameOf = res[PolicySectionID].edit_VehicleRegisteredInNameOf;
        this.DriverofVehicle = res[PolicySectionID].DriverofVehicle;
        this.DriverInitials = res[PolicySectionID].DriverInitials;
        this.DriverBirthDate = res[PolicySectionID].DriverBirthDate.toString().substring(0,4);
        this.edit_DriverLicenceIssueYear = res[PolicySectionID].DriverLicenceIssueDate.toString().substring(0,4);
        this.edit_CoverType_ID = res[PolicySectionID].CoverType_ID;
        this.edit_VehiclePurpose_ID = res[PolicySectionID].VehiclePurpose_ID;
        this.edit_OverNightParking_ID = res[PolicySectionID].OverNightParking_ID;
        this.ElectronicTrackerYN =  res[PolicySectionID].ElectronicTrackerYN;
        this.edit_city_id = res[PolicySectionID].InsuredAddressCity_ID;
        this.CarRentalYN = res[PolicySectionID].CarRentalYN;
        this.edit_M1Option_ID = res[PolicySectionID].M1Option_ID;
        this.R_OutStandingHirePurchaseAmount = res[PolicySectionID].R_OutStandingHirePurchaseAmount;
        this.OMI4x4And4x2YN = res[PolicySectionID].OMI4x4And4x2YN;
        this.LocksKeysYN = res[PolicySectionID].LocksKeysYN;
        this.R_MotorvehicleKeysAmount = res[PolicySectionID].R_MotorvehicleKeysAmount;
        this.R_RadioInsuredAmount = res[PolicySectionID].R_RadioInsuredAmount;
        // this.LastClaim_ID = res[PolicySectionID].LastClaim_ID;
        /* Start of extra items set*/
        if(this.CarRentalYN == "Y"){
          if(res[PolicySectionID].M1Option_ID == 1){
            this.extraItems.push({name:'Car Hire',value:'30 days Standard'});
          }
          if(res[PolicySectionID].M1Option_ID == 2){
            this.extraItems.push({name:'Car Hire',value:'60 days Standard'});
          }
          if(res[PolicySectionID].M1Option_ID == 3){
            this.extraItems.push({name:'Car Hire',value:'30 days Luxury'});
          }
          if(res[PolicySectionID].M1Option_ID == 4){
            this.extraItems.push({name:'Car Hire',value:'60 days Luxury'});
          }
        }                       
        if(res[PolicySectionID].VehicleRadioYN == "Y"){
          this.extraItems.push({name:'Car Sound',value:this.R_RadioInsuredAmount});
        }        
        if(res[PolicySectionID].LocksKeysYN == "Y"){
          this.extraItems.push({name:'Locks and Keys',value:this.R_MotorvehicleKeysAmount});
        }        
        if(res[PolicySectionID].OMI4x4And4x2YN == "Y"){
          this.extraItems.push({name:'4x4Cover',value:'Yes (R125 per month)'});
        }        
        if(res[PolicySectionID].creditShortfallCS == "Y"){
          this.extraItems.push({name:'Credit Shortfall',value:this.R_OutStandingHirePurchaseAmount});
        }        
        if(res[PolicySectionID].SmartOption_ID == "1"){
          this.extraItems.push({name:'Dent and Scratch',value:'Yes (additional R57 per month)'});
        }/* End of extra items set*/
        if(this.edit_M1Option_ID != "0"){
          this.showCarHirefunc();
        }
        this.edit_VehicleRadioYN = res[PolicySectionID].VehicleRadioYN;
        if(this.edit_VehicleRadioYN == "Y"){
          this.showSoundfunc();
        }
        this.edit_LocksKeysYN = res[PolicySectionID].LocksKeysYN;
        if(this.edit_LocksKeysYN == "Y"){
          this.showLocksfunc();
        }
        this.edit_OMI4x4And4x2YN = this.setBooloandYN(res[PolicySectionID].LuxuryOr4x4Cover_ID);
        // alert(this.edit_OMI4x4And4x2YN);
        if(this.edit_OMI4x4And4x2YN == "Y"){
          this.show4x4func();
        }
        this.edit_creditShortfallCS = res[PolicySectionID].OutStandingHirePurchaseYN;
        this.edit_R_OutStandingHirePurchaseAmount = res[PolicySectionID].R_OutStandingHirePurchaseAmount;
        if(this.edit_creditShortfallCS == "Y"){
          this.showCSfunc();
          this.setCSAmount('Y');

        }
        this.edit_SmartOption_ID = this.setBooloandYN(res[PolicySectionID].SmartOption_ID);
        if(this.edit_SmartOption_ID == "Y"){
          this.showDentfunc();
        }
        this.edit_ExcessOption_ID = res[PolicySectionID].ExcessOption_ID;
        this.edit_R_AdditionalOtherAmount = res[PolicySectionID].R_AdditionalOtherAmount;
        switch(this.edit_ExcessOption_ID) {
          case 11:
            // alert("case 11");
            this.edit_ExcessOption_ID = Math.round(res[PolicySectionID].ExcessRand);
            // code block
            break;
          default:
            // code block
        }
        if (res.Status) {
          alert(res.Message);
        }else{
          // alert("ELSE" + res.Message);
        }

      }).catch(err => {
      alert(err);
      });
    }
    setBooloandYN(tval){
      // alert(tval);
      var retval = "N";
      if(tval == "1"){
        retval = "Y";
      }
      // alert(retval);
      return retval;
    }
    async getSuburbName(Suburb_Day_Id)
    {
      // alert(Suburb_Day_Id);
      var suburbObj: any = {};
      // console.write(this.user)
      await this._api.getSuburbName(Suburb_Day_Id).then(res => {
        // alert(res);
        suburbObj = res;
      }).catch(err => {
        alert(err);
      });
      // alert("suburbObj Object:");
      console.log(suburbObj);
      // alert(suburbObj);
      var retval = "";
      for (let key in suburbObj){
        // alert(key);

          if (suburbObj.hasOwnProperty(key))
          {
            this.edit_suburbIDLIST.push(suburbObj[key]);
            this.edit_sub_name = suburbObj[key].Suburb2.toString();
            this.Suburbs = [this.edit_sub_name];
            this.getSuburbByName(this.edit_sub_name);
            // alert(suburbObj[key].Suburb2.toString());
          }
      }
      return retval;
    }
   async setVehicleModels(vehicleMakeID,vehicleYear){
      this.vehicleModels = [];
      this.showCantFind = true;
      this.url = "https://mypolicy.lum.co.za/api/api/getVehicleBrands.php?VehicleMakePID=" + vehicleMakeID + "&vehicleYear=" + vehicleYear;
      // alert(this.url);
      console.log(this.url);
      await this.spinner.show();
      await this.http.get(this.url).toPromise().then(
      data => {
        // console.log(data);
        for (let key in data)
          if (data.hasOwnProperty(key))
          {
            this.vehicleModels.push(data[key]);
            this.showCantFind = false;

          }
      }
      );
      await this.spinner.hide();
    console.log(this.vehicleModels);
  }

  setRegOwner(value){
      if(value == "N"){
        this.showRegOwner = true;
      }else{
        this.showRegOwner = false;
      }
  }
  setCarRadioAmount(value){
      if(value == "Y")
      {
        this.showCarRadioAmount = true;
      }else{
        this.showCarRadioAmount = false;
      }
  }
  setCarLocksAmount(value){
      if(value == "Y")
      {
        this.showLocksAmount = true;
      }else{
        this.showLocksAmount = false;
      }
  }
  setCSAmount(value){
      if(value == "Y"){
        this.showCSAmount = true;
      }else{
        this.showCSAmount = false;
      }
  }

  setRegDriver(value){
    console.log(this.user);
    
    if(value == "N"){
      this.showRegDriver = true;
      this.DriverofVehicle="";
      this.DriverInitials="";
      this.DriverBirthDate="";
    }else{
      this.showRegDriver = false;
      this.DriverofVehicle=this.user.Surname;
      this.DriverInitials=this.user.Initials;
      this.DriverBirthDate=this.user.DateOfBirth;
    }
  }


  // This function will populate the first retail value found in the amandm table.
  async setRetailValue(VehicleMakeID, VehicleYear, VehicleModelID){
    // alert('RETAL VALUE');
    this.retailValue = "";
    this.retailValueArray = [];
    this.retailCounter =0;
    // alert(VehicleMakeID + VehicleYear+ VehicleModelID);
    console.log(VehicleMakeID + VehicleYear+ VehicleModelID);
    // Check if all values are completed and the call the webservices
    if(VehicleModelID > 0 && VehicleYear > 0 && VehicleModelID > 0)
    {
      this.url = "https://mypolicy.lum.co.za/api/api/getRetailValue.php?VehicleMakeID=" + VehicleMakeID + '&VehicleYear=' + VehicleYear + "&VehicleModelID=" + VehicleModelID;
      console.log(this.url);
      this.http.get(this.url).toPromise().then(
        data => {
          // console.log(data);
          for (let key in data)
            if (data.hasOwnProperty(key))
              if(this.retailCounter == 0)
              {
                this.retailValueArray.push(data[key]);
                console.log(data[key].RetailPrice);
                this.retailValue = data[key].RetailPrice;
                // console.log(data[key].RetailPrice);
                this.retailCounter++;
                this.MMCode = data[key].MMCode;
              }
          }
      );
      this.getVehicleInfo.VehicleMakeID = VehicleMakeID;
      this.getVehicleInfo.VehicleYear = VehicleYear;
      this.getVehicleInfo.VehicleModelID = VehicleModelID;
      await this.spinner.show();
      await this._api.getVehicleInfo(this.getVehicleInfo).then(res => {        
        if(res){
          console.log(res)
          this.MMCode = res.MMCode;
          this.retailValue = res.RetailPrice;
          this.spinner.hide();
        }
        else{
          this.spinner.hide();
          alert('Could not process your request now, try again')
        }
      }).catch(err=>{
        this.spinner.hide();
        alert('Could not process your request now, try again');
      });
    }
    
  }
  getSuburbByName(suburb_name:string) {
    this.Suburbs = [];
    if(suburb_name.length >= 4)
    {
      // alert("getSuburbByName");
      this.Suburbs.push("Select Suburb");
      this.Suburbs.push("Select Suburb");
      this.Suburbs.push("Select Suburb");
      this.url = "https://mypolicy.lum.co.za/api/api/getSuburbs.php?suburb_name=" + encodeURIComponent(suburb_name);
      this.http.get(this.url).toPromise().then(
        data => {
          // console.log(data);
          for (let key in data)
            if (data.hasOwnProperty(key))
            {
              this.Suburbs.push(data[key]);
              this.CitiesIDs.push(data[key].City_ID);
            }
          }
        );
      // search suburb
      this.getCitiesBySuburbName(suburb_name);
      // console.log(this.CitiesIDs);
    }
  }

  setSuburb(suburbID=""){
    alert(suburbID);
  }
  getCitiesBySuburbName(suburbName=""){
    this.Cities = [];
    this.url = "https://mypolicy.lum.co.za/api/api/getCity.php?suburb_name=" +  encodeURIComponent(suburbName);
        this.http.get(this.url).toPromise().then(
          data => {
            // console.log(data);
            for (let key in data)
              if (data.hasOwnProperty(key))
              {
                this.Cities.push(data[key]);
              }
            }
          );        
  }
  getExcess(excess_value){
    alert('GetExcess');
  }
  getPremium(){
    console.log("GET PREMIUM");
    this.showSubmit = true;
    this.showFinalSteps = true;
    this.monthlyPremium ="";
    console.log(this.user);
    console.log("GET PREMIUM");
    // alert("getPremium");
  }
  showCarHirefunc()
  {
    this.showCarHire = !this.showCarHire;
    if(this.showCarHire == true)
    {
      this.showCarHireStyle= "btn btn-success";
    }else{
      this.showCarHireStyle= "btn btn-danger";
    }
  }
  showSoundfunc()
  {
    this.showSound = !this.showSound;
    if(this.showSound == true)
    {
      this.showSoundStyle= "btn btn-success";
    }else{
      this.showSoundStyle= "btn btn-danger";
    }
  }
  showLocksfunc(){
    this.showLocks = !this.showLocks;
    if(this.showLocks == true)
    {
      this.showLocksStyle= "btn btn-success";
    }else{
      this.showLocksStyle= "btn btn-danger";
    }
  }
  show4x4func(){
    this.show4x4 = !this.show4x4;
    if(this.show4x4 == true)
    {
      this.show4x4Style= "btn btn-success";
    }else{
      this.show4x4Style= "btn btn-danger";
    }
  }
  showCSfunc(){
    this.showCS = !this.showCS;
    if(this.showCS == true)
    {
      this.showCSStyle= "btn btn-success";
    }else{
      this.showCSStyle= "btn btn-danger";
    }
  }
  showDentfunc(){
    this.showDent = !this.showDent;
    if(this.showDent == true)
    {
      this.showDentStyle= "btn btn-success";
    }else{
      this.showDentStyle= "btn btn-danger";
    }
  }
  async findVehicleAction(f)
  {
    console.log(this.user);
    console.log(this.user.Policy_ID);
    var message = "Data error. The client could not find his Vehicle.  Policy Id:" + this.user.Policy_ID ;
    console.log(message);
    await this._api.sendComms(f, this.user,this.PolicySectionID,"cant_find_vehicle",message).then(res => {
      }).catch(err => {
      alert(err);
    });
    alert("Thank you. We will be in contact soon.");
    this.router.navigate(['welcome']);
    this.spinner.hide();
  }
  async nav(formval)
  {

    if(formval.valid==true)
    {
        // alert('Action to save 4 fields somewhere in the database.');
        await this._api.cancelVehicle(formval, this.user,this.PolicySectionID).then(res => {
            }).catch(err => {
            alert(err);
          })
          // alert('This vehicle has been added.')
      }


    this.router.navigate(['welcome'])
  }
  async submit() {

  }
  async onSubmit(formval:NgForm)
  {
    this.reCalculatePremium = true;
    await this.spinner.show();
    await this._api.submitVehicle(formval,this.user).then(res => {
        // console.log(res.CalcNettPremium);
        this.monthlyPremium = res.CalcNettPremium;
        this.PolicySectionID = res.PolicySectionID;
        if (res.Status) {
          alert(res.Message);
        }
      }).catch(err => {
      alert(err);
    });
    this.spinner.hide()
  }
  async yesAction(formval:NgForm , user: any)
  {
    // alert('Yes Action');
    this.getBankList();
    this.showFinalFields = true;
    this.showFinalSteps = false;

  }
  async noAction(formval:NgForm , user: any){
    this.showFinalFields = false;
    var message = 'V4: Dear Client your cover can only start once you provide the the necesary information to us.';
    await this._api.sendComms(formval, this.user,this.PolicySectionID,"send_client_sms",message).then(res => {
        }).catch(err => {
        alert(err);
      })
    // alert('SEND CLIENT SMS');
    console.log(this.user);
    var message2 = "V4: Dear Broker there are still outstanding information regarding a new vehicle on your client's policy. Policy Id: " + this.user.Policy_Id +".";
    await this._api.sendComms(formval, this.user,this.PolicySectionID,"send_broker_sms",message2).then(res => {
      }).catch(err => {
      alert(err);
    })
    // alert('Diarise outstanding information and send second SMS and E-mail within 24 hours.');  // TO BE DONE AS A CRON JOB WITH ADOLF
    alert('Please supply the missing information asap.');
    this.router.navigate(['welcome']);
  }
  async SaveVehicle(formval:NgForm , user: any){
    console.log(formval);
    console.log(user);
    console.log(this.PolicySectionID);
    if (this.currentDateString < formatDate(new Date(), 'yyyy-MM-dd', 'en')) {
      alert("Your request cannot be processed and someone will contact you.");
    }
    if(formval.valid){
        await this.spinner.show();
        await this._api.saveFourFields(formval, this.user,this.PolicySectionID).then(res => {
          console.log(res);
            }).catch(err => {
            alert(err);
          });
      }else{
        alert("Please complete compulsory fields.");
        this.spinner.hide();
        return 0;
      }
    // var checkVal:boolean = true;
    // if(formval.form.controls['cover_start_date'].value.toString() >= this.currentDateString.toString() && checkVal){
      await this.spinner.show();
      this._api.saveVehicle(formval, this.user,this.PolicySectionID).then(res => {
        console.log(res);
          }).catch(err => {
          alert(err);
        })
        alert('Your vehicle has been added to the policy. Further correspondence will follow.');
      this.spinner.hide();
      this.router.navigate(['welcome']);
    // }else{
    //   alert('Please select a valid cover start date.');
    // }
    this.spinner.hide();
  }
  async getBankList()
  {
    console.log("GET BANK LIST");
    await this._api.getBankList().then(res => {
      console.log("BANK LIST RES:");
      console.log(res);
      this.bankListObj = res;
      if (res.Status) {
        // alert(res.Message);
      }
      else
      {
        // alert("ELSE" + res.Message);
      }

    }).catch(err => {
    alert(err);
    })
    console.log("Bank List Object:");
    console.log(this.bankListObj);
    for (let key in this.bankListObj){
        if (this.bankListObj.hasOwnProperty(key)){
          this.bankList.push(this.bankListObj[key]);
        }
    }
    console.log("BANKLIST ARRAY:");
    console.log(this.bankList);
    this.spinner.hide();
  }
  async archiveVehicle(formval:NgForm , user: any)
  {
    // this case is a quote
    this._api.keepQuote(formval, this.user,this.PolicySectionID).then(res => {

      }).catch(err => {
      alert(err);
    })
    //Refresh users data after removing an policy item
    if (this.AuthToken == null || this.AuthToken == undefined) {
      this.AuthToken = await localStorage.getItem('jwt');
    }    
    await this.spinner.show();
    await this._api.refreshUserData(this.AuthToken).subscribe((res) => {
    console.log(res);
    location.reload();
    location.reload();
    }, err => {
      alert("Errors encountered"+err);
    });
    alert('Quote archived.');
    this.router.navigate(['welcome']).then(() => {
      window.location.reload();
    });
  }

  displayAddToMyPolicyActions(formval:NgForm , user: any)
  {
    this.showFinalSteps = true;
    this.showSubmitBottom = true;
  }
  isVehicleFinanced(){
    if(this.FinancingYN != ""){
      this.FinancingYN="Y"
    }else{
      this.FinancingYN="N"
    }
    
  }
  selectExtras(value){
    if (value == "Car Hire") {
      this.renderer.setStyle(this.carHire.nativeElement, 'display', 'inline');
      this.renderer.setStyle(this.carSound.nativeElement, 'display', 'none');
      this.renderer.setStyle(this.locksKeys.nativeElement, 'display', 'none');
      this.renderer.setStyle(this.luxuryCover.nativeElement, 'display', 'none');
      this.renderer.setStyle(this.credit.nativeElement, 'display', 'none');
      this.renderer.setStyle(this.dent.nativeElement, 'display', 'none');
    }
    if (value == "Car Sound") {
      this.renderer.setStyle(this.carHire.nativeElement, 'display', 'none');
      this.renderer.setStyle(this.carSound.nativeElement, 'display', 'inline');
      this.renderer.setStyle(this.locksKeys.nativeElement, 'display', 'none');
      this.renderer.setStyle(this.luxuryCover.nativeElement, 'display', 'none');
      this.renderer.setStyle(this.credit.nativeElement, 'display', 'none');
      this.renderer.setStyle(this.dent.nativeElement, 'display', 'none');
    }
    if (value == "Locks and Keys") {
      this.renderer.setStyle(this.carHire.nativeElement, 'display', 'none');
      this.renderer.setStyle(this.carSound.nativeElement, 'display', 'none');
      this.renderer.setStyle(this.locksKeys.nativeElement, 'display', 'inline');
      this.renderer.setStyle(this.luxuryCover.nativeElement, 'display', 'none');
      this.renderer.setStyle(this.credit.nativeElement, 'display', 'none');
      this.renderer.setStyle(this.dent.nativeElement, 'display', 'none');
    }
    if (value == "4x4Cover") {
      this.renderer.setStyle(this.carHire.nativeElement, 'display', 'none');
      this.renderer.setStyle(this.carSound.nativeElement, 'display', 'none');
      this.renderer.setStyle(this.locksKeys.nativeElement, 'display', 'none');
      this.renderer.setStyle(this.luxuryCover.nativeElement, 'display', 'inline');
      this.renderer.setStyle(this.credit.nativeElement, 'display', 'none');
      this.renderer.setStyle(this.dent.nativeElement, 'display', 'none');
    }
    if (value == "Credit Shortfall") {
      this.renderer.setStyle(this.carHire.nativeElement, 'display', 'none');
      this.renderer.setStyle(this.carSound.nativeElement, 'display', 'none');
      this.renderer.setStyle(this.locksKeys.nativeElement, 'display', 'none');
      this.renderer.setStyle(this.luxuryCover.nativeElement, 'display', 'none');
      this.renderer.setStyle(this.credit.nativeElement, 'display', 'inline');
      this.renderer.setStyle(this.dent.nativeElement, 'display', 'none');
    }
    if (value == "Dent and Scratch") {
      this.renderer.setStyle(this.carHire.nativeElement, 'display', 'none');
      this.renderer.setStyle(this.carSound.nativeElement, 'display', 'none');
      this.renderer.setStyle(this.locksKeys.nativeElement, 'display', 'none');
      this.renderer.setStyle(this.luxuryCover.nativeElement, 'display', 'none');
      this.renderer.setStyle(this.credit.nativeElement, 'display', 'none');
      this.renderer.setStyle(this.dent.nativeElement, 'display', 'inline');
    }
  }
  addExtra(){
    //User Input validation for adding extras items
    if (this.extraItem == null) {
      alert("Please make sure you have entered the extra item");
      return;
    }
    for (let i = 0; i < this.extraItems.length; i++) {
      if (this.extraItems[i].name == this.extraItem) {
        alert("Item already exists");
        return;
      }      
    }
    let itemValue:any;
    if (this.extraItem == "Car Hire") {
      if(this.edit_M1Option_ID == "0"){
        itemValue = "No";
      }
      if(this.edit_M1Option_ID == "1"){
        itemValue = "30 days Standard";
      }
      if(this.edit_M1Option_ID == "2"){
        itemValue = "60 days Standard";
      }
      if(this.edit_M1Option_ID == "3"){
        itemValue = "30 days Luxury";
      }
      if(this.edit_M1Option_ID == "4"){
        itemValue = "60 days Luxury";
      }
    }
    if (this.extraItem == "Car Sound") {
      if(this.VehicleRadioYN == "N"){
        itemValue = "No";
      }
      if(this.VehicleRadioYN == "10000"){
        itemValue = "Increase to R10,000";
      }
      if(this.VehicleRadioYN == "15000"){
        itemValue = "Increase to R15,000";
      }
      if(this.VehicleRadioYN == "20000"){
        itemValue = "Increase to R20,000";
      }
    }
    if (this.extraItem == "Locks and Keys") {
      if(this.LocksKeysYN == "N"){
        itemValue = "No";
      }
      if(this.LocksKeysYN == "10000"){
        itemValue = "Increase to R10,000";
      }
      if(this.LocksKeysYN == "15000"){
        itemValue = "Increase to R15,000";
      }
      if(this.LocksKeysYN == "20000"){
        itemValue = "Increase to R20,000";
      }
    }
    if (this.extraItem == "4x4Cover") {
      if(this.OMI4x4And4x2YN == "Y"){
        itemValue = "Yes (R125 per month)";
      }
      if(this.OMI4x4And4x2YN == "N"){
        itemValue = "No";
      }
    }
    if (this.extraItem == "Credit Shortfall") {
      if(this.creditShortfallCS == "Y"){
        itemValue = "Yes";
      }
      if(this.creditShortfallCS == "N"){
        itemValue = "No";
      }
      itemValue = this.R_OutStandingHirePurchaseAmount;
    }
    if (this.extraItem == "Dent and Scratch") {
      if(this.SmartOption_ID == "1"){
        itemValue = "Yes (additional R57 per month)";
      }
      if(this.SmartOption_ID == "0"){
        itemValue = "No";
      }
    }
    this.extraItems.push({name:this.extraItem,value:itemValue});
  }
  removeItem(value){
    let itemIndex;
    for (let i = 0; i < this.extraItems.length; i++) {
      if (this.extraItems[i].name == value) {
        itemIndex=i;
      }      
    }
    this.extraItems.splice(itemIndex, 1);
  }
  setDefaultRetailValue(){
    if(Number(this.retailValue) > 2850000){
      this.retailValue = (2850000).toString();
    }
  }
  delay(ms: number) {
    return new Promise( resolve => setTimeout(resolve, ms) );
  }


}
