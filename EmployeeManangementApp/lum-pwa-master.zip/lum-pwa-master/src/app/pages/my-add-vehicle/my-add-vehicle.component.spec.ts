import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MyAddVehicleComponent } from './my-add-vehicle.component';

describe('MyAddVehicleComponent', () => {
  let component: MyAddVehicleComponent;
  let fixture: ComponentFixture<MyAddVehicleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MyAddVehicleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MyAddVehicleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
