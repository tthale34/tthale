import { HttpClient } from '@angular/common/http';
import { ElementRef } from '@angular/core';
import { ViewChild } from '@angular/core';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { ActivatedRoute } from '@angular/router';
import { GlobalService } from 'src/app/helpers/globals';
import { ApiGatewayService } from 'src/app/services/api-gateway.service';

@Component({
  selector: 'app-helpchat',
  templateUrl: './helpchat.component.html',
  styleUrls: ['./helpchat.component.scss']
})
export class HelpchatComponent implements OnInit {
  @ViewChild('messagetextbox') messageElement: ElementRef;
  @ViewChild('convtypeselect') convtypeelementselect: ElementRef;
  @ViewChild('myscroll') myScrollContainer: ElementRef;
  params = {
    jwt: '',
    fileToUpload: File = null,
    doctype: '',
    PolicyID: 0,
    documentList: [],
  }
  private global_service = new GlobalService();
  messagetextbox: string = '';
  title = 'angular-dashboard-chat';
  openform: any = false;
  openInviteform: any = false;
  openmessagehistory: any = false;
  convtypeinfo = 0;
  messageinput = "";
  convversationTopic: any = "";
  currentuser: any = "";
  arrayofusers: any = [];
  arrayofconversations: any = [];
  arrayofconversationshistory: any = [];
  arrayofmessages: any = [];
  conversationmessages: any = [];
  conversationmessageshistory: any = [];
  userobject: any = {};
  username: any = 'Herman';
  myUserId: any = 0;
  userNameClient: any = "";
  surnameUser: any = "";
  emailuser: any = "";
  policyCode: any = "";
  conversationtype: any = "";
  myglobalconversationId: any = 0;
  myconvidhistory: any = 0;
  newBlankForm: any;
  topicConv: any = "";
  conversationmessagesusers: any[] = [];
  ratinginput: any = ""
  ratingmessageTextInput: any = "";
  AuthTokenJwt: any;
  decodedString: any = "";
  invitelinkforuser: any = "";
  getconvidfromurl: any = 0;
  usermessageobj: any = '';
  myUrl: string = '';
  policyIdDocumentUpload: any = 0;

  constructor(private route: ActivatedRoute, private httpClient: HttpClient, messageElementparam: ElementRef, myScrollContainerparam: ElementRef, myconversationtype: ElementRef, public router: Router, private _api: ApiGatewayService) {
    this.messageElement = messageElementparam;
    this.myScrollContainer = myScrollContainerparam;
    this.convtypeelementselect = myconversationtype;
  }

  async ngOnInit() {
    // this.GetAllConversations();
    if (this.AuthTokenJwt == null || this.AuthTokenJwt == undefined) {
      this.AuthTokenJwt = await localStorage.getItem('jwt');
    }
    this.myUrl = this.global_service.baseUrl.substring(0, this.global_service.baseUrl.length - 4);

    console.log(this.myUrl);
    this.route.queryParams.subscribe(params => {
      this.params.jwt = params['jwt'];
      this.params.PolicyID = params['PolicyID'];
    });
    // this.myUserId =

    // this.decodedString = this.DecodeToken(this.AuthTokenJwt)
    // console.log(this.decodedString.data);

    // this.route.queryParams.subscribe(params => {
    // 	console.log(params);
    // 	this.userNameClient = params.policycode;

    // 	this.myglobalconversationId = params.conversationid;
    // })

    this.getconvidfromurl = await localStorage.getItem('convidurl');

    if (this.getconvidfromurl != 0) {
      this.myglobalconversationId = Number(this.getconvidfromurl);
    }
    console.log(this.myglobalconversationId)
    // setInterval(() => { console.log(this.openmessagehistory); this.GetConverSationMessages(this.myglobalconversationId); }, 5000);

    setInterval(() => { console.log(this.openmessagehistory); if (this.openmessagehistory == false) { this.GetConverSationMessages(this.myglobalconversationId); } }, 5000);

    this.userobject = await JSON.parse(localStorage.getItem('currentUser')).Data || null;
    if (this.userobject == null) {
      this.router.navigate(['welcome']);
      return;
    }
    console.log(this.userobject)
    this.myUserId = this.userobject.User_ID;
    this.userNameClient = this.userobject.Names;
    this.surnameUser = this.userobject.Surname;
    this.policyCode = this.userobject.PolicyCode;
    this.policyIdDocumentUpload = this.userobject.Policy_ID;
    console.log(this.policyIdDocumentUpload + ": \n" + this.myUserId + ": \n" + this.userNameClient + " " + this.surnameUser)
  }

  inviteUser(convid: any,) {

  }

  sendreviewmessage() {
    this.ratinginput = document.getElementsByName('rating');
    this.ratingmessageTextInput = (<HTMLInputElement>document.getElementById('ratingtextareainput')).value;
    // alert(this.ratinginput.target.value);
    // ratingemojivalue = document.getElementsByName("rating");
    var ratingvalueemoji = "";
    for (var i = 0; i < this.ratinginput.length; i++) {
      if (this.ratinginput[i].checked)
        ratingvalueemoji = this.ratinginput[i].value;
    }
    // alert(ratingvalueemoji);
    var endmessagerating = "Client rated you " + ratingvalueemoji + "/" + "3" + " with the following comments: \n" + this.ratingmessageTextInput;
    var sendmessagejson = {
      "userid": Number(this.myUserId),
      "conversationid": this.myglobalconversationId,
      "statusid": 1,
      "messagetext": endmessagerating,
      "messagetypeid": 1,

    }
    this.conversationmessages = this.httpClient.post<any>(`https://chat.lum.co.za/newmessage`, JSON.stringify(sendmessagejson)).subscribe((item: any) => {
      //userobject =
      // this.myglobalconversationId = item;
      //this.GetConverSationMessages(this.myglobalconversationId)
      this.myglobalconversationId = 0;
      this.openform = false
      this.CloseRatingForm();
    });
  }
  uploadDocument() {
    // {{ myUrl }}/#/api/api/upload-documents?jwt={{AuthTokenJwt}}& ClaimID=350820
    // this.httpClient.post<any>(`https://mypolicy.lum.co.za/#/api/upload-documents?jwt=`, JSON.stringify(sendmessagejson)).subscribe((item: any) => {
    //   //userobject =
    //   // this.myglobalconversationId = item;
    //   //this.GetConverSationMessages(this.myglobalconversationId)
    //   this.myglobalconversationId = 0;
    //   this.openform = false
    //   this.CloseRatingForm();
    // });
  }
  ShowRatingList() {
    const messagebox = document.getElementById("messageblock");
    const ratingbox = document.getElementById("ratingboxsub");

    if (messagebox != null) {
      messagebox.style.setProperty("display", "none");
      messagebox.style.setProperty("flex-direction", "column");

    }
    if (ratingbox != null) {
      ratingbox.style.setProperty("display", "block");
    }
  }
  GetConversationId(convidparam: any) {
    this.myglobalconversationId = convidparam;
  }
  createnewconversation() {
    var serverult = "https://chat.lum.co.za/startnewconversation";
    this.convtypeinfo = this.convtypeelementselect.nativeElement.value;
    // conversationtype =
    var userinputvar = {
      "userinfo": {
        "id": this.myUserId,
        "name": this.userNameClient,
        "surname": this.surnameUser,
        "usertype": 6,
        "email": this.emailuser,
        "policycode": this.policyCode
      },
      "conversationtypeid": Number(this.convtypeinfo)
    }
    this.conversationmessages = this.httpClient.post<any>(serverult, JSON.stringify(userinputvar)).subscribe((item: any) => {
      //userobject =
      this.myglobalconversationId = item.convid;
      console.log(this.myglobalconversationId);
      // this.GetConverSationMessages()
    });
    this.messageElement.nativeElement.value = " ";
    // window.location.reload();
    console.log(this.myglobalconversationId)
  }
  //: Observable<any>
  sendmessagetouser() {
    this.messageinput = this.messageElement.nativeElement.value;
    // alert(this.messageinput);
    var sendmessagejson = {
      "userid": this.myUserId,
      "conversationid": this.myglobalconversationId,
      "statusid": 1,
      "messagetext": this.messageinput,
      "messagetypeid": 1,

    }
    this.conversationmessages = this.httpClient.post<any>(`https://chat.lum.co.za/newmessage`, JSON.stringify(sendmessagejson)).subscribe((item: any) => {
      //userobject =
      // this.myglobalconversationId = item;
      //this.GetConverSationMessages(this.myglobalconversationId)
      this.myglobalconversationId = item.conversationid;
      console.log(item);
    });
    this.messageElement.nativeElement.value = " ";
    // window.location.reload();
  }
  CloseFormUserInvite() {
    const invitebox = document.getElementById("userlistInviter");
    const inviteheadingdiv = document.getElementById("HeadingUser");
    const inviteheadingtext = document.getElementById("headinginvite");
    const headingtexxthide = document.getElementById("headingText");
    const userstoinvitelist = document.getElementById("userstoinvitelist");
    const listofusersinvite = document.getElementById("listofusersinvite");
    if (invitebox != null) {
      invitebox.style.setProperty("display", "none");
      invitebox.style.setProperty("flex-direction", "column");
    }
    if (inviteheadingdiv != null) {
      inviteheadingdiv.style.setProperty("display", "none");

    }
    if (inviteheadingtext != null) {
      inviteheadingtext.style.setProperty("display", "none");

    }
    if (userstoinvitelist != null) {
      userstoinvitelist.style.setProperty("display", "flex");
      userstoinvitelist.style.setProperty("width", "100%");
    }
    if (listofusersinvite != null) {
      listofusersinvite.style.setProperty("display", "none");

    }
  }
  closeUserHistory() {
    this.openInviteform = false;
    const sidemenu = document.getElementById("sidemenu");
    if (sidemenu != null) {
      sidemenu.style.display = "block";
    }
  }
  OpenRatingForm() {
    this.openform = true;
    const sidemenu = document.getElementById("sidemenu");
    if (sidemenu != null) {
      sidemenu.style.display = "none";
    }
  }
  CloseRatingForm() {
    this.openform = false;
    const sidemenu = document.getElementById("sidemenu");
    if (sidemenu != null) {
      sidemenu.style.display = "block";
    }
  }
  GetAllConversations(): Observable<any> {
    const sidemenu = document.getElementById("sidemenu");
    this.arrayofconversations = this.httpClient.post<any>('https://chat.lum.co.za/clientgetconversations', { "policycode": this.policyCode })
      .subscribe((item: any) => {
        this.arrayofconversations = item.conversations.reverse();
        console.log(this.arrayofconversations.reverse());
        this.openInviteform = true
        if (sidemenu != null) {
          sidemenu.style.display = "none";
        }
      });
    console.log(this.arrayofconversations.reverse())
    return this.arrayofconversations.reverse();
  }
  GetConverSationMessagesPopUp(convparamid: any): Observable<any> {
    //alert("I work");
    // this.myScrollContainer.nativeElement.scrollTop = this.myScrollContainer.nativeElement.scrollHeight;
    this.messageSpacings();
    this.conversationmessagesusers = [];
    let params = new URLSearchParams();
    params.append("someParamKey", convparamid)

    let convidbody = { "id": convparamid }
    this.conversationmessageshistory = this.httpClient.post<any>(`https://chat.lum.co.za/getallmessageforconversation`, convidbody).subscribe((item: any) => {
      this.conversationmessageshistory = item.conversationmessages;
      this.scrollToBottom();
      this.myconvidhistory = convparamid;

      console.log(this.conversationmessageshistory);
      console.log(item);
    });
    return this.conversationmessages;
  }
  GetConverSationMessages(convparamid: any): Observable<any> {
    //alert("I work");
    // this.myScrollContainer.nativeElement.scrollTop = this.myScrollContainer.nativeElement.scrollHeight;
    this.messageSpacings();

    this.conversationmessagesusers = [];
    let params = new URLSearchParams();
    params.append("someParamKey", convparamid)

    let convidbody = { "id": convparamid }
    this.conversationmessages = this.httpClient.post<any>(`https://chat.lum.co.za/getallmessageforconversation`, convidbody).subscribe((item: any) => {
      this.conversationmessages = item.conversationmessages;
      this.scrollToBottom();
      this.myglobalconversationId = convparamid;
      // this.conversationmessages.map((item22) => {
      // 	//this.userNameClient = item22.name;
      // 	this.usermessageobj = item22.User;

      // })

      console.log(this.conversationmessages.User);
      // this.userNameClient = item.conversationmessages.User[0].name
      //console.log(this.conversationmessages.User[0].name);
    });
    return this.conversationmessages;
  }
  scrollToBottom(): void {
    try {
      this.myScrollContainer.nativeElement.scrollToBottom = this.myScrollContainer.nativeElement.scrollHeight;
    } catch (err) { }
  }
  messageSpacings() {
    for (let index = 0; index < this.arrayofmessages.length; index++) {
      const element = this.arrayofmessages[index];
      if (this.myUserId != element.userid) {
        const usermessage = document.getElementById("messagehistoryitem");
        if (usermessage != null) {
          usermessage.style.setProperty("--background-color", "lime");
        }
      }
    }
  }
  getuserNamebyid(userid: any) {
    for (let index = 0; index < this.arrayofusers.length + 1; index++) {
      const element = this.arrayofmessages[index];
      if (userid == element.id) {
        this.userobject = element;
      }
    }
  }
  AddUserToConversation(userid: any) {
    alert("I work");
  }
  GetallUsers() {
    this.httpClient.get<any[]>('https://chat.lum.co.za/getallusers', { responseType: 'json' }).subscribe((item: any) => { this.arrayofusers = item.users; console.log(item.users) });
    return this.arrayofusers
  }
  sendUploadMessage() {
    var sendmessagejson = {
      "userid": this.myUserId,
      "conversationid": this.myglobalconversationId,
      "statusid": 1,
      "messagetext": "A document has been uploaded",
      "messagetypeid": 1,

    }
    console.log(sendmessagejson);
    this.httpClient.post<any>(`https://chat.lum.co.za/newmessage`, JSON.stringify(sendmessagejson)).subscribe((item: any) => {
      //userobject =
      // this.myglobalconversationId = item;
      //this.GetConverSationMessages(this.myglobalconversationId)
      this.myglobalconversationId = item.conversationid;
      console.log(item);
    });
  }
  ShowUserList() {
    // alert("hi");
    this.GetallUsers();
    const invitebox = document.getElementById("userlistInviter");
    const inviteheadingdiv = document.getElementById("HeadingUser");
    const inviteheadingtext = document.getElementById("headinginvite");
    const userstoinvitelist = document.getElementById("userstoinvitelist");
    const listofusersinvite = document.getElementById("listofusersinvite");
    if (invitebox != null) {
      invitebox.style.setProperty("display", "flex");
      invitebox.style.setProperty("flex-direction", "column");
    }
    if (inviteheadingdiv != null) {
      inviteheadingdiv.style.setProperty("display", "flex");

    }
    if (inviteheadingtext != null) {
      inviteheadingtext.style.setProperty("display", "flex");

    }
    if (userstoinvitelist != null) {
      userstoinvitelist.style.setProperty("display", "flex");
      userstoinvitelist.style.setProperty("width", "100%");
    }
    if (listofusersinvite != null) {
      listofusersinvite.style.setProperty("display", "flex");

    }
  }
  onFileSelect(event) {
    this.params.fileToUpload = event.target.files[0];
    this.onSubmit();
  }
  async onSubmit() {
    if (this.params.documentList.length == 0) {
      alert("Please make sure you have add the documents");
      return;
    }

    console.log("params");
    console.log(this.params);
    this._api.postUpload(this.params).then(res => {
      console.log(res)
      if (res.Status) {
        alert(res.Message);
        this.router.navigate(['welcome']);
      }
      else {
        alert(res.Message)
      }
    }).catch(err => {
      console.log(err);
      alert(err);
    });
  }
}
