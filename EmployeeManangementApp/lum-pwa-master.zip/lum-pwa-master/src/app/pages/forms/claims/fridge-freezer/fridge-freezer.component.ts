import { Component, OnInit, Renderer2,ViewChild , ElementRef } from '@angular/core';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { ApiGatewayService } from 'src/app/services/api-gateway.service';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-fridge-freezer',
  templateUrl: './fridge-freezer.component.html',
  styleUrls: ['./fridge-freezer.component.scss']
})
export class FridgeFreezerComponent implements OnInit {

  @ViewChild('otherTypeOfLoss') otherTypeOfLoss: ElementRef;

  damageTypes:Array<any> =[];
  damageType_ID = 0;
  damageList :Array<any> =[];
  damageTotalValue_= 0;
  myContents:any;
  currentDate: any = new Date().toISOString().slice(0, 10);
  user: any;
  claim = {
    PolicySection_ID:0,
    dateOfLoss: new Date().toISOString().slice(0, 10),
    AccidentTime: new Date().toISOString().slice(11,16),
    LossDamageOccuredDesc: "",
    LossDamagePrpoertyDesc: "",
    claimTypeID: 15,
    PID:0,
    R_BudgetAmount:0,
    R_OriginalBudgetAmount:0,
    LossType_ID:1009,
    LossDamageDiscoverDate: new Date().toISOString().slice(0, 10),
    User_ID:'',
    FastTrack:''
  };
  maxId = 0;
  totalInsuredAmount=0;

  constructor(private modalService: NgbModal,private spinner: NgxSpinnerService,private router: Router, private _api: ApiGatewayService,private renderer: Renderer2) { }

  async ngOnInit(){
    // await this.spinner.show();

    this.damageTypes = await JSON.parse( localStorage.getItem('lookUps')   ).l_losstypehousecontents;
    this.user = await JSON.parse(localStorage.getItem('currentUser')).Data;
    this.myContents = await this.user.PolicyItems['9'];
    this.totalInsuredAmount = await this.user.ClaimLimits.FridgeFreezerLimit;
    this.claim.User_ID = this.user.User_ID;

    // this.spinner.hide();

    this.renderer.setStyle(this.otherTypeOfLoss.nativeElement, 'display', 'none');
  }
  nav() {
    this.router.navigate(['claims-home']);
  }
  async submit(content) {
    if ((<HTMLInputElement>document.getElementById("damageLocation")).value == "") {
      alert("Please make sure you have selected the damaged location");
      return;
    }
    if (this.claim.LossDamageOccuredDesc == "") {
      alert("Please make sure you have selected the type of damage / loss ");
      return;
    }
    if (this.claim.LossDamageOccuredDesc != "" && this.claim.LossDamageOccuredDesc == "other" && (<HTMLInputElement>document.getElementById("otherTypeOfLossValue")).value == "") {
      alert("Please make sure you have entered other damage type description ");
      return;
    }
    if (this.claim.R_BudgetAmount > this.totalInsuredAmount) {
      alert("Your maximum claim amount can not exceed "+this.totalInsuredAmount+"");
      return;
    }
    if (this.damageList.length <= 0 ) {
      alert("Please make sure you have added at least one damaged item");
      return;
    }

    let tempItems = "Damaged Item/s:\n";
    for (let index = 0; index < this.damageList.length; index++) {
      tempItems = tempItems+this.damageList[index]["damagedItem"]+" R"+this.damageList[index]["damageValue"]+"\n";
    }

    this.claim.LossDamagePrpoertyDesc = tempItems;
    if ((<HTMLInputElement>document.getElementById("otherTypeOfLossValue")).value != "") {
      this.claim.LossDamageOccuredDesc = this.claim.LossDamageOccuredDesc+" : "+(<HTMLInputElement>document.getElementById("otherTypeOfLossValue")).value;
    }
    if (this.claim.R_BudgetAmount < 10000) {
      this.open(content);
    } else {
      await this.spinner.show();
      this._api.submitClaim(this.claim).then(res => {
        if(res.Status){
          alert(res.Message)
          this.spinner.hide();
          this.router.navigate(['claims-home'])
        }
        else{
          this.spinner.hide();
          alert('Could not process your request now, try again')
        }
      }).catch(err=>{
        this.spinner.hide();
        alert('Could not process your request now, try again');
      });
    }

  }

  async fastTrack(value){
    this.claim.FastTrack = value;
    await this.spinner.show();
    this._api.submitClaim(this.claim).then(res => {
      console.log(res);
      if(res.Status){
        alert(res.Message)
        this.spinner.hide();
	      this.router.navigate(['claims-home'])
      }
      else{
        this.spinner.hide();
        alert('Could not process your request now, try again')
      }
    }).catch(err=>{
      this.spinner.hide();
      alert('Could not process your request now, try again');
    });
  }
  
  async open(content) {
    this.modalService.open(content, { ariaLabelledBy: 'modal-basic-title' }).result.then((result) => {
      //action yes/no buttons
      console.log("in open result =");
      console.log(result);
    }, (reason) => {
      console.log("reason:");
      console.log(reason);
    });
  }
  addNewDamagedItem(){
    let tempNumber:any;
    tempNumber = (<HTMLInputElement>document.getElementById("damageValue")).value;

    //User Input validation for adding Damage items
    if ((<HTMLInputElement>document.getElementById("damageItem")).value ==="") {
      alert("Please make sure you have selected the damaged item");
      return;
    }
    if ( tempNumber === "") {
      alert("Please make sure you have populated the damaged item value");
      return;
    }
    if(isNaN(parseFloat(tempNumber)) && isNaN(tempNumber - 0)){
      alert("Value entered is not a valid number");
      return;
    }
    // setting damage item variables
    let damagedItem_ = (<HTMLInputElement>document.getElementById("damageItem")).value;
    let damageValue_ = (<HTMLInputElement>document.getElementById("damageValue")).value;
    this.damageTotalValue_ = this.damageTotalValue_ + Number(damageValue_);
    //inseting new item into the list of items
    this.damageList.push({id:this.damageList.length,damagedItem:damagedItem_,damageValue:damageValue_});
    // console.log(this.damageList);
    (<HTMLInputElement>document.getElementById("damageValue")).value = "";
    (<HTMLInputElement>document.getElementById("myTotal")).innerHTML = ""+parseFloat(""+this.damageTotalValue_).toFixed(2);
    this.claim.R_BudgetAmount = this.damageTotalValue_;
    this.claim.R_OriginalBudgetAmount = this.damageTotalValue_;
  }
  removeDamagedItem(id,damageValue){
    this.damageTotalValue_ = this.damageTotalValue_ - Number(damageValue);
    (<HTMLInputElement>document.getElementById("myTotal")).innerHTML = ""+parseFloat(""+this.damageTotalValue_).toFixed(2);
    this.damageList = this.damageList.filter(item => item.id !== id);
    console.log(this.damageList);
    this.claim.R_BudgetAmount = this.damageTotalValue_;
    this.claim.R_OriginalBudgetAmount = this.damageTotalValue_;
  }
  dateOfIncidentChange(value){
    this.claim.dateOfLoss = value;
  }
  damageLocationChange(id){
    this.claim.PolicySection_ID = id;
    // console.log(this.totalInsuredAmount);
  }
  typeOfLossChange(value){
    this.claim.LossDamageOccuredDesc = value;
    if (value == "other") {
      this.renderer.setStyle(this.otherTypeOfLoss.nativeElement, 'display', 'inline');
    }else{
      this.renderer.setStyle(this.otherTypeOfLoss.nativeElement, 'display', 'none');
    }
  }
}
