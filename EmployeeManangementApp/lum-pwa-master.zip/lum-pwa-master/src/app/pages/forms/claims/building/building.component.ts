import { Component, OnInit, Renderer2,ViewChild , ElementRef } from '@angular/core';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { ApiGatewayService } from 'src/app/services/api-gateway.service';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-building',
  templateUrl: './building.component.html',
  styleUrls: ['./building.component.scss']
})
export class BuildingComponent implements OnInit {
  @ViewChild('fireOriginHolder') fireOriginHolder: ElementRef;
  @ViewChild('mySapsRef') mySapsRef: ElementRef;
  currentDate: any = new Date().toISOString().slice(0, 10);
  claim = {
    claimTypeID: 6,
    dateOfLoss: new Date().toISOString().slice(0, 10),
    PID: 0, // for new claim
    PolicySection_ID: 1,
    LossDamageAddress1: '',
    LossType: '',
    LossType_ID: '',
    ItemType_ID:0,
    fireOrigin:'',
    Endos_M_YN:'',
    //Describe in details how property got damaged
    LossDamagePrpoertyDesc:'',
    //List of damdaged goods
    LossDamageOccuredDesc:'',
    //List of damdaged goods
    NonStandardDescP:'',
    UnoccupiedLonger60DaysYN:'',
    SAPDPoliceStation:'',
    sapsRefNum:'',
    sapsCheck:false,
    SAPDReferenceNumber:'',
    AccidentTime: new Date().toISOString().slice(11,16),
    AccidentReportedSAPDYN:'N',
    totalClaim:0.00,
    R_BudgetAmount:0,
    R_OriginalBudgetAmount:0,
    R_FullInsuredAmount:0,
    insuredAmount:0,
    User_ID:'',
    FastTrack:''
  };
  lossTypes:Array<any> =[];
  myBuildings:Array<any> =[];
  damagedItems:Array<any> =[];
  damageItem:any = null;
  damageValue:0;
  user: any;
  years: any[] = [{ "year": "2023" },{"year":"2022"},{"year":"2021"},{"year":"2020"},{"year":"2019"},{"year":"2018"},{"year":"2017"},{"year":"2016"},{"year":"2015"},{"year":"2014"},{"year":"2013"},{"year":"2012"},{"year":"2011"},{"year":"2010"}];
  ref_month:any;
  ref_year:any;

  constructor(private modalService: NgbModal,private spinner: NgxSpinnerService,private router: Router, private _api: ApiGatewayService,private renderer: Renderer2) { }

  async ngOnInit() {
    this.lossTypes = await JSON.parse( localStorage.getItem('lookUps')).l_losstypehousecontents;
    this.lossTypes.splice(4, 2);
    this.lossTypes.splice(8, 1);
    this.lossTypes.splice(9, 2);
    this.myBuildings = await JSON.parse(localStorage.getItem('currentUser')).Data.PolicyItems['1'];
    this.user = await JSON.parse(localStorage.getItem('currentUser')).Data;
    this.claim.User_ID = this.user.User_ID;
    //Hide fields to be checked if required
    this.renderer.setStyle(this.fireOriginHolder.nativeElement, 'display', 'none');
    this.renderer.setStyle(this.mySapsRef.nativeElement, 'display', 'none');
  }
  selBuildingChange(value) {
    for (let i = 0; i < this.myBuildings.length; i++) {
      if (this.myBuildings[i].PID == value) {
        this.claim.LossDamageAddress1 = this.myBuildings[i].ItemDescription;
        this.claim.ItemType_ID = this.myBuildings[i].ItemType;
        this.claim.PolicySection_ID = this.myBuildings[i].PID
        this.claim.R_FullInsuredAmount = this.myBuildings[i].R_TotalInsuredAmount;
        this.claim.Endos_M_YN = this.myBuildings[i].Endos_M_YN;
      }
    }
  }
  lossTypeHomeContent(value){
    for (let i = 0; i < this.lossTypes.length; i++) {
      if(Number(this.lossTypes[i]["ID"]) === Number(value)){
        this.claim.LossType=this.lossTypes[i]["Value"];
        this.claim.LossType_ID=this.lossTypes[i]["ID"];
      }
    }
    if (this.claim.LossType === "Fire Damage") {
      this.renderer.setStyle(this.fireOriginHolder.nativeElement, 'display', 'inline');
    } else {
      this.renderer.setStyle(this.fireOriginHolder.nativeElement, 'display', 'none');
    }
    if (this.claim.LossType === "Forcible Theft") {
      this.renderer.setStyle(this.mySapsRef.nativeElement, 'display', 'inline');
    } else {
      this.renderer.setStyle(this.mySapsRef.nativeElement, 'display', 'none');
    }
  }
  nav() {
    this.router.navigate(['claims-home']);
  }
  add(){
    //User Input validation for adding Damage items
    if (this.damageItem ===null) {
      alert("Please make sure you have entered the damaged item");
      return;
    }
    if ( this.damageValue === 0) {
      alert("Please make sure you have entered the damaged item value");
      return;
    }
    if(isNaN(parseFloat(this.damageValue)) && isNaN(this.damageValue - 0)){
      alert("Value entered is not a valid number");
      return;
    }
    this.damagedItems.push({value:this.damageItem,price:this.damageValue});
    this.claim.totalClaim = this.claim.totalClaim+Number(this.damageValue);
    this.damageItem = '';
    this.damageValue=0;
  }
  remove(value){
    this.claim.totalClaim = this.claim.totalClaim-Number(this.damagedItems[value]["price"]);
    this.damagedItems.splice(value, 1);
  }
  checkSAPSRef(){
    if (this.claim.sapsCheck) {
      console.log(this.claim.sapsCheck);
      this.renderer.setStyle(this.mySapsRef.nativeElement, 'display', 'none');
      this.claim.AccidentReportedSAPDYN='N';
    } else {
      this.renderer.setStyle(this.mySapsRef.nativeElement, 'display', 'inline');
      this.claim.AccidentReportedSAPDYN='Y';
    }
  }
  async submit() {
    if (this.claim.LossDamageAddress1 === "") {
      alert("Please make sure you have selected the damaged location");
      return;
    }
    if (this.claim.LossType == "") {
      alert("Please make sure you have selected the type of damage / loss ");
      return;
    }
    if (this.claim.LossType === "Fire Damage" && this.claim.fireOrigin ==="") {
      alert("Please make sure you have entered the origin of the fire");
      return;
    }
    if (this.claim.UnoccupiedLonger60DaysYN === "") {
      alert("Please make sure you have selected the unocuppied longer than 60 daysfield");
      return;
    }
    if (this.claim.LossDamageOccuredDesc === "") {
      alert("Please make sure you have entered a the full description of how the incident or damage occured");
      return;
    }
    if (this.claim.LossType === "Forcible Theft" && this.claim.AccidentReportedSAPDYN==="N" && this.claim.sapsRefNum === "") {
      if (!this.claim.sapsCheck) {
        alert("Please make sure you have entered a valid SAPS reference number");
        return;
      }
    }
    if (this.claim.totalClaim == 0) {
      alert("Please make sure you have added damaged items");
      return;
    }
    if(this.claim.sapsRefNum !== ""){
      this.claim.SAPDReferenceNumber=this.claim.sapsRefNum+"/"+this.ref_month+"/"+this.ref_year;
      this.claim.AccidentReportedSAPDYN='Y';
    }
    this.claim.R_BudgetAmount = this.claim.totalClaim;
    this.claim.R_OriginalBudgetAmount = this.claim.totalClaim;
    this.claim.LossDamagePrpoertyDesc = "Damaged Item/s:\n";
    for (let index = 0; index < this.damagedItems.length; index++) {
      this.claim.LossDamagePrpoertyDesc = this.claim.LossDamagePrpoertyDesc+this.damagedItems[index]["value"]+" R"+this.damagedItems[index]["price"]+"\n";
    }
    this.claim.NonStandardDescP = this.claim.LossDamagePrpoertyDesc;
    // if (this.claim.R_BudgetAmount < 10000) {
    //   this.open(content);
    // } else {
      await this.spinner.show();
      this._api.submitClaim(this.claim).then(res => {
        if(res.Status){
          alert(res.Message);
          this.spinner.hide();
          this.router.navigate(['claims-home']);
        }
        else{
          this.spinner.hide();
          alert('Could not process your request now, try again');
        }
      }).catch(err=>{
        this.spinner.hide();
        alert('Could not process your request now, try again');
      });
    // }


  }
  async fastTrack(value){
    this.claim.FastTrack = value;
    await this.spinner.show();
    this._api.submitClaim(this.claim).then(res => {
      if(res.Status){
        alert(res.Message);
        this.spinner.hide();
	      this.router.navigate(['claims-home']);
      }
      else{
        this.spinner.hide();
        alert('Could not process your request now, try again');
      }
    }).catch(err=>{
      this.spinner.hide();
      alert('Could not process your request now, try again');
    });
  }
  async open(content) {
    this.modalService.open(content, { ariaLabelledBy: 'modal-basic-title' }).result.then((result) => {
      //action yes/no buttons
      console.log("in open result =");
      console.log(result);
    }, (reason) => {
      console.log("reason:");
      console.log(reason);
    });
  }

}
