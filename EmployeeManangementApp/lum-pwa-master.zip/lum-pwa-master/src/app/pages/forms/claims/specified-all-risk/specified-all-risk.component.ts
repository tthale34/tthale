import { Component, OnInit, Renderer2,ViewChild , ElementRef } from '@angular/core';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { ApiGatewayService } from 'src/app/services/api-gateway.service';
import { GetUserdataService } from 'src/app/services/get-userdata.service';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-specified-all-risk',
  templateUrl: './specified-all-risk.component.html',
  styleUrls: ['./specified-all-risk.component.scss']
})
export class SpecifiedAllRiskComponent implements OnInit {
  @ViewChild('mySapsRef') mySapsRef: ElementRef;
  @ViewChild('bicycleAdditionalFields') bicycleAdditionalFields: ElementRef;
  @ViewChild('unknown') unknown: ElementRef;
  @ViewChild('jewelryAdditionalFields') jewelryAdditionalFields: ElementRef;
  @ViewChild('musicAdditionalFields') musicAdditionalFields: ElementRef;
  @ViewChild('photoAdditionalFields') photoAdditionalFields: ElementRef;
  @ViewChild('sportsAdditionalFields') sportsAdditionalFields: ElementRef;
  @ViewChild('bicycleSponsored') bicycleSponsored: ElementRef;
  @ViewChild('vehicleLockedFields') vehicleLockedFields: ElementRef;
  @ViewChild('musicField2') musicField2: ElementRef;
  @ViewChild('cellTabletIpad') cellTabletIpad: ElementRef;
  years: any[] = [{ "year": "2023" },{"year":"2022"},{"year":"2021"},{"year":"2020"},{"year":"2019"},{"year":"2018"},{"year":"2017"},{"year":"2016"},{"year":"2015"},{"year":"2014"},{"year":"2013"},{"year":"2012"},{"year":"2011"},{"year":"2010"}];
  incidentTypes: Array<any> = [];
  tmpIncidentTypes: Array<any> = [];
  specifiedAllRiskItems: Array<any> = [];
  insuredAmount:number=0.00;
  currentDate: any = new Date().toISOString().slice(0, 10);
  user:any;
  itemClaim = {
    LossDetail: '',
    claimTypeID: 11,
    PolicySection_ID: 0,
    R_BudgetAmount:0,
    R_OriginalBudgetAmount:0,
    LossType: '',
    LossType_ID: '',
    LossDamageOccuredDesc:'' ,
    LossDamagePrpoertyDesc:'' ,
    LossDate: new Date().toISOString().slice(0, 10),
    PID:0,
    ItemType_ID:0,
    Endos_M_YN:'',
    riskItem:'',
    vehicleLocked:'',
    vehicleForcedIn:'',
    equipmentVisible:'',
    unknownPlace:'',
    totalClaimAmount:0,
    purposeOfUse:'',
    sponsored:'',
    jewelryLockedSafe:'',
    musicEquipPurpose:'',
    photoIncomeInLoss:'',
    equipDamagedInGame:'',
    sapsStation:'',
    sapsRefNum:'',
    sapsCheck:false,
    musicDamagedInUse:'',
    OriginalSupplier: '',
    HirePurchaseRefNumber: null,
    SAPDReferenceNumber:'',
    OccuredDate:new Date().toISOString().slice(0, 10),
    User_ID:'',
    FastTrack:''
  }

  constructor(private modalService: NgbModal,private spinner: NgxSpinnerService,private router: Router, private _api: ApiGatewayService,private _userData: GetUserdataService,private renderer: Renderer2) { }

  async ngOnInit(){
    await this.spinner.show();
    this.tmpIncidentTypes = await JSON.parse(localStorage.getItem('lookUps')).l_losstypeallrisk;
    for (let index = 0; index < this.tmpIncidentTypes.length; index++) {
      if(this.tmpIncidentTypes[index].Value === "Damaged" || this.tmpIncidentTypes[index].Value === "Fire Damage"){
      }else{
        this.incidentTypes[this.incidentTypes.length] = this.tmpIncidentTypes[index];
      }
    }
    this.user = await JSON.parse(localStorage.getItem('currentUser')).Data;
    this.itemClaim.User_ID = this.user.User_ID;
    this.specifiedAllRiskItems = this._userData.getSpecifiedAllRiskPolicyItems();
    this.renderer.setStyle(this.mySapsRef.nativeElement, 'display', 'none');
    this.renderer.setStyle(this.bicycleAdditionalFields.nativeElement, 'display', 'none');
    this.renderer.setStyle(this.unknown.nativeElement, 'display', 'none');
    this.renderer.setStyle(this.jewelryAdditionalFields.nativeElement, 'display', 'none');
    this.renderer.setStyle(this.musicAdditionalFields.nativeElement, 'display', 'none');
    this.renderer.setStyle(this.photoAdditionalFields.nativeElement, 'display', 'none');
    this.renderer.setStyle(this.sportsAdditionalFields.nativeElement, 'display', 'none');
    this.renderer.setStyle(this.bicycleSponsored.nativeElement, 'display', 'none');
    this.renderer.setStyle(this.vehicleLockedFields.nativeElement, 'display', 'none');
    this.renderer.setStyle(this.musicField2.nativeElement, 'display', 'none');
    this.renderer.setStyle(this.cellTabletIpad.nativeElement, 'display', 'none');
    this.spinner.hide();
  }
  nav() {
    this.router.navigate(['claims-home']);
  }
  async submit() {
    if (this.itemClaim.riskItem == "") {
      alert("Please make sure you have selected the Specified All Risk Item");
      return;
    }
    if (this.itemClaim.LossType == "") {
      alert("Please make sure you have selected the incident type");
      return;
    }
    if (this.itemClaim.LossDamageOccuredDesc == "") {
      alert("Please make sure you have selected where the loss occured");
      return;
    }
    if(Number(this.itemClaim.totalClaimAmount) > Number(this.insuredAmount) ) {
      alert("Total claim amount exceeds insured amount, Please make sure you enter insured amount or less");
      return;
    }
    if (this.itemClaim.sapsRefNum == undefined) {
      this.itemClaim.SAPDReferenceNumber = "";
    } else {
      this.itemClaim.SAPDReferenceNumber = this.itemClaim.sapsRefNum+"/"+(<HTMLInputElement>document.getElementById("ref_month")).value+"/"+(<HTMLInputElement>document.getElementById("ref_year")).value;
    }
    this.itemClaim.R_BudgetAmount = this.itemClaim.totalClaimAmount;
    this.itemClaim.R_OriginalBudgetAmount = this.itemClaim.totalClaimAmount;
    this.itemClaim.LossDamagePrpoertyDesc = this.itemClaim.totalClaimAmount.toString();
    this.itemClaim.OccuredDate = this.itemClaim.LossDate;
    // if (this.itemClaim.R_BudgetAmount < 10000) {
    //   this.open(content);
    // }else{
      this._api.submitClaim(this.itemClaim).then(res => {
        if(res.Status){
          alert(res.Message);
          this.spinner.hide();
          this.router.navigate(['claims-home']);
        }
        else{
          this.spinner.hide();
          alert('Could not process your request now, try again');
        }
      }).catch(err=>{
        this.spinner.hide();
        alert('Could not process your request now, try again');
      });
    // }

  }
  setSpecifiedAllRiskItem(id){
    this.itemClaim.PolicySection_ID = id;
    for (let i = 0; i < this.specifiedAllRiskItems.length; i++) {
      if(this.specifiedAllRiskItems[i].PID == id){
        this.itemClaim.Endos_M_YN = this.specifiedAllRiskItems[i].Endos_M_YN;
        this.itemClaim.ItemType_ID = this.specifiedAllRiskItems[i].ItemType_ID;
        this.itemClaim.riskItem = this.specifiedAllRiskItems[i].ItemDescription;
        this.insuredAmount = Number(this.specifiedAllRiskItems[i].R_TotalInsuredAmount);
        //Enabled additional fields based on item type ID
        //Bicycle fields 1
        if(this.itemClaim.ItemType_ID == 1){
          this.renderer.setStyle(this.bicycleAdditionalFields.nativeElement, 'display', 'inline');
        }else{
          this.renderer.setStyle(this.bicycleAdditionalFields.nativeElement, 'display', 'none');
        }
        //Golf 23
        //Music 19,1059
        if (this.itemClaim.ItemType_ID == 19 || this.itemClaim.ItemType_ID == 1059) {
          this.renderer.setStyle(this.musicAdditionalFields.nativeElement, 'display', 'inline');
        }else{
          this.renderer.setStyle(this.musicAdditionalFields.nativeElement, 'display', 'none');
        }
        //Jewelry fields 12,1045
        //Photo fields 21,1051
        if(this.itemClaim.ItemType_ID == 21 || this.itemClaim.ItemType_ID == 1051){
          this.renderer.setStyle(this.photoAdditionalFields.nativeElement, 'display', 'inline');
        }else{
          this.renderer.setStyle(this.photoAdditionalFields.nativeElement, 'display', 'none');
        }
        //Sports fields 23,1053
        if(this.itemClaim.ItemType_ID == 23 || this.itemClaim.ItemType_ID == 1053){
          this.renderer.setStyle(this.sportsAdditionalFields.nativeElement, 'display', 'inline');
        }else{
          this.renderer.setStyle(this.sportsAdditionalFields.nativeElement, 'display', 'none');
        }
        //Cellphone,tablet, and IPad fields 23,1053
        if(this.itemClaim.ItemType_ID == 6){
          this.renderer.setStyle(this.cellTabletIpad.nativeElement, 'display', 'inline');
        }else{
          this.renderer.setStyle(this.cellTabletIpad.nativeElement, 'display', 'none');
        }
      }
    }
  }
  bicyclePurpose(value){
    if (value === "Professional" || value === "Racing") {
      this.renderer.setStyle(this.bicycleSponsored.nativeElement, 'display', 'inline');
    }else{
      this.renderer.setStyle(this.bicycleSponsored.nativeElement, 'display', 'none');
    }
  }
  incidentTypeChange(value){
    this.itemClaim.LossType_ID = value;
    for (let index = 0; index < this.incidentTypes.length; index++) {
      if(this.incidentTypes[index].ID == value){
        this.itemClaim.LossType = this.incidentTypes[index].Value;
      }
    }
    if (this.itemClaim.LossType === 'Theft' || this.itemClaim.LossType === 'Lost') {
      this.renderer.setStyle(this.mySapsRef.nativeElement, 'display', 'inline');
    } else {
      this.renderer.setStyle(this.mySapsRef.nativeElement, 'display', 'none');
    }
    //Sports fields 23,1053
    if(this.itemClaim.ItemType_ID == 23 || this.itemClaim.ItemType_ID == 1053){
      this.renderer.setStyle(this.sportsAdditionalFields.nativeElement, 'display', 'inline');
    }else{
      this.renderer.setStyle(this.sportsAdditionalFields.nativeElement, 'display', 'none');
    }
  }
  placeOfOccurance(value) {
    this.itemClaim.LossDamageOccuredDesc = value;
    //Jewelry question pop-up.12,1045
    if (value == "From My Home" && (this.itemClaim.ItemType_ID == 12 || this.itemClaim.ItemType_ID == 1045) && (this.itemClaim.R_OriginalBudgetAmount >= 50000 || this.itemClaim.Endos_M_YN == "Y")) {
      this.renderer.setStyle(this.jewelryAdditionalFields.nativeElement, 'display', 'inline');
    }else{
      this.renderer.setStyle(this.jewelryAdditionalFields.nativeElement, 'display', 'none');
    }
    if(value == "Unknown"){
      this.renderer.setStyle(this.unknown.nativeElement, 'display', 'inline');
    }else{
      this.renderer.setStyle(this.unknown.nativeElement, 'display', 'none');
    }
    if(value == "From My Vehicle"){
      this.renderer.setStyle(this.vehicleLockedFields.nativeElement, 'display', 'inline');
    }else{
      this.renderer.setStyle(this.vehicleLockedFields.nativeElement, 'display', 'none');
    }
  }
  musicEquipPurposeChange(value){
    if (value === 'Professional') {
      this.renderer.setStyle(this.musicField2.nativeElement, 'display', 'inline');
    } else {
      this.renderer.setStyle(this.musicField2.nativeElement, 'display', 'none');
    }
  }
  checkSAPSRef(){
    if ((<HTMLInputElement>document.getElementById("sapsCheck")).checked) {
      this.renderer.setStyle(this.mySapsRef.nativeElement, 'display', 'none');
    } else {
      this.renderer.setStyle(this.mySapsRef.nativeElement, 'display', 'inline');
    }
  }
  async fastTrack(value){
    this.itemClaim.FastTrack = value;
    await this.spinner.show();
    this._api.submitClaim(this.itemClaim).then(res => {
      if(res.Status){
        alert(res.Message);
        this.spinner.hide();
	      this.router.navigate(['claims-home']);
      }
      else{
        this.spinner.hide();
        alert('Could not process your request now, try again');
      }
    }).catch(err=>{
      this.spinner.hide();
      alert('Could not process your request now, try again');
    });
  }
  async open(content) {
    this.modalService.open(content, { ariaLabelledBy: 'modal-basic-title' }).result.then((result) => {
      //action yes/no buttons
      console.log("in open result =");
      console.log(result);
    }, (reason) => {
      console.log("reason:");
      console.log(reason);
    });
  }
}
