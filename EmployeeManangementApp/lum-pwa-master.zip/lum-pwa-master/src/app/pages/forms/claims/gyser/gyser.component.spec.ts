import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GyserComponent } from './gyser.component';

describe('GyserComponent', () => {
  let component: GyserComponent;
  let fixture: ComponentFixture<GyserComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GyserComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GyserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
