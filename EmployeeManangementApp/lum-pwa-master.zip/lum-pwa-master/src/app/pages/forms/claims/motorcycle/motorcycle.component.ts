import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ApiGatewayService } from 'src/app/services/api-gateway.service';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-motorcycle',
  templateUrl: './motorcycle.component.html',
  styleUrls: ['./motorcycle.component.scss']
})
export class MotorcycleComponent implements OnInit {
  accidentView: boolean = true;
  theftView: boolean = false;
  towAddress: string = '';
  enterAddress: boolean = false;
  currentDate: any = new Date().toISOString().slice(0, 10);
  claimDetails = {
    NeedTowID: 1,
    PolicySection_ID: null,
    OccuredDate: new Date().toISOString().slice(0, 10),
    claimTypeID: 0,
    DriverRelatio_ID: '3', //policy holder,
    IncidentType_ID: 1,
    VehiclePurpose_ID: 1,
    SAPDReferenceNumber: null,
    SAPDPoliceStation: null,
    DriverName: null, //for other driver
    DriverIDNumber: null, //for other driver
    DriverLicenceNumber: null, //for other driver
    PID: 0, // for new claim
    AccidentDescription:null,
    AccidentPlace:null,
    PhotoYN: 'Yes',
    SAPSDateReported:new Date().toISOString().slice(0, 10), //new
    Injuries_ID:null,
    OtherPartyInitial:null,
    OtherPartySurname:null,
    thirdpIDNumber:null,
    OtherPartyCellPhone:null,
    thirdpModel:null,
    thirdpRegNumber:null,
    vAccidentTime:new Date().toISOString().slice(11,16),
    User_ID:''
  };
  myMotorcycles: any = [];
  user: any;
  lookUps: any = [];
  isTpInvolved:boolean = false;
  constructor(private router: Router, private _api: ApiGatewayService, private spinner: NgxSpinnerService) { }

  async ngOnInit() {
    await this.spinner.show();
    this.user = await JSON.parse(localStorage.getItem('currentUser')).Data;
    this.claimDetails.User_ID = this.user.User_ID;
    this.myMotorcycles = this.user.PolicyItems['3'];
    this.lookUps = await JSON.parse(localStorage.getItem('lookUps'));
    this.spinner.hide();
    // this.itemChange('');
  }
  itemChange(value){
    this.claimDetails.claimTypeID = value;
    if (this.accidentView && !this.theftView) {
      this.accidentView =false;
      this.theftView =true;
    } else {
      this.accidentView =true;
      this.theftView =false;
    }
  }
  towOptionsChange(value: any) {
    console.log(value)
    this.claimDetails.NeedTowID = value;
    if (value == 2) {
      this.enterAddress = true
    }
    else
      this.enterAddress = false;
  }
  motorcycleChange(value) {
    this.claimDetails.PolicySection_ID = value;
  }
  picsTakenChange(value){
    this.claimDetails.PhotoYN = value
  }
  motorcycleControledChange(value) { 
    this.claimDetails.DriverRelatio_ID = value
  }
  incidentChange(value) {
    if(value == 2 || value == 3){
      this.isTpInvolved = true
    }else{
      this.isTpInvolved = false;
    }    
    this.claimDetails.IncidentType_ID = value;
  }
  injuriesChange(value){
    this.claimDetails.Injuries_ID = value
  }
  motorPurposeChange(value) {
    this.claimDetails.VehiclePurpose_ID = value;
  }


  nav() {
    this.router.navigate(['claims-home']);
  }
  onBlurAddress(val) {
    if (this.towAddress.length < 6) {
      alert("fill in a valid address")
      return;
    }
    this._api.callTowTruck({ towAddress: this.towAddress }).then(res => {
      if (res.Status)
        alert(res.Message)
    })
  }
  async submit() {
    if (this.claimDetails.claimTypeID == 0) {
      alert("Please make sure you have selected the claim type.");
      return;
    }
    await this.spinner.show()
    this._api.submitClaim(this.claimDetails).then(res => {
      if (res.Status) {
        alert(res.Message);
        this.router.navigate(['claims-home']);
      }
      else
        alert('We could not process your claim, please try again')

      this.spinner.hide()
    }).catch(err => {
      alert('We could not process your claim, please try again')
      this.spinner.hide()
    });
  }

}
