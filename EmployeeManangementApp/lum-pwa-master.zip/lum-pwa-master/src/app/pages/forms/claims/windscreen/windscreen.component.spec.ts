import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WindscreenComponent } from './windscreen.component';

describe('WindscreenComponent', () => {
  let component: WindscreenComponent;
  let fixture: ComponentFixture<WindscreenComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WindscreenComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WindscreenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
