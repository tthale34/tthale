import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { ApiGatewayService } from 'src/app/services/api-gateway.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { GlobalService } from 'src/app/helpers/globals';
@Component({
  selector: 'app-vehicle',
  templateUrl: './vehicle.component.html',
  styleUrls: ['./vehicle.component.scss']
})
export class VehicleComponent implements OnInit {
  vehAccidentForm: FormGroup;
  towAddress: string = '';
  currentDate: any = new Date().toISOString().slice(0, 10);
  enterAddress: boolean = false;
  claimDetails = {
    NeedTowID: 1,
    PolicySection_ID: null,
    OccuredDate: new Date().toISOString().slice(0, 10),
    claimTypeID: 8,
    DriverRelatio_ID: '3', //policy holder,
    IncidentType_ID: 1,
    VehiclePurpose_ID: 1,
    SAPDReferenceNumber: null,
    SAPDPoliceStation: null,
    DriverName: null, //for other driver
    DriverIDNumber: null, //for other driver
    DriverLicenceNumber: null, //for other driver
    PID: 0, // for new claim
    AccidentDescription:null,
    AccidentPlace:null,
    PhotoYN: 'Yes',
    SAPSDateReported:new Date().toISOString().slice(0, 10), //new
    Injuries_ID:null,
    OtherPartyInitial:null,
    OtherPartySurname:null,
    thirdpIDNumber:null,
    OtherPartyCellPhone:null,
    thirdpModel:null,
    thirdpRegNumber:null,
    vAccidentTime:new Date().toISOString().slice(11,16),
    User_ID:''
  };
  myVehicles: any = [];
  globals: GlobalService;
  selectedDate: any;
  lookUps: any = {};
  user: any;
  isTpInvolved:boolean = false;
  constructor(private router: Router, private _api: ApiGatewayService, private spinner: NgxSpinnerService) { }

  async ngOnInit() {
    console.log(new Date().toISOString().slice(11,16))
    await this.spinner.show();
    this.user = await JSON.parse(localStorage.getItem('currentUser')).Data;
    this.claimDetails.User_ID = this.user.User_ID;
    console.log(JSON.parse(localStorage.getItem('lookUps')))
    this.myVehicles = await this.user.PolicyItems['2'];
    this.claimDetails.PolicySection_ID = this.myVehicles[0].PID
    this.lookUps = await JSON.parse(localStorage.getItem('lookUps'));
    this.claimDetails.Injuries_ID ="None"
    this.spinner.hide();

  }

  nav() {
    this.router.navigate(['claims-home']);
  }

  vehicleChange(vehId) {
    console.log(vehId)
    this.claimDetails.PolicySection_ID = vehId;
  }

  vehicleControledChange(value) {
    this.claimDetails.DriverRelatio_ID = value
    console.log(this.claimDetails.DriverRelatio_ID.toString())
  }

  incidentChange(value) {
    if(value == 2 || value == 3){
      this.isTpInvolved = true
    }
    else
    this.isTpInvolved = false;
    console.log(value)
    this.claimDetails.IncidentType_ID = value;
  }
  picsTakenChange(value){
this.claimDetails.PhotoYN = value
  }

  injuriesChange(value){
    this.claimDetails.Injuries_ID = value
  }

  towOptionsChange(value: any) {
    console.log(value)
    this.claimDetails.NeedTowID = value;
    if (value == 2) {
      this.enterAddress = true
    }
    else
      this.enterAddress = false;
  }
  vehPurposeChange(value) {
    this.claimDetails.VehiclePurpose_ID = value;
  }

  onBlurAddress(val) {
    if (this.towAddress.length < 6) {
      alert("fill in a valid address")
      return;
    }
    this._api.callTowTruck({ towAddress: this.towAddress }).then(res => {
      if (res.Status)
        alert(res.Message)
    })
  }

  async submit() {
    await this.spinner.show()
    this._api.submitClaim(this.claimDetails).then(res => {
      if (res.Status) {
        alert(res.Message)
        this.router.navigate(['claims-home'])
      }
      else
        alert('We could not process your claim, please try again')

      this.spinner.hide()
    }).catch(err => {
      alert('We could not process your claim, please try again ')
      this.spinner.hide()
    });
  }




}
