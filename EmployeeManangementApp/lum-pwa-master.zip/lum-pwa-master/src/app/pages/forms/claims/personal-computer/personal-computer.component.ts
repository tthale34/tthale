import { Component, ElementRef, OnInit, Renderer2, ViewChild } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { ApiGatewayService } from 'src/app/services/api-gateway.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { GlobalService } from 'src/app/helpers/globals';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { GetUserdataService } from 'src/app/services/get-userdata.service';

@Component({
  selector: 'app-personal-computer',
  templateUrl: './personal-computer.component.html',
  styleUrls: ['./personal-computer.component.scss']
})
export class PersonalComputerComponent implements OnInit {
  @ViewChild('mySapsRef') mySapsRef: ElementRef;
  years: any[] = [{ "year": "2023" },{"year":"2022"},{"year":"2021"},{"year":"2020"},{"year":"2019"},{"year":"2018"},{"year":"2017"},{"year":"2016"},{"year":"2015"},{"year":"2014"},{"year":"2013"},{"year":"2012"},{"year":"2011"},{"year":"2010"}];
  incidentTypes: Array<any> = [];
  tmpIncidentTypes: Array<any> = [];
  personalComputerItems: Array<any> = [];
  insuredAmount:number=0.00;
  currentDate: any = new Date().toISOString().slice(0, 10);
  user:any;
  itemClaim = {
    LossDetail: '',
    claimTypeID: 12,
    PolicySection_ID: 0,
    R_BudgetAmount:0,
    R_OriginalBudgetAmount:0,
    LossType: '',
    LossType_ID: '',
    LossDamageOccuredDesc:'' ,
    LossDamagePrpoertyDesc:'' ,
    LossDate: new Date().toISOString().slice(0, 10),
    PID:0,
    ItemType:0,
    Endos_M_YN:'',
    riskItem:'',
    vehicleLocked:'',
    vehicleForcedIn:'',
    equipmentVisible:'',
    unknownPlace:'',
    totalClaimAmount:0,
    purposeOfUse:'',
    sponsored:'',
    jewelryLockedSafe:'',
    musicEquipPurpose:'',
    photoIncomeInLoss:'',
    equipDamagedInGame:'',
    sapsStation:'',
    sapsRefNum:'',
    sapsCheck:false,
    musicDamagedInUse:'',
    OriginalSupplier: '',
    HirePurchaseRefNumber: null,
    SAPDReferenceNumber:'',
    OccuredDate:new Date().toISOString().slice(0, 10),
    User_ID:'',
    FastTrack:''
  }

  constructor(private modalService: NgbModal,private spinner: NgxSpinnerService,private router: Router, private _api: ApiGatewayService,private _userData: GetUserdataService,private renderer: Renderer2) { }

  async ngOnInit(){
    await this.spinner.show();
    this.tmpIncidentTypes = await JSON.parse(localStorage.getItem('lookUps')).l_losstypepersonalcomputer;
    for (let index = 0; index < this.tmpIncidentTypes.length; index++) {
      if(this.tmpIncidentTypes[index].Value === "Damaged" || this.tmpIncidentTypes[index].Value === "Fire Damage"){
      }else{
        this.incidentTypes[this.incidentTypes.length] = this.tmpIncidentTypes[index];
      }
    }
    this.user = await JSON.parse(localStorage.getItem('currentUser')).Data;
    this.itemClaim.User_ID = this.user.User_ID;
    this.personalComputerItems = await this.user.PolicyItems['7'];
    this.renderer.setStyle(this.mySapsRef.nativeElement, 'display', 'none');
    this.spinner.hide();
  }
  nav() {
    this.router.navigate(['claims-home']);
  }
  async submit() {
    if (this.itemClaim.riskItem == "") {
      alert("Please make sure you have selected the Personal Computer Item");
      return;
    }
    if (this.itemClaim.LossType == "") {
      alert("Please make sure you have selected the incident type");
      return;
    }
    if (this.itemClaim.LossDamageOccuredDesc == "") {
      alert("Please make sure you have selected where the loss occured");
      return;
    }
    if(Number(this.itemClaim.totalClaimAmount) > Number(this.insuredAmount) ) {
      alert("Total claim amount exceeds insured amount, Please make sure you enter insured amount or less");
      return;
    }
    if (this.itemClaim.sapsRefNum == undefined) {
      this.itemClaim.SAPDReferenceNumber = "";
    } else {
      this.itemClaim.SAPDReferenceNumber = this.itemClaim.sapsRefNum+"/"+(<HTMLInputElement>document.getElementById("ref_month")).value+"/"+(<HTMLInputElement>document.getElementById("ref_year")).value;
    }
    this.itemClaim.R_BudgetAmount = this.itemClaim.totalClaimAmount;
    this.itemClaim.R_OriginalBudgetAmount = this.itemClaim.totalClaimAmount;
    this.itemClaim.LossDamagePrpoertyDesc = this.itemClaim.totalClaimAmount.toString();
    this.itemClaim.OccuredDate = this.itemClaim.LossDate;
    // if (this.itemClaim.R_BudgetAmount < 10000) {
    //   this.open(content);
    // }else{
      this._api.submitClaim(this.itemClaim).then(res => {
        if(res.Status){
          alert(res.Message);
          this.spinner.hide();
          this.router.navigate(['claims-home']);
        }
        else{
          this.spinner.hide();
          alert('Could not process your request now, try again');
        }
      }).catch(err=>{
        this.spinner.hide();
        alert('Could not process your request now, try again');
      });
    // }

  }
  setPersonalComputerItems(id){
    this.itemClaim.PolicySection_ID = id;
    for (let i = 0; i < this.personalComputerItems.length; i++) {
      if(this.personalComputerItems[i].PID == id){
        this.itemClaim.Endos_M_YN = this.personalComputerItems[i].Endos_M_YN;
        this.itemClaim.ItemType = this.personalComputerItems[i].ItemType;
        this.itemClaim.riskItem = this.personalComputerItems[i].ItemDescription;
        this.insuredAmount = Number(this.personalComputerItems[i].R_TotalInsuredAmount);
        //Enabled additional fields based on item type ID
        //Bicycle fields 1
      }
    }
  }
  incidentTypeChange(value){
    this.itemClaim.LossType_ID = value;
    for (let index = 0; index < this.incidentTypes.length; index++) {
      if(this.incidentTypes[index].ID == value){
        this.itemClaim.LossType = this.incidentTypes[index].Value;
      }
    }
    if (this.itemClaim.LossType === 'Theft' || this.itemClaim.LossType === 'Lost') {
      this.renderer.setStyle(this.mySapsRef.nativeElement, 'display', 'inline');
    } else {
      this.renderer.setStyle(this.mySapsRef.nativeElement, 'display', 'none');
    }

  }
  placeOfOccurance(value) {
    this.itemClaim.LossDamageOccuredDesc = value;

  }

  checkSAPSRef(){
    if ((<HTMLInputElement>document.getElementById("sapsCheck")).checked) {
      this.renderer.setStyle(this.mySapsRef.nativeElement, 'display', 'none');
    } else {
      this.renderer.setStyle(this.mySapsRef.nativeElement, 'display', 'inline');
    }
  }
  async fastTrack(value){
    this.itemClaim.FastTrack = value;
    await this.spinner.show();
    this._api.submitClaim(this.itemClaim).then(res => {
      if(res.Status){
        alert(res.Message);
        this.spinner.hide();
	      this.router.navigate(['claims-home']);
      }
      else{
        this.spinner.hide();
        alert('Could not process your request now, try again');
      }
    }).catch(err=>{
      this.spinner.hide();
      alert('Could not process your request now, try again');
    });
  }
  async open(content) {
    this.modalService.open(content, { ariaLabelledBy: 'modal-basic-title' }).result.then((result) => {
      //action yes/no buttons
      console.log("in open result =");
      console.log(result);
    }, (reason) => {
      console.log("reason:");
      console.log(reason);
    });
  }

}
