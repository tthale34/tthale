import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FridgeFreezerComponent } from './fridge-freezer.component';

describe('FridgeFreezerComponent', () => {
  let component: FridgeFreezerComponent;
  let fixture: ComponentFixture<FridgeFreezerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FridgeFreezerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FridgeFreezerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
