import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { ApiGatewayService } from 'src/app/services/api-gateway.service';

@Component({
  selector: 'app-unspecified-risk',
  templateUrl: './unspecified-risk.component.html',
  styleUrls: ['./unspecified-risk.component.scss']
})
export class UnspecifiedRiskComponent implements OnInit {
  myItems: any = [];
  currentDate: any = new Date().toISOString().slice(0, 10);
  itemClaim = {
    LossDetail: '',
    ItemDescription: '',
    OriginalSupplier: '',
    LossDamagePropertyDesc: null,
    claimTypeID: 11,
    PolicySection_ID: 0,
    HirePurchaseRefNumber: null,
    SAPDReferenceNumber: null,
    LossDamageOccuredDesc: 'my place',
    LossType_ID: 0,
    PID: 0,
    LossDate: new Date().toISOString().slice(0, 10),
    ItemsTotal :0,
    User_ID:''
  }
  incidentTypes: Array<any> = [];
  user: any;
  buidlString: string = ''   //LossDetail
  constructor(private spinner: NgxSpinnerService, private router: Router, private _api: ApiGatewayService) { }

  async ngOnInit() {
    let arr = await JSON.parse(localStorage.getItem('currentUser')).Data.PolicyItems['6'];
    this.incidentTypes = await JSON.parse(localStorage.getItem('lookUps')).l_losstypeallrisk;
    this.user = await JSON.parse(localStorage.getItem('currentUser')).Data;
    this.itemClaim.User_ID = this.user.User_ID;
    this.itemClaim.LossType_ID = this.incidentTypes[0].ID;
    for (let index = 0; index < arr.length; index++) {
      if (arr[index].ItemType_ID == 26 || arr[index].ItemType_ID == 1066) {
        await this.myItems.push(arr[index])
      }
    }
    if (this.myItems.length == 0) {
      this.router.navigate(['claims-home'])
      alert('You have no items insured')
      return;
    }

    this.itemClaim.PolicySection_ID = await this.myItems[0].PID;
    this.itemClaim.OriginalSupplier = await this.myItems[0].CellPhoneIEMI;
    this.itemClaim.ItemDescription = await this.myItems[0].ItemDescription;
  }

  nav() {
    this.router.navigate(['claims-home']);
  }

  unknownItems: Array<any> = [{ value: '' }];
  unknownItemsPrice: Array<any> = [{ value: 0 }];
  addItemValidation: boolean = true;
  showInitAdd: boolean = false;
  removeItem(idx) {
    if (idx == 0) {
      this.showInitAdd = true
    } else {
      this.showInitAdd = false;
    }

    this.unknownItems.splice(idx, 1)
    this.unknownItemsPrice.splice(idx, 1)
  }


  add() {
    if (this.unknownItems.length != 0) {
      let idx = this.unknownItems.length - 1;
      if (this.unknownItems[idx].value.length == 0 || this.unknownItemsPrice[idx].value < 1) {
        this.addItemValidation = false;
        return;
      }
    }
    this.showInitAdd = false;
    this.addItemValidation = true;
    let itemPrice = parseInt(this.unknownItemsPrice[this.unknownItemsPrice.length-1].value);
    this.unknownItems.push({ value: '' });
    this.unknownItemsPrice.push({ value: 0 });
    let test = '';

    this.itemClaim.ItemsTotal+= itemPrice;
    for (let index = 0; index < this.unknownItems.length; index++) {

      test += this.unknownItems[index].value + ":R " + this.unknownItemsPrice[index].value + ",";

    }
    test = test.substring(0, test.length - 6);
    this.itemClaim.LossDamagePropertyDesc = test;
  }

  async submit() {
    await this.spinner.show()
    this._api.submitClaim(this.itemClaim).then(res => {
      if (res.Status) {
        this.spinner.hide();
        alert(res.Message);
        this.router.navigate(['claims-home'])
        this.spinner.hide();
      }
      else {
        this.spinner.hide();
        alert("Could not process your request")
      }
    }).catch(err => {
      this.spinner.hide();
      alert("Could not process your request")
    })
  }

  placeOfOccurance(value) {
    this.itemClaim.LossDamageOccuredDesc = value
  }

  devTypeChange(value) {
    this.itemClaim.PolicySection_ID = value;
    this.itemClaim.ItemDescription
    for (let index = 0; index < this.myItems.length; index++) {
      if (this.myItems[index].PID == value) {
        this.itemClaim.OriginalSupplier = this.myItems[index].CellPhoneIEMI;
        this.itemClaim.ItemDescription = this.myItems[index].ItemDescription
        this.itemClaim.ItemDescription = this.itemClaim.LossDamagePropertyDesc
        return;
      }
    }
  }

  incidentTypeChange(value) {
    this.itemClaim.LossType_ID = value;
  }

}
