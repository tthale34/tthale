import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CaravanTrailerComponent } from './caravan-trailer.component';

describe('CaravanTrailerComponent', () => {
  let component: CaravanTrailerComponent;
  let fixture: ComponentFixture<CaravanTrailerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CaravanTrailerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CaravanTrailerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
