import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { ApiGatewayService } from 'src/app/services/api-gateway.service';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-client-claim-upload',
  templateUrl: './client-claim-upload.component.html',
  styleUrls: ['./client-claim-upload.component.scss']
})
export class ClientClaimUploadComponent implements OnInit {
  addInfo:boolean = false;
  params = {
    quoteValue:0,
    jwt:'',
    fileToUpload: File = null,
    doctype:'',
    ClaimID:'',
    documentList:[],
    sapsRefNum:'',
    OriginalSupplier:'',
    HirePurchaseRefNumber:''
  }
  invalidFile: boolean = false;
  type:any;
  claimType:String = '';
  checkClaimType:boolean = false;
  constructor(private spinner: NgxSpinnerService,private router: Router,private route: ActivatedRoute ,private formBuilder:FormBuilder,private httpClient:HttpClient,private _api: ApiGatewayService) { }
  ngOnInit(): void {
    this.route.queryParams.subscribe(params=>{
      this.params.jwt =params['jwt'];
      this.claimType =params['claimType'];
    });
    if (this.claimType == 'Theft') {
      this.checkClaimType = true;
    }
    console.log(this.checkClaimType);
  }
  addInformation(){
    console.log(this.checkClaimType);
    if(this.addInfo){
      this.addInfo = false;
    }else{
      this.addInfo = true;
    }
  }
  onFileSelect(event) {
    this.params.fileToUpload= event.target.files[0];
    // this.type = this.params.fileToUpload.name.split('.').pop();
    // if (this.type === "jpeg" || this.type === "jpg" || this.type === "pdf") {
    //   this.invalidFile = false;
    // }else{
    //   this.invalidFile = true;
    // }
    // if(this.invalidFile){
    //   alert("Please make sure you have uploaded a .jpeg or .jpg or pdf file");
    //   this.params.fileToUpload =null;
    // }
    // console.log(this.invalidFile+" : "+this.type);
  }
  async onSubmit() {
    if (this.params.documentList.length == 0) {
      alert("Please make sure you have add the documents");
      return;
    }

    await this.spinner.show();
      this._api.postUpload(this.params).then(res => {
        console.log(res)
        if(res.Status){
          alert(res.Message);
          this.spinner.hide();
          this.router.navigate(['welcome']);
        }
        else{
          this.spinner.hide();
          alert(res.Message)
        }
      }).catch(err=>{
        this.spinner.hide();
        console.log(err);
        alert(err);
      });
  }
  validateDoc(){
    if (this.params.fileToUpload == null) {
      alert("Please make sure you have selected a file");
      return false;
    }
    if (this.params.doctype == "") {
      alert("Please make sure you have selected a document type");
      return false;
    }
    return true;
  }
  addDocument(){
    if(this.validateDoc()){
      this.params.documentList.push({id:this.params.documentList.length,doc:this.params.fileToUpload,docName:this.params.fileToUpload.name,docType:this.params.doctype});
      this.params.fileToUpload = null;
      this.params.doctype = '';
    }
  }
  removeDocument(id){
    this.params.documentList = this.params.documentList.filter(item => item.id !== id);
  }


}
