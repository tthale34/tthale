import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LightVesselsComponent } from './light-vessels.component';

describe('LightVesselsComponent', () => {
  let component: LightVesselsComponent;
  let fixture: ComponentFixture<LightVesselsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LightVesselsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LightVesselsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
