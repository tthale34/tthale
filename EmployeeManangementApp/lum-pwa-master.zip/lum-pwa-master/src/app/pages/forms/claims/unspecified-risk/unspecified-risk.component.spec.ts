import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UnspecifiedRiskComponent } from './unspecified-risk.component';

describe('UnspecifiedRiskComponent', () => {
  let component: UnspecifiedRiskComponent;
  let fixture: ComponentFixture<UnspecifiedRiskComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UnspecifiedRiskComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UnspecifiedRiskComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
