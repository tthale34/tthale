import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { ApiGatewayService } from 'src/app/services/api-gateway.service';
@Component({
  selector: 'app-specified-risk',
  templateUrl: './specified-risk.component.html',
  styleUrls: ['./specified-risk.component.scss']
})
export class SpecifiedRiskComponent implements OnInit {

  currentDate: any = new Date().toISOString().slice(0, 10);
  myItems: any = [];
  itemClaim = {
    LossDetail: '',
    ItemDescription: null,
    OriginalSupplier: '',
    LossDamagePropertyDesc: null,
    claimTypeID: 11,
    PolicySection_ID: 0,
    HirePurchaseRefNumber: null,
    SAPDReferenceNumber: null,
    LossType_ID: 0,
    LossDamageOccuredDecs:'my place' ,
    LossDate: new Date().toISOString().slice(0, 10),
    PID:0,
    User_ID:''
  }
  incidentTypes:Array<any> =[];
  user:any;
  constructor(private spinner: NgxSpinnerService,private router: Router, private _api: ApiGatewayService) { }

  async ngOnInit() {
    let arr = await JSON.parse(localStorage.getItem('currentUser')).Data.PolicyItems['6']; 
    this.incidentTypes = await JSON.parse( localStorage.getItem('lookUps')   ).l_losstypeallrisk;
    this.user = await JSON.parse(localStorage.getItem('currentUser')).Data;
    this.itemClaim.User_ID = this.user.User_ID;
    //console.log(JSON.parse( localStorage.getItem('lookUps')   ).l_losstypeallrisk)
    console.log(arr[0])
    this.itemClaim.LossType_ID = this.incidentTypes[0].ID;
    for (let index = 0; index < arr.length; index++) {
      if (arr[index].ItemType_ID == 6) {
        await this.myItems.push(arr[index])
      } 
    }
    if(this.myItems.length == 0){
      this.router.navigate(['claims-home'])
      alert('You have no items insured')
      return;
    }

    this.itemClaim.PolicySection_ID = await this.myItems[0].PID;
    this.itemClaim.OriginalSupplier = await this.myItems[0].CellPhoneIEMI;
    this.itemClaim.ItemDescription = await this.myItems[0].ItemDescription;
    this.itemClaim.LossDamagePropertyDesc = await this.itemClaim.ItemDescription;
  }

  nav() {
    this.router.navigate(['claims-home']);
  }

  async submit() {
    if(this.itemClaim.OriginalSupplier.length < 1){
      alert("IMEI Number is empty")
      return;
    }
    await this.spinner.show();
    this._api.submitClaim(this.itemClaim).then(res => {
      console.log(res)
      if(res.Status){
        alert(res.Message)
        this.spinner.hide(); 
	this.router.navigate(['claims-home'])
      }
      else{
        this.spinner.hide();
        alert('Could not process your request now, try again')
      }
    }).catch(err=>{
      this.spinner.hide();
      alert('Could not process your request now, try again')
    })
  }

  placeOfOccurance(value) {
    this.itemClaim.LossDamageOccuredDecs = value
  }

  devTypeChange(value) {
    this.itemClaim.PolicySection_ID = value; 
    for (let index = 0; index < this.myItems.length; index++) {
      if (this.myItems[index].PID == value) {
        this.itemClaim.OriginalSupplier = this.myItems[index].CellPhoneIEMI;
        this.itemClaim.ItemDescription = this.myItems[index].ItemDescription
       this.itemClaim.ItemDescription = this.itemClaim.LossDamagePropertyDesc  
        return;
      }
    }
  }
  incidentTypeChange(value) {
    this.itemClaim.LossType_ID = value;
  }

}
