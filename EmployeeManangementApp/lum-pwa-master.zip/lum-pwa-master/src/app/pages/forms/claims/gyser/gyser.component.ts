import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { GlobalService } from 'src/app/helpers/globals';
import { ApiGatewayService } from 'src/app/services/api-gateway.service';

@Component({
  selector: 'app-gyser',
  templateUrl: './gyser.component.html',
  styleUrls: ['./gyser.component.scss']
})
export class GyserComponent implements OnInit {
  currentDate: any = new Date().toISOString().slice(0, 10);
  signupForm: FormGroup;
  claimTypeID: number;
  globals: GlobalService;
  claim = {
    address: "",
    lossDate: new Date().toISOString().slice(0, 10),
    property60Day: "N",
    damageDesc: "",
    PID: 0, // for new claim
    selectedBuilding: '',
    claimTypeID: null,
    User_ID:''
  };
  lookUps: any={};
  policyItems: any;
  user: any;
  myBuildings: any;
  constructor(private spinner: NgxSpinnerService, private router: Router, private _api: ApiGatewayService) {
    this.globals = new GlobalService();
    this.claimTypeID = this.globals.getClaimIDs().geyser;

  }

  async ngOnInit() {
    this.lookUps = await JSON.parse(localStorage.getItem('lookUps'));
    //  console.log( JSON.parse(localStorage.getItem('currentUser')).Data.PolicyItems)
    this.user = await JSON.parse(localStorage.getItem('currentUser')).Data;
    this.claim.User_ID = this.user.User_ID;
    this.myBuildings = await this.user.PolicyItems['1'];
    this.claim.selectedBuilding = this.myBuildings[0].PID;
    this.claim.damageDesc = this.lookUps.l_losstypegeyser[0].ID;
  }

  async submitClaim() {
    await this.spinner.show();
    this.claim.claimTypeID = await this.claimTypeID
    await this._api.submitClaim(this.claim).then(res => {
      if (res.Status) {
        alert(res.Message);
        this.router.navigate(['claims-home']);
      }
      else
        alert(res.Message);
    }).catch(err => {
      alert("Could not process your request, please try again")
    })
    this.spinner.hide()
  }

  selBuildingChange(value) {
    this.claim.selectedBuilding = value;
  }

  nav() {
    this.router.navigate(['claims-home']);
  }

  lossTypeGeyserChange(value) {
    this.claim.damageDesc = value;
  }

  property60DayChange(value) {
    this.claim.property60Day = value;
  }

}
