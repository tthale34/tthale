import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { GlobalService } from 'src/app/helpers/globals';
import { ApiGatewayService } from 'src/app/services/api-gateway.service';
import { NgxSpinnerService } from 'ngx-spinner'; 
@Component({
  selector: 'app-windscreen',
  templateUrl: './windscreen.component.html',
  styleUrls: ['./windscreen.component.scss']
})
export class WindscreenComponent implements OnInit {
  myVehicles: any = [];
  claimTypeID: number;
  globals: GlobalService;
  claim: any = {};
  lookUps: any={}; 
  lossDate:string = new Date().toISOString().slice(0, 10); 
  user:any;
  currentDate: any = new Date().toISOString().slice(0, 10);
  constructor(private spinner:NgxSpinnerService,private router: Router,private _api:ApiGatewayService) {  
    this.globals = new GlobalService();
    this.claimTypeID = this.globals.getClaimIDs().windScreen;
  }

  async ngOnInit() { 
    this.user = await JSON.parse(localStorage.getItem('currentUser')).Data;
    this.claim.User_ID = this.user.User_ID;
    console.log(this.user);
    this.myVehicles = await this.user.PolicyItems['2'];
    await this.assignCalim();  
    this.lookUps = await JSON.parse(localStorage.getItem('lookUps'));
    console.log(this.lookUps);
    this.claim.PolicySection_ID = await this.myVehicles[0].PID;
    this.claim.driver = await this.lookUps.l_driverrelationship[0].ID;
    this.claim.glassDesc = await this.lookUps.l_windscreenclaimdescription[0].ID;
    this.claim.damageDesc = await this.lookUps.l_windscreenclaimdamadge[0].ID;

  
  }

  vehicleChange(vehPID) {
    this.claim.PolicySection_ID = vehPID
  }

  vehicleControledChange(value) {
    this.claim.driver = value;
  }

  windScreenDescChange(value) {
    this.claim.glassDesc = value
   }

  windScreenDamageDescChange(value) {
    this.claim.damageDesc = value
   }

  nav() {
    this.router.navigate(['claims-home']);
  }

  async submit() {
    await this.spinner.show();
    this.claim.dateOfLoss = await this.lossDate; 
    await this._api.submitClaim(this.claim).then(res=>{
      if(res.Status){
         alert(res.Message);
         this.router.navigate(['claims-home']);
        }
         else
         alert(res.Message);
    }).catch(err=>{
       alert("Could not process your request, please try again")
    })
    this.spinner.hide()
    
  }

  assignCalim() {
    this.claim = {
      claimTypeID: this.claimTypeID,
      PID: 0,
      dateOfLoss: new Date(),
      driver: 0,
      damageDesc: 0, 
      glassDesc: 0,
    }
  }


}
