import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PersonalComputerComponent } from './personal-computer.component';

describe('PersonalComputerComponent', () => {
  let component: PersonalComputerComponent;
  let fixture: ComponentFixture<PersonalComputerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PersonalComputerComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PersonalComputerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
