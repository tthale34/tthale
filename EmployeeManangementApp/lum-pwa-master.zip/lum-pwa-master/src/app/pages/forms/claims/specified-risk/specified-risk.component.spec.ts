import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SpecifiedRiskComponent } from './specified-risk.component';

describe('SpecifiedRiskComponent', () => {
  let component: SpecifiedRiskComponent;
  let fixture: ComponentFixture<SpecifiedRiskComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SpecifiedRiskComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SpecifiedRiskComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
