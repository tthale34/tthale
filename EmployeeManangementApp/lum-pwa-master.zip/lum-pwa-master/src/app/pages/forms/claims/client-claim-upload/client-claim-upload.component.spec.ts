import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ClientClaimUploadComponent } from './client-claim-upload.component';

describe('ClientClaimUploadComponent', () => {
  let component: ClientClaimUploadComponent;
  let fixture: ComponentFixture<ClientClaimUploadComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ClientClaimUploadComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ClientClaimUploadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
