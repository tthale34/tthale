import { Component, OnInit } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';
import { ApiGatewayService } from 'src/app/services/api-gateway.service';
import { Router } from '@angular/router';
import { AuthenticationService } from '../../services/authentication.service';
import { GlobalService } from '../../helpers/globals';


@Component({
  selector: 'app-broker-dashboard',
  templateUrl: './broker-dashboard.component.html',
  styleUrls: ['./broker-dashboard.component.scss']
})
export class BrokerDashboardComponent implements OnInit {
  private global_service = new GlobalService();
  clients: boolean = false;
  open_claims: boolean = false;
  renewals: boolean = false;
  cancelled: boolean = false;
  financials: boolean = false;
  selectors: boolean = true;
  addNoteFields:boolean = false;
  addNoteLink:boolean = true;
  user: any;
  myClaims: Array<any> = [];
  myClients: Array<any> = [];
  itemsShown: Array<any> = [];
  totalCommission:number;
  AuthToken:any;
  openClaimText:'';
  myUrl:string = '';
  constructor(private spinner: NgxSpinnerService,private _api: ApiGatewayService,private router: Router,private auth_api: AuthenticationService) { }

  async ngOnInit() {
    this.user = await JSON.parse(localStorage.getItem('currentUser')).Data;
    console.log(this.user);
    if (this.AuthToken == null || this.AuthToken == undefined) {
      this.AuthToken = await localStorage.getItem('jwt');
    }
    this.myUrl = this.global_service.baseUrl.substring(0,this.global_service.baseUrl.length-4);
  }
  async changeView(main = true,changeTo = ''){
    if(main){
      this.clients = false;
      this.open_claims = false;
      this.renewals = false;
      this.cancelled = false;
      this.financials = false;
      this.selectors = true;
    }else{
      if(changeTo == "openClaims"){
        this.clients = false;
        this.open_claims = true;
        this.renewals = false;
        this.cancelled = false;
        this.financials = false;
        this.selectors = false;
        this.submit(changeTo);
      }
      if(changeTo == "getClients"){
        this.clients = true;
        this.open_claims = false;
        this.renewals = false;
        this.cancelled = false;
        this.financials = false;
        this.selectors = false;
        this.submit(changeTo);
      }
      if(changeTo == "renewals"){
        this.clients = false;
        this.open_claims = false;
        this.renewals = true;
        this.cancelled = false;
        this.financials = false;
        this.selectors = false;
        this.submit(changeTo);
      }
      if(changeTo == "cancelledClients"){
        this.clients = false;
        this.open_claims = false;
        this.renewals = false;
        this.cancelled = true;
        this.financials = false;
        this.selectors = false;
        this.submit(changeTo);
      }
      if(changeTo == "financials"){
        this.clients = false;
        this.open_claims = false;
        this.renewals = false;
        this.cancelled = false;
        this.financials = true;
        this.selectors = false;
        this.submit(changeTo);       
      }
      if(changeTo == "switchClient"){
        this.router.navigate(['broker-advisor-view']);
      }
    }
  }
  updateClientResult(event){
    this.submit("cancelledClients",event.target.checked);    
  }
  async submit(value,lastYearClients = false,claimID =0,note=''){
    await this.spinner.show();
    await this._api.getBrokerDetails(value,lastYearClients,claimID,note).subscribe(res => {
      if (res.Status) {
        console.log(res.Message);
        if(res.Message === "Your open claims"){
            this.myClaims = res.Result.Data;
        }else{          
          if(value == "financials"){
            this.totalCommission  = 0;
            for (let i = 0; i < res.Result.Data.length; i++) {
              this.totalCommission = Number(res.Result.Data[1].Commission) + this.totalCommission;
            }
            this.totalCommission = Number(this.totalCommission.toFixed(2));
          }
          this.myClients = res.Result.Data;
        }
      }
      else
        alert("Could not process your request now, Please try again later")
    }, err => {
      alert("Could not process your request now, Please try again later")
    });
    await this.spinner.hide();
  }
  async goToClient(value,policyID){
    await this.spinner.show();
    await this.auth_api.changeUserAccount(value,policyID,this.AuthToken).subscribe((res) => {
      if (res.Status) {
        localStorage.setItem('jwt',res.jwt); 
        localStorage.setItem('token',res.jwt);
        let x =  localStorage.getItem('jwt');
        
        this.router.navigate(['welcome']);        
      } else {       
        alert(res.Message);
      }
    }, err => {
      alert("Could not change to client account.");
    });
    await this.spinner.hide();
  }
  displayItem(value){
    let element = document.getElementById(value);
    let currentElementID;
    for (let i = 0; i < this.itemsShown.length; i++) {
      if (this.itemsShown[i].id == value) {
        currentElementID = i;
      }      
    }
    if (currentElementID == undefined) {
      element.style.border = '2px solid black';
      element.style.borderRadius = '10px';
      element.style.marginBottom = '5px';
      element.style.display = 'inline';
      this.itemsShown.push({id:value,shown:true});
    }else{
      if (this.itemsShown[currentElementID].shown) {
        element.style.display = 'none';
        this.itemsShown[currentElementID].shown = false;
      }else{
        element.style.border = '2px solid black';
        element.style.borderRadius = '10px';
        element.style.marginBottom = '5px';
        element.style.display = 'inline';
        this.itemsShown[currentElementID].shown = true;
      }
    }  
  }
  addNoteFieldsMethod(value){
    if(this.addNoteFields) {
      this.submit("addClaimNote",false,value,this.openClaimText);
      this.addNoteFields = false;
      this.addNoteLink = true;        
      
    } else {
      this.addNoteFields = true;
      this.addNoteLink = false;
    }
  }
}
