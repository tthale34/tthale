import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FicaComponent } from './fica.component';

describe('FicaComponent', () => {
  let component: FicaComponent;
  let fixture: ComponentFixture<FicaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FicaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FicaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
