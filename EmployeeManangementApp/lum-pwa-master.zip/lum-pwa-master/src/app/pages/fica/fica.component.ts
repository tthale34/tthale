import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ApiGatewayService } from 'src/app/services/api-gateway.service';

@Component({
  selector: 'app-fica',
  templateUrl: './fica.component.html',
  styleUrls: ['./fica.component.scss']
})
export class FicaComponent implements OnInit {
  ficaDetails: any

  constructor(private router: Router, private _api: ApiGatewayService) { }

  ngOnInit(): void { 
    console.log(this.ficaDetails = JSON.parse(localStorage.getItem('userProfile')))

    // if()

    // console.log(this.ficaDetails = JSON.parse(localStorage.getItem('currentUser')))
    this.ficaDetails = this.ficaDetails.Data;
  }

  showError: boolean = false;
  submitForm() {
    this._api.verifyFicaDetails().subscribe(res=>{
      if(res.Status)
      this.router.navigate(['welcome']);
      else
      alert('Could not Verify your details now')
    })
    
  }

}

export interface IFica {
  ClientCell: string,
    Surname: string, 
    ClientEmail:string,
}
