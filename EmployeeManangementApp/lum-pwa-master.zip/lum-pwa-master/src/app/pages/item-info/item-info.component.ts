import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { ApiGatewayService } from 'src/app/services/api-gateway.service';

@Component({
  selector: 'app-item-info',
  templateUrl: './item-info.component.html',
  styleUrls: ['./item-info.component.scss']
})
export class ItemInfoComponent implements OnInit {
  myInsuredItem: any = {}
  newItem = {
    itemDescNewItem: null,
    itemAMTNewItem: null,
    itemType: 'Motor Vehicle'
  }
  isRemove: boolean = false;
  isEdit: boolean = false;
  removeDate: any = new Date().toISOString().slice(0, 10);
  currDate: any = new Date().toISOString().slice(0, 10); //used to disable past dates
  newItemDescription: string;
  newR_TotalInsuredAmount: number;
  isNewItem: boolean = false;
  showAddVehicle = false;
  user: any = {};
  AuthToken:any;
  constructor(private spinner:NgxSpinnerService,private router: Router, private _api: ApiGatewayService, private activatedRoute: ActivatedRoute) {

  }

  async ngOnInit() {
    if (this.activatedRoute.snapshot.queryParamMap.has('newItem')) {
      if (this.activatedRoute.snapshot.queryParamMap.get('newItem')) {
        this.isNewItem = true;
      }
    } else {
      if (localStorage.getItem('insuredItem') == undefined) {
        this.router.navigate(['welcome']);
        alert('Could not process your request, try again')
        return;
      }
      this.myInsuredItem = await JSON.parse(localStorage.getItem('insuredItem'));
      this.myInsuredItem.R_TotalInsuredAmount = 'R ' + this.myInsuredItem.R_TotalInsuredAmount;
    }
    this.user = await JSON.parse(localStorage.getItem('currentUser')).Data;
    // console.log(this.user.IDNumber);
    // var usersId = await JSON.parse(localStorage.getItem('currentUser')).Data.User_ID;

    if(this.user.IDNumber == '7510070003083' || this.user.IDNumber == '771017503083' || this.user.usersId == 16726 || this.user.usersId == 16272)
    {
        this.showAddVehicle = true;
    }

  }
  newItemChange(value) {
    //adding new item
    this.newItem.itemType = value;
    // alert(value);
    if(value == "Motor Vehicle")
    {
      this.router.navigate(['/my-add-vehicle']);
    }
    // code to redirect to my-vehicle-add screen if vehicle is selected
  }
  itemAction(action: string) {
    if (action == 'remove') {
      this.isRemove = true;
      this.isEdit = false;
      document.getElementById('removeBtn').style.background = '#2f4364'
      document.getElementById('editBtn').style.background = '#fff'

    } else {
      this.isEdit = true;
      this.isRemove = false;
      document.getElementById('editBtn').style.background = '#2f4364';
      document.getElementById('removeBtn').style.background = '#fff'
    }
  }
  
  async submit() {
    //Refresh users data after removing an policy item
    if (this.AuthToken == null || this.AuthToken == undefined) {
      this.AuthToken = await localStorage.getItem('jwt');
    }    
    await this.spinner.show();
    await this._api.refreshUserData(this.AuthToken).subscribe((res) => {
    console.log(res);
    location.reload();
    location.reload();
    }, err => {
      alert("Errors encountered"+err);
    });
    //Edit new item
    if (this.isNewItem) {
      await this._api.modifyItems(this.newItem, 'add').then(res => {
        if (res.Status) {
          alert(res.Message);
           this.router.navigate(['welcome'], {
            queryParams:{deleted:true,result:res.Result}
          });
        } else{
          alert('We    again')
     this.spinner.hide();
    }
      }).catch(err => {
        this.spinner.hide()
        alert('We could not process your request now, try again')
      })
      return;
    }
    //Remove item
    if (this.isRemove) {
      this.router.navigate(['welcome'], {
        queryParams:{deleted:true,pid:this.myInsuredItem.PID}
      });      
      //Remove policy item from data
      await this._api.modifyItems({ itemID: this.myInsuredItem.PID, removeDate: this.removeDate }, 'remove').then(res => {
        if (res.Status) {
          alert(res.Message);
          this.router.navigate(['welcome'], {
            queryParams:{updated:true,pid:this.myInsuredItem.PID}
          });
        } else{
          alert('We could not remove the item, try again:'+res.Message);
          this.spinner.hide();
        }
      }).catch(err => {
        alert(err);
        this.spinner.hide();
      })
      // return;
    }

    if (this.isEdit) {
      this._api.modifyItems({
        itemID: this.myInsuredItem.PID,
        removeDate: this.removeDate,
        oldItemDescription: this.myInsuredItem.ItemDescription,
        newItemDescription: this.newItemDescription,
        oldInsuredValue: this.myInsuredItem.R_TotalInsuredAmount,
        newInsuredValue: this.newR_TotalInsuredAmount
      }, 'edit').then(res => {

        if (res.Status) {
          this.spinner.hide();
          this.router.navigate(['welcome']);
          alert(res.Message);          
        } else{
          alert('We could not process your request now, try again')
          this.spinner.hide();
        }
      }).catch(err => {
        alert('We could not process your request now, try again')
        this.spinner.hide()
      })
      return;
    }

  }

  nav() {
    this.router.navigate(['welcome'])
  }
  ngOnDestroy() {
    localStorage.removeItem('insuredItem');
  }

}
