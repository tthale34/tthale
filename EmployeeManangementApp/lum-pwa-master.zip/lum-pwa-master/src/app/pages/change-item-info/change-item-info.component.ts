import { Component, OnInit,Renderer2,ViewChild , ElementRef } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient} from '@angular/common/http';
import { ApiGatewayService } from 'src/app/services/api-gateway.service';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-change-item-info',
  templateUrl: './change-item-info.component.html',
  styleUrls: ['./change-item-info.component.scss']
})
export class ChangeItemInfoComponent implements OnInit {
  restrictFuntion:boolean = false;
  @ViewChild('div') div: ElementRef;
  htmlToAdd:any;
  changeItemView:boolean = false;
  selectHomeContents:boolean = true;
  action:'';
  homeContents:Array<any> =[];
  homeContentAddress:Array<any> =[];
  homeContentsItems:Array<any> =[];
  updateItems:boolean=false;
  DateCoverStart:'';
  data:Array<any> =[];
  userPostalAddress = {
    PostalAddressLine1:'',
    PostalAddressLine2:'',
    Suburb_ID:0,
    Suburb:'',
    City_ID:0,
    City:"",
    PostalCode:'',
    Client_ID:0,
    ChangedSuburbOrCity1:'',
  }
  userResAddress = {
    AddressRes1:'',
    AddressRes2:'',
    AddressResSuburb_ID:0,
    AddressResSuburb:'',
    AddressResCity_ID:0,
    AddressResCity:'',
    AddressResPostalCode:'',
    AddressResArea_ID:0,
    Client_ID:0,
    changeAllRisk:'',
    changeClientAddress:'',
    riskItems:[],
    InsuredAddressLine1:'',
    InsuredAddressLine2:'',
    InsuredAddressSuburb_ID:0,
    InsuredAddressSuburb:'',
    InsuredAddressCity_ID:0,
    InsuredAddressCity:'',
    InsuredAddressPostalCode:'',
    ItemDescription:'',
    PID:'',
    ChangedSuburbOrCity2:'',
  }
  insuredAddress = {
    InsuredAddressLine1:'',
    InsuredAddressLine2:'',
    InsuredAddressSuburb_ID:0,
    InsuredAddressSuburb:'',
    InsuredAddressCity_ID:0,
    InsuredAddressCity:'',
    InsuredAddressPostalCode:'',
    InsuredAddressArea_ID:0,
    ItemDescription:'',
    Client_ID:0,
    User_ID:0,
    changeAllRisk:'',
    CoverStartDate:new Date().toISOString().slice(0, 10),
    PID:'',
    riskItems:[],
    clientAddress:'',
    ChangedSuburbOrCity3: ''
  }
  showRiskItems:boolean = false;
  riskItem:Array<any> =[];
  selectedHomeContent:'';
  // to review
  Suburb = "";
  Suburbs = [];
  CitiesIDs = [];
  addressResCitySub: number;
  Cities = [];
  url="";
  edit_sub_name:string="";
  edit_city_id = "";
  edit_suburbIDLIST = [];
  Policy_ID:0;
  Client_ID:0;


  constructor(private router: Router,private renderer: Renderer2,private http: HttpClient,private _api: ApiGatewayService,private spinner: NgxSpinnerService) { }

  async ngOnInit(){
    this.homeContents = await JSON.parse(localStorage.getItem('currentUser')).Data.PolicyItems['9'];
    if(await JSON.parse(localStorage.getItem('currentUser')).Data.PolicyItems['1']){
      this.homeContents.push(await JSON.parse(localStorage.getItem('currentUser')).Data.PolicyItems['1']);
    }
    this.Policy_ID=await JSON.parse(localStorage.getItem('currentUser')).Data.Policy_ID;
    this.Client_ID=await JSON.parse(localStorage.getItem('currentUser')).Data.Client_ID;
    this.insuredAddress.User_ID=await JSON.parse(localStorage.getItem('currentUser')).Data.User_ID;

    if(this.insuredAddress.User_ID == 19325 || this.insuredAddress.User_ID == 2125){
      this.restrictFuntion = true;
    }else{
      this.restrictFuntion = false;
    }
    this.setAddresses(this.Policy_ID);
    this.setAllRiskItems();

  }
  setRiskItemCheck(value){
    if(this.insuredAddress.riskItems[value].Status){
      this.insuredAddress.riskItems[value].Status = false;
    }else{
      this.insuredAddress.riskItems[value].Status = true;
    }
  }
  setAllRiskItems(){
    this.spinner.show();
    this._api.getPostalAdd(this.Policy_ID,'getAllItems',this.selectedHomeContent).then(res => {
        for (let i = 0; i < res.length; i++) {
          this.insuredAddress.riskItems.push({ItemDescription:res[i].ItemDescription,PID:res[i].PID,Status:false});
        }
      this.spinner.hide();
    }).catch(err=>{
      this.spinner.hide();
      alert('Could not process your request now, try again');
    });
  }
  setItemAddresses(){
    this.spinner.show();
    this._api.getPostalAdd(this.Policy_ID,'getHomeContentAddress',this.selectedHomeContent).then(res => {

      if(res.Status){
        if (this.userResAddress.changeClientAddress == "Y") {
          this.userResAddress.InsuredAddressLine1 = res.InsuredAddressLine1;
          this.userResAddress.InsuredAddressLine2 = res.InsuredAddressLine2;
          this.userResAddress.InsuredAddressSuburb_ID = res.InsuredAddressSuburb_ID;
          this.userResAddress.InsuredAddressSuburb = res.InsuredAddressSuburb;
          this.userResAddress.InsuredAddressCity_ID = res.InsuredAddressCity_ID;
          this.userResAddress.InsuredAddressCity = res.InsuredAddressCity;
          this.userResAddress.InsuredAddressPostalCode = res.InsuredAddressPostalCode;
          this.userResAddress.ItemDescription = res.ItemDescription;
        }else{
          this.insuredAddress.InsuredAddressLine1 = res.InsuredAddressLine1;
          this.insuredAddress.InsuredAddressLine2 = res.InsuredAddressLine2;
          this.insuredAddress.InsuredAddressSuburb_ID = res.InsuredAddressSuburb_ID;
          this.insuredAddress.InsuredAddressSuburb = res.InsuredAddressSuburb;
          this.insuredAddress.InsuredAddressCity_ID = res.InsuredAddressCity_ID;
          this.insuredAddress.InsuredAddressCity = res.InsuredAddressCity;
          this.insuredAddress.InsuredAddressPostalCode = res.InsuredAddressPostalCode;
          this.insuredAddress.ItemDescription = res.ItemDescription;
        }
        console.log(res);
      }
      this.spinner.hide();
    }).catch(err=>{
      this.spinner.hide();
      alert('Could not process your request now, try again');
    });
  }
  setAddresses(value){
    this.spinner.show();
    this._api.getPostalAdd(value,'setAddresses').then(res => {
      console.log(res);
      if (res.Status) {
        this.userPostalAddress.PostalAddressLine1 = res.PostalAddressLine1;
        this.userPostalAddress.PostalAddressLine2 = res.PostalAddressLine2;
        this.userPostalAddress.Suburb = res.Suburb;
        this.userPostalAddress.Suburb_ID = res.Suburb_ID;
        this.userPostalAddress.City = res.City;
        this.userPostalAddress.City_ID = res.City_ID;
        this.userPostalAddress.PostalCode = res.PostalCode;

        this.userResAddress.AddressRes1 = res.AddressRes1;
        this.userResAddress.AddressRes2 = res.AddressRes2;
        this.userResAddress.AddressResSuburb = res.AddressResSuburb;
        this.userResAddress.AddressResSuburb_ID = res.AddressResSuburb_ID;
        this.userResAddress.AddressResCity = res.AddressResCity;
        this.userResAddress.AddressResCity_ID = res.AddressResCity_ID;
        this.userResAddress.AddressResPostalCode = res.AddressResPostalCode;
      }
      this.spinner.hide();
    }).catch(err=>{
      this.spinner.hide();
      console.log(err);
      alert('Could not process your request now, try again');
    });
  }
  selectView(){
    this.changeItemView=true;
  }
  nav(){
    this.router.navigate(['welcome']);
  }
  navBack(){
    this.router.navigate(['change-item-info']);
  }
  selHomeContent(value){
    this.action = value;
    if(value != 'risk_address'){
      this.selectHomeContents=true;
    }else{
      this.selectHomeContents=false;
    }

  }
  getSuburbByName(suburb_name:string) {
    this.Suburbs = [];
    if(suburb_name.length >= 4){
      this.Suburbs.push("Select Suburb");
      this.Suburbs.push("Select Suburb");
      this.Suburbs.push("Select Suburb");
      this.url = "https://mypolicy.lum.co.za/api/api/getSuburbs.php?suburb_name=" + encodeURIComponent(suburb_name);
      this.http.get(this.url).toPromise().then(
        data => {
          // console.log(data);
          for (let key in data) {
            if (data.hasOwnProperty(key)){
              // this.userPostalAddress.Suburb_ID=data[key].PID;
              // this.userResAddress.AddressResSuburb_ID=data[key].PID;
              // this.insuredAddress.InsuredAddressSuburb_ID=data[key].PID;

              this.Suburbs.push(data[key]);
              this.CitiesIDs.push(data[key].City_ID);

              console.log(data[key].PID);
            }

          }
            console.log(this.Suburbs);
          }

        ).catch(e => {
            console.log(e.message);
        });
        console.log(this.url);
      // search suburb
      this.getCitiesBySuburbName(suburb_name);
      // console.log(this.CitiesIDs);
    }

  }

  getCitiesBySuburbName(suburbName=""){
    this.Cities = [];
    this.url = "https://mypolicy.lum.co.za/api/api/getCity.php?suburb_name=" + encodeURIComponent(suburbName);
        this.http.get(this.url).toPromise().then(
          data => {
            console.log(data);
            for (let key in data)
              if (data.hasOwnProperty(key)){
                //
                // this.userResAddress.AddressResCity_ID=data[key].PID;
                this.userResAddress.AddressResCity_ID=data[key].city_id;
                this.userResAddress.AddressResCity=data[key].City2;
                this.userResAddress.ChangedSuburbOrCity2 = 'Y';
                this.userResAddress.AddressResPostalCode=data[key].pcode;
                this.userResAddress.AddressResSuburb_ID=data[key].suburbid;
                this.userResAddress.AddressResArea_ID=data[key].Area_ID;
                // changeClientAddress:'',
                // this.userResAddress.AddressResArea_ID=data[key].Area_ID;
                // Area_ID
                // this.userPostalAddress.City_ID=data[key].PID;
                this.userPostalAddress.City_ID=data[key].city_id;
                this.userPostalAddress.City=data[key].City2;
                this.userPostalAddress.PostalCode=data[key].pcode;
                this.userPostalAddress.ChangedSuburbOrCity1='Y';
                this.userPostalAddress.Suburb_ID=data[key].suburbid;
                // this.userResAddress.AddressResCity_ID=data[key].PID;
                this.insuredAddress.InsuredAddressCity_ID=data[key].city_id;
                this.insuredAddress.InsuredAddressCity=data[key].City2;
                this.insuredAddress.InsuredAddressArea_ID=data[key].Area_ID;
                this.insuredAddress.ChangedSuburbOrCity3='Y';
                this.insuredAddress.InsuredAddressPostalCode=data[key].pcode;
                this.insuredAddress.InsuredAddressSuburb_ID=data[key].suburbid;
                // changeClientAddress
                // this.insuredAddress.InsuredAddressArea_ID=data[key].Area_ID;
                // console.log(data[key].PID);
                // this.insuredAddress.InsuredAddressCity_ID=data[key].city_id;
                // this.insuredAddress.InsuredAddressCity=data[key].City2;
                this.Cities.push(data[key]);
                console.log(data[key].suburbid);
              }
              console.log(data);
            }

          ).catch(e => {
            console.log(e);
        });
  }
  updateCheckedItems(value){
    let temp = this.homeContentsItems[value].Checked;
    if(temp == 'N'){
      this.homeContentsItems[value].Checked = 'Y';
    }else{
      this.homeContentsItems[value].Checked = 'N';
    }
  }
  setCityID(){

    console.log(this.userResAddress.AddressResSuburb_ID);
    console.log(this.Suburbs);
    console.log(this.Cities);
  }
  async submit(value){
    this.spinner.show();
    if (value === 'postal_address') {
      this.userPostalAddress.Client_ID=this.Client_ID;

      await this._api.getPostalAdd(this.Policy_ID,'updatePostalAddress',this.userPostalAddress).then(res => {
        console.log(this.userPostalAddress);
        this.spinner.hide();
      }).catch(err=>{
        this.spinner.hide();
        alert('Could not process your request now, try again');
      });
    }
    if (value == 'client_profile') {
      this.userResAddress.Client_ID=this.Client_ID;
      this.userResAddress.riskItems=this.insuredAddress.riskItems;
      this.userResAddress.PID = this.selectedHomeContent;
      // this.userResAddress.AddressResSuburb=(<HTMLInputElement>document.getElementById("suburbs")).value;
      // this.userResAddress.AddressResCity=(<HTMLInputElement>document.getElementById("unitPrice")).value;
      // alert(this.userResAddress.AddressResSuburb_ID);
      await this._api.getPostalAdd(this.Policy_ID,'updateResAddress',this.userResAddress).then(res => {
        console.log(res);
        this.spinner.hide();

        console.log(this.userResAddress);
        // alert(this.userResAddress.changeClientAddress);
      }).catch(err=>{
        this.spinner.hide();
        alert('Could not process your request now, try again');
      });
    }
    if (value == 'risk_address') {
      if(this.insuredAddress.changeAllRisk == ''){
        alert("Please make sure you have selected if you want to update risk items.");
        this.spinner.hide();
        return;
      }
      this.insuredAddress.Client_ID = this.Client_ID;
      this.insuredAddress.PID = this.selectedHomeContent;
      await this._api.getPostalAdd(this.Policy_ID,'updateHomeAddress',this.insuredAddress).then(res => {
        console.log(res);
        this.spinner.hide();
      }).catch(err=>{
        this.spinner.hide();
        alert('Could not process your request now, try again');
      });
    }
    alert("Changes have been submitted successfully.");
    this.router.navigate(['welcome']);
  }
  preventKeyPress(event:any){
    alert("Please use date select button to update the date");
    this.insuredAddress.CoverStartDate=new Date().toISOString().slice(0, 10);
  }

}
