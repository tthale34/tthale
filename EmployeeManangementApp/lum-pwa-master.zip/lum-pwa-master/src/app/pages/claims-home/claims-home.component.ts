import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-claims-home',
  templateUrl: './claims-home.component.html',
  styleUrls: ['./claims-home.component.scss']
})
export class ClaimsHomeComponent implements OnInit {
  route: string = 'my-claims';
  policyprefixbool: boolean = false;
  constructor(private router: Router) { }

  ngOnInit(): void {
    if (JSON.parse(localStorage.getItem('currentUser')).Data.PolicyPrefix === "TG") {
      this.policyprefixbool = true;
    }
  }

  nav(section) {
    this.router.navigate([this.route],
      {
        queryParams: { section: section }
      }

    )
  }

}
