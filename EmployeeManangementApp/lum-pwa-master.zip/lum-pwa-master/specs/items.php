<?php
    function updateItem($pid=-991){
      global $LMSDB;
        fixObject($_SESSION['User']);

          //Update all 3 items
      $sql  = " UPDATE PolicySection SET ";
      $sql .=  " ServerDateTime = '".date('Y-m-d H:i:s.000')."' ";

      if($_POST['PolicySection_ID'] == 2 && $_POST['car_excess'] == 15){
        $sql .= ", ExcessOption_ID = 4, ExcessRand = '2000' ";
      }
      else if($_POST['PolicySection_ID'] == 2 && $_POST['car_excess'] != 15){
        $sql .= ", ExcessOption_ID = '3', ExcessRand = '' ";
      }

      $do_not_update = array("pid", "SportsType_ID","LockedInSafeYN","PhotographicType_ID","Purpose_ID","R_HHNonStandardInsuredAmount","IsRegularDriverYN","ClientSurname","ClientInitials","ClientIdNumber","dIdNumber","add_more","ClothingYN","ReinstallDataYN","addAnother", "SubTypeId", "auto-suburb", "car_excess", "Policy_Prev_Insured");

      foreach($_POST as $key => $value){
        if(!in_array($key,$do_not_update)) {

          //Get NCB for Car and Home content
          //Car
          if((isset($_POST['PolicySection_ID']) && $_POST['PolicySection_ID'] == 2) && $key=='LastClaim_ID'){
            if($_POST['Policy_Prev_Insured'] == 12){
              if($value == 1){ $sql .= ", ClaimFreeGroup_ID = 2"; }
              else if($value == 2){ $sql .= ", ClaimFreeGroup_ID = 2"; }
              else if($value == 4){ $sql .= ", ClaimFreeGroup_ID = 4"; }
              else if($value == 6){ $sql .= ", ClaimFreeGroup_ID = 4"; }
              else if($value == 8){ $sql .= ", ClaimFreeGroup_ID = 4"; }
            }
            else if($_POST['Policy_Prev_Insured'] == 24){
              if($value == 1){ $sql .= ", ClaimFreeGroup_ID = 2"; }
              else if($value == 2){ $sql .= ", ClaimFreeGroup_ID = 3"; }
              else if($value == 4){ $sql .= ", ClaimFreeGroup_ID = 5"; }
              else if($value == 6){ $sql .= ", ClaimFreeGroup_ID = 5"; }
              else if($value == 8){ $sql .= ", ClaimFreeGroup_ID = 5"; }
            }
            else if($_POST['Policy_Prev_Insured'] == 36){
              if($value == 1){ $sql .= ", ClaimFreeGroup_ID = 4"; }
              else if($value == 2){ $sql .= ", ClaimFreeGroup_ID = 4"; }
              else if($value == 4){ $sql .= ", ClaimFreeGroup_ID = 4"; }
              else if($value == 6){ $sql .= ", ClaimFreeGroup_ID = 6"; }
              else if($value == 8){ $sql .= ", ClaimFreeGroup_ID = 6"; }
            }
            else if($_POST['Policy_Prev_Insured'] == 48){
              if($value == 1){ $sql .= ", ClaimFreeGroup_ID = 4"; }
              else if($value == 2){ $sql .= ", ClaimFreeGroup_ID = 5"; }
              else if($value == 4){ $sql .= ", ClaimFreeGroup_ID = 5"; }
              else if($value == 6){ $sql .= ", ClaimFreeGroup_ID = 7"; }
              else if($value == 8){ $sql .= ", ClaimFreeGroup_ID = 7"; }
            }
            else if($_POST['Policy_Prev_Insured'] >= 60){
              if($value == 1){ $sql .= ", ClaimFreeGroup_ID = 4"; }
              else if($value == 2){ $sql .= ", ClaimFreeGroup_ID = 6"; }
              else if($value == 4){ $sql .= ", ClaimFreeGroup_ID = 6"; }
              else if($value == 6){ $sql .= ", ClaimFreeGroup_ID = 8"; }
              else if($value == 8){ $sql .= ", ClaimFreeGroup_ID = 8"; }
            }
          }
          //Home Content


          if($key=='M1Option_ID') {
            $sql .= ", ".$key. " = '".FixStringForDatabase($value)."' ";
            /*if($value=='1' or $value=='2') {
              $sql .= ", CarRentalYN = 'Y' ";
            } else {
              $sql .= ", CarRentalYN = 'N' ";
            }*/
          } else if(($key=='R_HHADInsuredAmount') && ($value > 1)) {
            $sql .= ", ".$key. " = '".FixStringForDatabase($value)."' ";
            $sql .= ", AccidentalDamageYN = 'Y' ";
          }  else if($key=='CylinderCapacity') {
            $sql .= ", ".$key. " = '".FixStringForDatabase($value)."' ";
            $sql .= ", ClaimFreeGroup_ID = case year(now()) - ".$_REQUEST['DriverLicenceIssueDate']."
                when 0 then 1
                when 1 then 2
                when 2 then 3
                when 3 then 4
                else 5 end ";
          } else if(($key=='R_AdditionalOtherAmount') && ($value > 1 )) {
            $sql .= ", ".$key. " = '".FixStringForDatabase($value)."' ";
            $sql .= ", AdditionalItemYN = 'Y' ";
            $sql .= ", AdditionalCoverYN = 'Y' ";
          } else if($key=='R_Retail') {
            $sql .= ", ".$key. " = '".FixStringForDatabase($value)."' ";
            $sql .= ", R_TotalInsuredAmount = '".FixStringForDatabase($value)."' ";
          } else if($key=='R_InsuredAmount') {
            $sql .= ", ".$key. " = '".FixStringForDatabase($value)."' ";
            if($_POST['PolicySection_ID'] != 8){//Exclude Caravan/trailer
              $sql .= ", R_TotalInsuredAmount = '".FixStringForDatabase($value)."' ";
            }
          } else if($key=='DriverBirthDate') {
             //CALC AGE
            $sql .= ", ".$key. " = '".FixStringForDatabase($value)."' ";
            $sql .= ", DriverAge = datediff (yy, cast('".FixStringForDatabase($value)."' as date), cast(now() as date)) ";
            $sql .= ", pensiondiscountyn = if datediff (yy, cast('".FixStringForDatabase($value)."' as date), cast(now() as date)) >=55 then 'Y' else 'N' endif ";
          } else if($key=='DriverLicenceIssueDate') {
             //CALC AGE - DriverPeriodLicence
            $sql .= ", ".$key. " = '".FixStringForDatabase($value)."' ";
            $sql .= ", DriverPeriodLicence = datediff (yy, cast('".FixStringForDatabase($value)."' as date), cast(now() as date)) ";
            }  else {
             $sql .= ", ".$key. " = '".FixStringForDatabase($value)."'";
          }
        }
      }
          $sql .= " where ((PID = ".$pid.") or ((parent_id=" . $pid . ") and (ifnull(parent_id,0,parent_id)>0))); commit;";
          $error = $LMSDB->sql_error($LMSDB->sql_query($sql));

          $vSectionIdSql = "SELECT ps.PID AS Item_ID, p.PID AS Policy_ID, p.Insurer_ID FROM policysection ps LEFT JOIN policy p ON p.PID = ps.Policy_ID ";
          $vSectionIdSql .= "WHERE ps.PID = ".$pid." OR ps.parent_ID = ".$pid;
          $vResultSections = $LMSDB->sql_query($vSectionIdSql);

          //Create Policy array for Hollard, Santam, OMI
          $vPolicyArray = array();
      while($sectionResults = $LMSDB->sql_fetchrow($vResultSections)){
        $vPolicyArray['policy_id'][] = $sectionResults['Policy_ID'];
        $vPolicyArray['item_id'][] = $sectionResults['Item_ID'];
      }
      $LMSDB->sql_freeresult($vResultSections);

      //Endorsements START
          if($_POST['PolicySection_ID'] == 2 && $_POST['car_excess'] > 0){
          if($_POST['car_excess'] == 10 && (isset($_SESSION['lmsquote']['Policy_ID']) && $_SESSION['lmsquote']['Policy_ID'] > 0)){
            //Check if exist and is DeleteYN = N
              $vSqlSelectExist = "SELECT IFNULL(count(Endorsement_ID), 0, count(Endorsement_ID)) AS numExist FROM PolicyEndorsement WHERE Policy_ID = ".$_SESSION['lmsquote']['Policy_ID']." AND ";
              $vSqlSelectExist .= "PolicySection_ID = ".$_POST['PolicySection_ID']." AND Endorsement_ID = 1381 AND DeletedYN = 'N'";
              $vEndosExist = $LMSDB->sql_fetchrow($LMSDB->sql_query($vSqlSelectExist));

              for($x = 0; $x < count($vPolicyArray['policy_id']); $x++){
            $sqlSG = "CALL LOL_Add_Policy_SpecialGroup(".$vPolicyArray['policy_id'][$x].", 'R', 15, ".$_SESSION['lmsquote']['UserName_ID'].")";
            $LMSDB->sql_query($sqlSG);
            $vSqlStringH = "call LOL_Add_Policy_History_Log(".$vPolicyArray['policy_id'][$x].", ".$_POST['PolicySection_ID'].", ".$vPolicyArray['item_id'][$x].", 3, ".$_SESSION['lmsquote']['UserName_ID'].", 'Special Group Removed - AX');";
                $LMSDB->sql_query($vSqlStringH);
                //Endorsement Remove
                deleteEndorsement($vPolicyArray['policy_id'][$x], $_POST['PolicySection_ID'], 2491, $vPolicyArray['item_id'][$x]);
              }

              if($vEndosExist['numExist'] == 0){
                for($e = 0; $e < count($vPolicyArray['policy_id']); $e++){
              $sqlSG1 = "CALL LOL_Add_Policy_SpecialGroup(".$vPolicyArray['policy_id'][$e].", 'A', 10, ".$_SESSION['lmsquote']['UserName_ID'].")";
              $LMSDB->sql_query($sqlSG1);
              $vSqlStringH1 = "call LOL_Add_Policy_History_Log(".$vPolicyArray['policy_id'][$e].", ".$_POST['PolicySection_ID'].", ".$vPolicyArray['item_id'][$e].", 2, ".$_SESSION['lmsquote']['UserName_ID'].", 'Special Group Added - WE(M)');";
                  $LMSDB->sql_query($vSqlStringH1);
                  //Endorsement ADD
                  saveNewEndorsement($vPolicyArray['policy_id'][$e], $_POST['PolicySection_ID'], $vPolicyArray['item_id'][$e], date('Y-m-d H:i:s.000'), 1381);
                }
              }
              $LMSDB->sql_freeresult($vEndosExist);
          }
          else if($_POST['car_excess'] == 15 && (isset($_SESSION['lmsquote']['Policy_ID']) && $_SESSION['lmsquote']['Policy_ID'] > 0)){
              $vSqlSelectExist = "SELECT IFNULL(count(Endorsement_ID), 0, count(Endorsement_ID)) AS numExist FROM PolicyEndorsement WHERE Policy_ID = ".$_SESSION['lmsquote']['Policy_ID']." AND ";
              $vSqlSelectExist .= "PolicySection_ID = ".$_POST['PolicySection_ID']." AND Endorsement_ID = 2491 AND DeletedYN = 'N'";
              $vEndosExist = $LMSDB->sql_fetchrow($LMSDB->sql_query($vSqlSelectExist));

              for($i = 0; $i < count($vPolicyArray['policy_id']); $i++){
            $sqlSG = "CALL LOL_Add_Policy_SpecialGroup(".$vPolicyArray['policy_id'][$i].", 'R', 10, ".$_SESSION['lmsquote']['UserName_ID'].")";
            $LMSDB->sql_query($sqlSG);
            $vSqlStringH2 = "call LOL_Add_Policy_History_Log(".$vPolicyArray['policy_id'][$i].", ".$_POST['PolicySection_ID'].", ".$vPolicyArray['item_id'][$i].", 3, ".$_SESSION['lmsquote']['UserName_ID'].", 'Special Group Removed - WE(M)');";
                $LMSDB->sql_query($vSqlStringH2);
                //Endorsement Remove
                deleteEndorsement($vPolicyArray['policy_id'][$i], $_POST['PolicySection_ID'], 1381, $vPolicyArray['item_id'][$i]);
              }

              if($vEndosExist['numExist'] == 0){
                for($y = 0; $y < count($vPolicyArray['policy_id']); $y++){
              $sqlSG2 = "CALL LOL_Add_Policy_SpecialGroup(".$vPolicyArray['policy_id'][$y].", 'A', 15, ".$_SESSION['lmsquote']['UserName_ID'].")";
              $LMSDB->sql_query($sqlSG2);
              $vSqlStringH = "call LOL_Add_Policy_History_Log(".$vPolicyArray['policy_id'][$y].", ".$_POST['PolicySection_ID'].", ".$vPolicyArray['item_id'][$y].", 2, ".$_SESSION['lmsquote']['UserName_ID'].", 'Special Group Added - AX');";
                  $LMSDB->sql_query($vSqlStringH);
                  //Endorsement ADD
                  saveNewEndorsement($vPolicyArray['policy_id'][$y], $_POST['PolicySection_ID'], $vPolicyArray['item_id'][$y], date('Y-m-d H:i:s.000'), 2491);
                }
              }
              $LMSDB->sql_freeresult($vEndosExist);
          }
          }
          else if($_POST['PolicySection_ID'] == 2 && $_POST['car_excess'] == 0){
          if(isset($_SESSION['lmsquote']['Policy_ID']) && $_SESSION['lmsquote']['Policy_ID'] > 0){
            for($z = 0; $z < count($vPolicyArray['policy_id']); $z++){
            $sqlSG = "CALL LOL_Add_Policy_SpecialGroup(".$vPolicyArray['policy_id'][$z].", 'R', 10, ".$_SESSION['lmsquote']['UserName_ID'].")";
            $LMSDB->sql_query($sqlSG);
            $vSqlStringH2 = "call LOL_Add_Policy_History_Log(".$vPolicyArray['policy_id'][$z].", ".$_POST['PolicySection_ID'].", ".$vPolicyArray['item_id'][$z].", 3, ".$_SESSION['lmsquote']['UserName_ID'].", 'Special Group Removed - WE(M)');";
                $LMSDB->sql_query($vSqlStringH2);
                //Endorsement Remove
                deleteEndorsement($vPolicyArray['policy_id'][$z], $_POST['PolicySection_ID'], 1381, $vPolicyArray['item_id'][$z]);

            $sqlSG2 = "CALL LOL_Add_Policy_SpecialGroup(".$vPolicyArray['policy_id'][$z].", 'R', 15, ".$_SESSION['lmsquote']['UserName_ID'].")";
            $LMSDB->sql_query($sqlSG2);
            $vSqlStringH = "call LOL_Add_Policy_History_Log(".$vPolicyArray['policy_id'][$z].", ".$_POST['PolicySection_ID'].", ".$vPolicyArray['item_id'][$z].", 3, ".$_SESSION['lmsquote']['UserName_ID'].", 'Special Group Removed - AX');";
                $LMSDB->sql_query($vSqlStringH);
                //Endorsement Remove
                deleteEndorsement($vPolicyArray['policy_id'][$z], $_POST['PolicySection_ID'], 2491, $vPolicyArray['item_id'][$z]);
            }
          }
          }
          //Home contents on Plot / Farm

      //Jewellery value > 50 000

          //Endorsements END

      //Motorcycle - not regular driver


