SELECT 

L_VehicleMake.VehicleMake1, 
L_VehicleModel.ModelDescription1,
L_Vehicle.* 


FROM "DBA"."L_Vehicle" 
LEFT OUTER JOIN L_VehicleMake ON L_VehicleMake.PID = L_Vehicle.VehicleMake_ID
LEFT OUTER JOIN L_VehicleModel ON L_VehicleModel.PID = L_Vehicle.VehicleModel_ID
