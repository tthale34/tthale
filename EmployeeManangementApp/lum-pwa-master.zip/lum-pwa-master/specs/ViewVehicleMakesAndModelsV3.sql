SELECT 
L_VehicleMake.VehicleMake1, 
L_VehicleModel.ModelDescription1,
MAX(L_Vehicle.PID) AS VehiclePID,
MAX(L_VehicleMake.PID) AS VehicleMakePID, 
MAX(L_VehicleModel.PID) AS L_VehicleModelPID


FROM "DBA"."L_Vehicle" 
LEFT OUTER JOIN L_VehicleMake ON L_VehicleMake.PID = L_Vehicle.VehicleMake_ID
LEFT OUTER JOIN L_VehicleModel ON L_VehicleModel.PID = L_Vehicle.VehicleModel_ID
WHERE L_VehicleMake.PID = 20162
or L_VehicleMake.PID = 20430

GROUP BY 
L_VehicleModel.ModelDescription1,
L_VehicleMake.VehicleMake1

 ORDER BY L_VehicleModel.ModelDescription1,
L_VehicleMake.VehicleMake1
