<?php

include("lol.inc.all.php");
//ini_set('display_errors','On');
//ini_set('error_reporting', E_ALL);


if ( $_SERVER['REQUEST_METHOD'] == 'POST' ) {
  $data = json_decode(file_get_contents("php://input")); //for post request
  $isPost = true;
} else {
  $data = json_decode(json_encode($_GET));
  $isPost = false;
}

$jwt = getJWTData($data);

function writeLog($logval =""){
    $myfile = fopen("/tmp/addvehicle1.txt", "a");
    $txt = "WRITE LOG
";
    $txt .= "FUNCTION:".$_GET['function_name']."
";
    // $txt .= print_r($_REQUEST,true);
    $txt .= " 
".$logval;

    fwrite($myfile, $txt);
    fclose($myfile);
}


writeLog(print_r($_REQUEST,true));
// if ($polID  = $jwt["Policy_ID"]) {
// file_put_contents("/tmp/call.assist." . $polID . ".log",print_r($jwt,true));  
//     $lms = new lol("LMS",$jwt);
//     $pol = new lmsPolicy($lms,$polID);
//       //$res = $pol->getClaims();
//       $res=null;
//       echo json_encode(lol::result(true,"You called assist",$res,null));

//     if ($isPost) {
//       /*
//       if (isset($data->accID)) {
//           echo json_encode(lol::result(true,"Your Premium was resubmitted.",null,null));
//       } else {
//           echo json_encode(lol::result(false,"No Unpaid selected",null,null));
//       }
//       */
//       $nres = $pol->logAssistCall();
//     } else {
//       $nres = $pol->logAssistCall();
      
//     }



// } else {
//     echo json_encode(lol::result(false,"You need to be logged in.",null,null));
    
// }

?>
