<?php
ini_set('display_errors','On');
ini_set('error_reporting', E_ALL);

include("lol.inc.all.php");

//include("../classes/claimVehicleTheft.php");
//include("../classes/claimVehicleWindscreen.php");
//include("../classes/claimBuildingGeyser.php");
//include("../classes/documentGenerator.php");

$lms = new lol("LMS");
$lms->login("elich@lum.co.za","test");

$claim = new claimAllRisk($lms,312206);

echo $claim->getClaimSQL();
echo var_dump($claim->getClaimDetail());

//$pol = new lmsPolicy($lms,96101);
//$pol->makeNote("test note");
//var_dump($pol->itemRemove("1028048","2020-11-07"));
                 
//var_dump($lms->getUserPolicyProfile(0));

//var_dump(lolHelperFunctions::sendSMS("0834210289","hello"));
//var_dump(lolHelperFunctions::sendEmail("adolfhartsenberg@gmail.com","adolf","clientapp@lum.co.za","App", "adolf@csbt.co.za","adolf2","this subject","this body"));

function CallAPI($method, $url, $data = false)
{
    $curl = curl_init();

    switch ($method)
    {
        case "POST":
            curl_setopt($curl, CURLOPT_POST, 1);

            if ($data)
                curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
            break;
        case "PUT":
            curl_setopt($curl, CURLOPT_PUT, 1);
            break;
        default:
            if ($data)
                $url = sprintf("%s?%s", $url, http_build_query($data));
    }

    // Optional Authentication:
    curl_setopt($curl, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
    curl_setopt($curl, CURLOPT_USERPWD, "username:password");

    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);

    $result = curl_exec($curl);

    curl_close($curl);

    return $result;
};

$docdata = array(
    "sysPolicyID"=>"96101",
    "CLIENTEMAIL"=>"adolfhartsenberg@gmail.com",
    "CLIENTNAME"=>"Adolf",
    "DocDesc"=>"My Doc",
    "DocKeyID"=>"96101",
    "DocID"=>"2",
    "sysUserNameID"=>"0",
    
);

$cheddata = array(
    "POLICYID"=>"96101",
    "CLIENTEMAIL"=>"adolfhartsenberg@gmail.com",
    "CLIENTNAME"=>"Adolf",
    "sysUserNameID"=>"0",
    
);

//$lms = new lol("LMS");
//var_dump($lms->login("elich@lum.co.za","test"));
//$var = json_encode($lms->getUserPolicyProfile(16726));
//print_r(json_decode($var));

/*
foreach($var["PolicyItems"] as $k=>$v){
    foreach($v as $x) {
        print_r($x);
    }
}
*/
//$pol = new lmsPolicy($lms,158107);
/*
$doc = new documentGenerator($pol);
            $taxData = array(
                "Policy_ID"=>$p["Policy_ID"]
                ,"from_date"=>$_from_date
                ,"to_date"=>$_to_date
                ,"userID"=>$this->lolPolicy->getLol()->getuserId()
                ,"CLIENTEMAIL"=>$p["ClientEmail"]
                ,"CLIENTNAME"=>$p["ClientCommonName"]
            );
  */          

//var_dump($doc->appMakeRtfDocument(2,158107));
//var_dump($doc->appMakeSchedule());
//var_dump($lms->getGrougedPolicyItems(96101, "N", null, null) );


//echo CallAPI("GET", "http://www.lum.co.za/mypolicy.lum.co.za/mobi.mypolicy.gen.document.php",$docdata);
//echo CallAPI("GET", "http://www.lum.co.za/mypolicy.lum.co.za/mobi.mypolicy.send.schedule.php",$cheddata);

//$claim = new claimBuildingGeyser($lms,314672);

//echo $claim->getClaimSQL();
//echo var_dump($claim->getClaimDetail());



//echo $lms->getAllLookUps();
$dbmap = array(
    "ddSelectVehicle" => "policysection_id",
    "incidentype" => "incedenttype_id",
    "relation" => "relationship_id",
    "description" => "lossdescription",
);

$dbmapa = array(
    "fields" => array(
        "PID" => array("field" => "pid","tablePrefix" => "pc"),
        ),
    "baseTable" => array("table"=>"policyclaim","prefix"=>"pc", "keyField"=>"PID", "filterField"=>"policy_id"),
    "joins" => array(
                     "p"=>array("table"=>"policy","keyField"=>"pid","masterPrefix"=>"pc","masterField"=>"policy_id"),
                     "c"=>array("table"=>"client","keyField"=>"pid","masterPrefix"=>"p","masterField"=>"client_id"),
                    )

);

$dbmapj = '{
    "fields" : {
        "PID" : {"field" : "pid","tablePrefix" : "ps"},
        "item" : {"field" : "Itemdescription","tablePrefix" : "ps"},
        "covertype" : {"field" : "covertype_id","tablePrefix" : "ps"},
        "relation" : {"field" : "VehicleRelationship_ID","tablePrefix" : "ps"},
        "itemtype" : {"field" : "itemtype_id","tablePrefix" : "ps"},
        "clientname" : {"field" : "clientcommonname","tablePrefix" : "c"},
        "policycode" : {"field" : "policycode","tablePrefix" : "p"},
        },
    "baseTable" : {"table":"policysection","prefix":"ps", "keyField":"PID"},
    "joins" : {
                     "policy":{"prefix":"p","keyField":"pid","masterPrefix":"ps","masterField":"policy_id"},
                     "client":{"prefix":"c","keyField":"pid","masterPrefix":"p","masterField":"client_id"},
                    }

}';

//$dbmap = json_decode($dbmapj, true);

//var_dump($dbmap);
$dbmap = $dbmapa;
$data = array(
    "PID" => "123456789",
    "policy_id" => "96101",
    "ddSelectVehicle" => "1234",
    "incidentype" => "2",
    "relation" => "1",
    "description" => "he bumped me",
    "clientname" => "Adolf",
    "policycodex" => "HC096101",
              );
/*
echo $lms->getDB()->selectSqlFromMap($dbmap,$data);              
$res = $lms->getDB()->all($lms->getDB()->selectSqlFromMap($dbmap,158107));
var_dump($res);
*/

//echo $lms->getDB()->getNextPID('policyclaim',1);


$customDbMap = array(
    "fields" => array(
                    "TotalLossYN" => array("field" => "TotalLossYN","tablePrefix" => "pc","readOnly" => false),
                    "PossibleRecoveryYN" => array("field" => "PossibleRecoveryYN","tablePrefix" => "pc","readOnly" => false),
                    "SecurityDependantYN" => array("field" => "SecurityDependantYN","tablePrefix" => "pc","readOnly" => false),
                    "GenTheftReportFormYN" => array("field" => "GenTheftReportFormYN","tablePrefix" => "pc","readOnly" => false),
                    "PossibleCounterClaim" => array("field" => "PossibleCounterClaim","tablePrefix" => "pc","readOnly" => false),
                    "WhereYouDrivingYN" => array("field" => "WhereYouDrivingYN","tablePrefix" => "pc","readOnly" => false),
                    "DriverPocessionValidLicence" => array("field" => "DriverPocessionValidLicence","tablePrefix" => "pc","readOnly" => false),
                    "AOLReceivedYN" => array("field" => "AOLReceivedYN","tablePrefix" => "pc","readOnly" => false),
                    "AssessorsReportReceivedYN" => array("field" => "AssessorsReportReceivedYN","tablePrefix" => "pc","readOnly" => false),
                    "RecoverySuccessAction_ID" => array("field" => "RecoverySuccessAction_ID","tablePrefix" => "pc","readOnly" => false),
                    "CarHireStartDate" => array("field" => "CarHireStartDate","tablePrefix" => "pc","readOnly" => false),
                    "CarRentalCompany_ID" => array("field" => "CarRentalCompany_ID","tablePrefix" => "pc","readOnly" => false),
                    "PolicyHolderJobTitle_ID" => array("field" => "PolicyHolderJobTitle_ID","tablePrefix" => "pc","readOnly" => false),
                    "PolicyHolderIDNumber" => array("field" => "PolicyHolderIDNumber","tablePrefix" => "pc","readOnly" => false),
                    "PolicyHolderHomePhone" => array("field" => "PolicyHolderHomePhone","tablePrefix" => "pc","readOnly" => false),
                    "PolicyHolderWorkPhone" => array("field" => "PolicyHolderWorkPhone","tablePrefix" => "pc","readOnly" => false),
                    "PolicyHolderCellPhone" => array("field" => "PolicyHolderCellPhone","tablePrefix" => "pc","readOnly" => false),
                    "EmailAddress" => array("field" => "EmailAddress","tablePrefix" => "pc","readOnly" => false),
                    "ItemDescription" => array("field" => "ItemDescription","tablePrefix" => "pc","readOnly" => false),
                    "CoverType_ID" => array("field" => "CoverType_ID","tablePrefix" => "pc","readOnly" => false),
                    "MotorVehicle_ID" => array("field" => "MotorVehicle_ID","tablePrefix" => "pc","readOnly" => false),
                    "YearModel" => array("field" => "YearModel","tablePrefix" => "pc","readOnly" => false),
                    "RegistrationNumber" => array("field" => "RegistrationNumber","tablePrefix" => "pc","readOnly" => false),
                    "R_InsuredAmount" => array("field" => "R_InsuredAmount","tablePrefix" => "pc","readOnly" => false),
                    "Milage" => array("field" => "Milage","tablePrefix" => "pc","readOnly" => false),
                    "ChassisNumber" => array("field" => "ChassisNumber","tablePrefix" => "pc","readOnly" => false),
                    "EngineNumber" => array("field" => "EngineNumber","tablePrefix" => "pc","readOnly" => false),
                    "InsuredUnderAnotherPolicyYN" => array("field" => "InsuredUnderAnotherPolicyYN","tablePrefix" => "pc","readOnly" => false),
                    "OtherPolicyInsurer_ID" => array("field" => "OtherPolicyInsurer_ID","tablePrefix" => "pc","readOnly" => false),
                    "OtherPolicyPolicyNumber" => array("field" => "OtherPolicyPolicyNumber","tablePrefix" => "pc","readOnly" => false),
                    "OtherPolicyAddress1" => array("field" => "OtherPolicyAddress1","tablePrefix" => "pc","readOnly" => false),
                    "HirePurchaseYN" => array("field" => "HirePurchaseYN","tablePrefix" => "pc","readOnly" => false),
                    "R_HirePurchaseOutstandAmount" => array("field" => "R_HirePurchaseOutstandAmount","tablePrefix" => "pc","readOnly" => false),
                    "HirePurchase_ID" => array("field" => "HirePurchase_ID","tablePrefix" => "pc","readOnly" => false),
                    "HirePurchaseRefNumber" => array("field" => "HirePurchaseRefNumber","tablePrefix" => "pc","readOnly" => false),
                    "RegisteredOwnerYN" => array("field" => "RegisteredOwnerYN","tablePrefix" => "pc","readOnly" => false),
                    "RegisteredOwnerName" => array("field" => "RegisteredOwnerName","tablePrefix" => "pc","readOnly" => false),
                    "RegisteredOwnerAddress1" => array("field" => "RegisteredOwnerAddress1","tablePrefix" => "pc","readOnly" => false),
                    "Interest" => array("field" => "Interest","tablePrefix" => "pc","readOnly" => false),
                    "TheftDate" => array("field" => "TheftDate","tablePrefix" => "pc","readOnly" => false),
                    "AccidentTime" => array("field" => "AccidentTime","tablePrefix" => "pc","readOnly" => false),
                    "AccidentPlace" => array("field" => "AccidentPlace","tablePrefix" => "pc","readOnly" => false),
                    "AccidentReportedYN" => array("field" => "AccidentReportedYN","tablePrefix" => "pc","readOnly" => false),
                    "AccidentReportedSAPDYN" => array("field" => "AccidentReportedSAPDYN","tablePrefix" => "pc","readOnly" => false),
                    "SAPDReferenceNumber" => array("field" => "SAPDReferenceNumber","tablePrefix" => "pc","readOnly" => false),
                    "SAPDReportedByWhom" => array("field" => "SAPDReportedByWhom","tablePrefix" => "pc","readOnly" => false),
                    "SAPDPoliceStation" => array("field" => "SAPDPoliceStation","tablePrefix" => "pc","readOnly" => false),
                    "AccidentDescription" => array("field" => "AccidentDescription","tablePrefix" => "pc","readOnly" => false),
                    "PurchaseDate" => array("field" => "PurchaseDate","tablePrefix" => "pc","readOnly" => false),
                    "R_PurchaseAmount" => array("field" => "R_PurchaseAmount","tablePrefix" => "pc","readOnly" => false),
                    "AntiTTheftDeviceYN" => array("field" => "AntiTTheftDeviceYN","tablePrefix" => "pc","readOnly" => false),
                    "AntiTTheftDeviceMake" => array("field" => "AntiTTheftDeviceMake","tablePrefix" => "pc","readOnly" => false),
                    "AntiTTheftDeviceIntalledBy" => array("field" => "AntiTTheftDeviceIntalledBy","tablePrefix" => "pc","readOnly" => false),
                    "InstallationDate" => array("field" => "InstallationDate","tablePrefix" => "pc","readOnly" => false),
                    "WindowEtchedYN" => array("field" => "WindowEtchedYN","tablePrefix" => "pc","readOnly" => false),
                    "WindowMarking" => array("field" => "WindowMarking","tablePrefix" => "pc","readOnly" => false),
                    "MarkingDesc" => array("field" => "MarkingDesc","tablePrefix" => "pc","readOnly" => false),
                    "NonStandardDesc" => array("field" => "NonStandardDesc","tablePrefix" => "pc","readOnly" => false),
                    "VehicleChangeModification" => array("field" => "VehicleChangeModification","tablePrefix" => "pc","readOnly" => false),
                    "VehicleSmallDefectYN" => array("field" => "VehicleSmallDefectYN","tablePrefix" => "pc","readOnly" => false),
                    "PersonalMarksYN" => array("field" => "PersonalMarksYN","tablePrefix" => "pc","readOnly" => false),
                    "PersonalMarks" => array("field" => "PersonalMarks","tablePrefix" => "pc","readOnly" => false),
                    "VehicleRadioYN" => array("field" => "VehicleRadioYN","tablePrefix" => "pc","readOnly" => false),
                    "RadioMake" => array("field" => "RadioMake","tablePrefix" => "pc","readOnly" => false),
                    "VehicleLockedYN" => array("field" => "VehicleLockedYN","tablePrefix" => "pc","readOnly" => false),
                    "ResponsiblePerson" => array("field" => "ResponsiblePerson","tablePrefix" => "pc","readOnly" => false),
                    "WhoPossessionKeys" => array("field" => "WhoPossessionKeys","tablePrefix" => "pc","readOnly" => false),
                    "VehicleInteriorColour_ID" => array("field" => "VehicleInteriorColour_ID","tablePrefix" => "pc","readOnly" => false),
                    "VehicleExteriorColour_ID" => array("field" => "VehicleExteriorColour_ID","tablePrefix" => "pc","readOnly" => false),
                    "RepudiationYN" => array("field" => "RepudiationYN","tablePrefix" => "pc","readOnly" => false),
                    "RepudiationReason" => array("field" => "RepudiationReason","tablePrefix" => "pc","readOnly" => false),
                    "CatastropheYN" => array("field" => "CatastropheYN","tablePrefix" => "pc","readOnly" => false),

                    
"L_RecoverySuccessAction_RecoverySuccessAction_ID_RecoverySuccessAction" => array("field" => "RecoverySuccessAction2","tablePrefix" => "L_RecoverySuccessAction_RecoverySuccessAction_ID","readOnly" => true),
"L_vCarRentalCompany_CarRentalCompany_ID_CarRentalCompany" => array("field" => "CarRentalCompany","tablePrefix" => "L_vCarRentalCompany_CarRentalCompany_ID","readOnly" => true),
"L_IndustryJobTitle_PolicyHolderJobTitle_ID_IndustryJobTitle" => array("field" => "IndustryJobTitle2","tablePrefix" => "L_IndustryJobTitle_PolicyHolderJobTitle_ID","readOnly" => true),
"L_VehicleCoverType_CoverType_ID_CoverType" => array("field" => "CoverType2","tablePrefix" => "L_VehicleCoverType_CoverType_ID","readOnly" => true),
"L_Insurer_OtherPolicyInsurer_ID_Insurer" => array("field" => "Insurer2","tablePrefix" => "L_Insurer_OtherPolicyInsurer_ID","readOnly" => true),
"L_HirePurchaseCompany_HirePurchase_ID_Name" => array("field" => "Name2","tablePrefix" => "L_HirePurchaseCompany_HirePurchase_ID","readOnly" => true),
"L_Colour_VehicleInteriorColour_ID_Colour" => array("field" => "Colour2","tablePrefix" => "L_Colour_VehicleInteriorColour_ID","readOnly" => true),
"L_Colour_VehicleExteriorColour_ID_Colour" => array("field" => "Colour2","tablePrefix" => "L_Colour_VehicleExteriorColour_ID","readOnly" => true),

                    
                    ),
    "joins" => array(
"L_RecoverySuccessAction_RecoverySuccessAction_ID"=>array("table"=>"L_RecoverySuccessAction","keyField"=>"pid","masterPrefix"=>"pc","masterField"=>"RecoverySuccessAction_ID"),
"L_vCarRentalCompany_CarRentalCompany_ID"=>array("table"=>"L_vCarRentalCompany","keyField"=>"pid","masterPrefix"=>"pc","masterField"=>"CarRentalCompany_ID"),
"L_IndustryJobTitle_PolicyHolderJobTitle_ID"=>array("table"=>"L_IndustryJobTitle","keyField"=>"pid","masterPrefix"=>"pc","masterField"=>"PolicyHolderJobTitle_ID"),
"L_VehicleCoverType_CoverType_ID"=>array("table"=>"L_VehicleCoverType","keyField"=>"pid","masterPrefix"=>"pc","masterField"=>"CoverType_ID"),
"L_Insurer_OtherPolicyInsurer_ID"=>array("table"=>"L_Insurer","keyField"=>"pid","masterPrefix"=>"pc","masterField"=>"OtherPolicyInsurer_ID"),
"L_HirePurchaseCompany_HirePurchase_ID"=>array("table"=>"L_HirePurchaseCompany","keyField"=>"pid","masterPrefix"=>"pc","masterField"=>"HirePurchase_ID"),
"L_Colour_VehicleInteriorColour_ID"=>array("table"=>"L_Colour","keyField"=>"pid","masterPrefix"=>"pc","masterField"=>"VehicleInteriorColour_ID"),
"L_Colour_VehicleExteriorColour_ID"=>array("table"=>"L_Colour","keyField"=>"pid","masterPrefix"=>"pc","masterField"=>"VehicleExteriorColour_ID"),                   )

);
/*
$dbmap = array_merge_recursive($dbmapa,$customDbMap);

//var_dump($dbmap);
echo $lms->getDB()->selectSqlFromMap($dbmap,$data);              
$res = $lms->getDB()->all($lms->getDB()->selectSqlFromMap($dbmap,158107));
var_dump($res);
*/
/*
$sqlupdate = "";
$cnt=1;
foreach($dbmap["fields"] as $k => $v) {
    if ($v["tablePrefix"]==$dbmap["baseTable"]["prefix"]) {
        if (isset($data[$k])) {
            if (strtolower($k) != strtolower($dbmap["baseTable"]["keyField"])) {
                
                if (($cnt++)>1) {$sqlupdate .= ",";};
                $sqlupdate .= $v["field"] . "='" . $data[$k] ."'";
                
            }
        }
    }
    
};
if (isset($data[$dbmap["baseTable"]["keyField"]]) ) {
    $sqlupdate = "update " . $dbmap["baseTable"]["table"] . " set " . $sqlupdate . " where " . $dbmap["baseTable"]["keyField"] . "=" . $data[$dbmap["baseTable"]["keyField"]] . ";commit;";
};
echo $sqlupdate;

echo "<br/><br/>";

$sqlget = "";
$cnt=1;
foreach($dbmap["fields"] as $k => $v) {
    
    if (($cnt++)>1) {$sqlget .= ",";};
    $sqlget .=  $v["tablePrefix"] . "." . $v["field"] . " as [" . $k ."]";
    
};
$sqlget = "select " . $sqlget ." from " . $dbmap["baseTable"]["table"] . " as " . $dbmap["baseTable"]["prefix"];

foreach($dbmap["joins"] as $t => $v) {
    $sqlget .= " left outer join " . $t . " as " . $v["prefix"] . " on " . $v["prefix"] . ".". $v["keyField"] . "=" . $v["masterPrefix"] . ".". $v["masterField"] ;
    
}

echo $sqlget;
*/
//var_dump($lms->login("momuzah@gmail.com","test"));
//echo "<br/><br/>";
//var_dump($lms->register("momuzah@gmail.com","test"));
//echo "<br/><br/>";
//var_dump($lms->login("momuzah@gmail.com","test"));
//echo "<br/><br/>";
/*
echo "<br/><br/>";
//var_dump($lms->register("0780336950","mo1"));
echo "<br/><br/>";
var_dump($lms->register("elich@lum.co.za","lich1"));
*/
//$pol = new lmsPolicy($lms,96101);
//echo "<br/><br/>";
//echo $pol->getPolicyCode();
//echo "<br/><br/>";
//var_dump($pol->getPolicyProfile());


/*
echo "<br/><br/>";
var_dump($pol->getClaims(1316608));
*/
?>