<?php
ini_set('display_errors','On');
ini_set('error_reporting', E_ALL);

include("lol.inc.all.php");

    include_once("../classes/class.lmsftp.php");


$lms = new lol("LMS");
$claim = new claimAllRisk($lms,318411);
//$claim->automateClaim();
$d = $claim->getClaimDetail();
print_r($d);
$v =  $claim->getDbValidation(true);
print_r($v);



//ftpfiletoserver("/lumasfiles/".$targetFolder, time(), dirname($uploaded_file) . "/" . $file->name);



//$folderdate = "2021/01/19";
/*
$folderdate = date("Y/m/d");
echo $folderdate;
$localfilename = "/tmp/appQuote__20210119_010801.png";
$ftp = new LMSFTP("192.168.169.101","lmsuser","lms", "/lumasfiles/");
$remote_folder = $ftp->get_root($localfilename);
$ftp->ftpfiletoserver($remote_folder, $folderdate, $localfilename)
*/



/*
$lms = new lol("LMS");

echo $lms->getAllLookUps();
*/
//var_dump($lms->login("momuzah@gmail.com","test"));
//echo "<br/><br/>";
//var_dump($lms->register("momuzah@gmail.com","test"));
//echo "<br/><br/>";
//var_dump($lms->login("momuzah@gmail.com","test"));
//echo "<br/><br/>";
/*
echo "<br/><br/>";
//var_dump($lms->register("0780336950","mo1"));
echo "<br/><br/>";
var_dump($lms->register("elich@lum.co.za","lich1"));
*/
//$pol = new lmsPolicy($lms,96101);
//echo "<br/><br/>";
//echo $pol->getPolicyCode();
//echo "<br/><br/>";
//var_dump($pol->getPolicyProfile());


/*
echo "<br/><br/>";
var_dump($pol->getClaims(1316608));
*/
?>