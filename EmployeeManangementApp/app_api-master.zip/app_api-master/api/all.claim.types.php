<?php
//ini_set('display_errors','On');
//ini_set('error_reporting', E_ALL);

include("lol.inc.all.php");


$lms = new lol("LMS");

//echo $lms->getAllLookUps();

echo json_encode($lms->getDB()->all("
select ct.pid as ClaimTypeID,
ct.claimtype2 as claimType,
ps.policysection2
from l_claimtype as ct
join l_policysection as ps on ps.pid=ct.policysectiontype_id
"));


//var_dump($lms->login("momuzah@gmail.com","test"));
//echo "<br/><br/>";
//var_dump($lms->register("momuzah@gmail.com","test"));
//echo "<br/><br/>";
//var_dump($lms->login("momuzah@gmail.com","test"));
//echo "<br/><br/>";
/*
echo "<br/><br/>";
//var_dump($lms->register("0780336950","mo1"));
echo "<br/><br/>";
var_dump($lms->register("elich@lum.co.za","lich1"));
*/
//$pol = new lmsPolicy($lms,96101);
//echo "<br/><br/>";
//echo $pol->getPolicyCode();
//echo "<br/><br/>";
//var_dump($pol->getPolicyProfile());


/*
echo "<br/><br/>";
var_dump($pol->getClaims(1316608));
*/
?>