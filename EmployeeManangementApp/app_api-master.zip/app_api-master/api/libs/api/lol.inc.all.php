<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Max-Age: 1000');
if(array_key_exists('HTTP_ACCESS_CONTROL_REQUEST_HEADERS', $_SERVER)) {
    header('Access-Control-Allow-Headers: '
           . $_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']);
} else {
    header('Access-Control-Allow-Headers: *');
}
header('Content-type: application/json');
/*
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
*/

// ini_set('display_errors','On');
//ini_set('error_reporting', E_ALL);
/*
function fileTimeStamp($filename = null){
	$t = microtime(true);
	$micro = sprintf("%06d",($t-floor($t))*1000000);
	$d = new DateTime(date('Y-m-d H:i:s.'.$micro,$t));
	$res = $d->format("Ymd_His_u");
	if ($filename) {
		$filename = str_ireplace("[stamp]",$res,$filename);
	} else {
		$filename = $res;
	}
	return $filename;
}
*/

include 'pwa.debug.php';

/*
if ( $_SERVER['REQUEST_METHOD'] == 'POST' ) {
  $_xdat = json_decode(file_get_contents("php://input")); //for post request
} else {
  $_xdat = json_decode(json_encode($_GET));
}
$___myuria = explode("?",basename($_SERVER["REQUEST_URI"]) ,2);
$___myuri = $___myuria[0];

$___mylog = "pwa_[stamp]." . $___myuri . ".log";

	$___t = microtime(true);
	$___micro = sprintf("%06d",($___t-floor($___t))*1000000);
	$___d = new DateTime(date('Y-m-d H:i:s.'.$___micro,$___t));
	$___res = $___d->format("Ymd_His_u");
	if ($___mylog) {
		$___mylog = str_ireplace("[stamp]",$___res,$___mylog);
	} else {
		$___mylog = $___res;
	}



$___mylog = "/tmp/" . $___mylog;
file_put_contents($___mylog,print_r($_xdat, true));
*/
 // required to decode jwt
include_once '../configs/conf.php';
include_once '../libs/vendor/firebase/php-jwt/src/BeforeValidException.php';
include_once '../libs/vendor/firebase/php-jwt/src/ExpiredException.php';
include_once '../libs/vendor/firebase/php-jwt/src/SignatureInvalidException.php';
include_once '../libs/vendor/firebase/php-jwt/src/JWT.php';
include_once 'jwt.helper.php';
include_once("../classes/lolDB.php");
include_once("../classes/lol.php");
include_once("../classes/lmsPolicy.php");
include_once("../classes/claimBase.php");
include_once("../classes/claimBuildingGeyser.php");
include_once("../classes/claimVehicleTheft.php");
include_once("../classes/claimVehicleAccident.php");
include_once("../classes/claimVehicleWindscreen.php");
include_once("../classes/documentGenerator.php");
include_once("../classes/lolHelperFunctions.php");
include_once("../classes/claimAllRisk.php");
include_once("../classes/claimContents.php");
include_once("../classes/claimContentsFreezer.php");





?>