<?php
ini_set('display_errors','On');
ini_set('error_reporting', E_ALL);

include("lol.inc.all.php");


$lms = new lol("LMS");

echo $lms->getAllLookUps();

//var_dump($lms->login("momuzah@gmail.com","test"));
//echo "<br/><br/>";
//var_dump($lms->register("momuzah@gmail.com","test"));
//echo "<br/><br/>";
//var_dump($lms->login("momuzah@gmail.com","test"));
//echo "<br/><br/>";
/*
echo "<br/><br/>";
//var_dump($lms->register("0780336950","mo1"));
echo "<br/><br/>";
var_dump($lms->register("elich@lum.co.za","lich1"));
*/
//$pol = new lmsPolicy($lms,96101);
//echo "<br/><br/>";
//echo $pol->getPolicyCode();
//echo "<br/><br/>";
//var_dump($pol->getPolicyProfile());


/*
echo "<br/><br/>";
var_dump($pol->getClaims(1316608));
*/
?>