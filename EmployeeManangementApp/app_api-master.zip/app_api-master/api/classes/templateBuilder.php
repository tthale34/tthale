<?php

class templateBuilder{
        private $lol;
        private $template_folder = "../templates/";
        private $isFileTemplate;
        private $sql;
        private $template;
        private $templateFileName;
        private $dataKey;
        

        public function __construct($_lol, $isFileTemplate, $dataKey, $template, $sql = null) {
                $this->lol = $_lol;
                $this->isFileTemplate = $isFileTemplate;
                if (isset($sql)) {
                        $this->sql = $sql;
                }
                
                $this->dataKey = $dataKey;
                if ($isFileTemplate) {
                        if (file_exists($this->template_folder . $template)) {
                                $this->template = file_get_contents($this->template_folder . $template);
                                $finfo = pathinfo($template); 
                                $fext = $finfo['extension'];
                                $fdir = $finfo['dirname'];
                                $fsql = $this->template_folder . $fdir . "/" . basename($this->template_folder . $template,$fext) . "sql";
                                
                                if (file_exists($fsql)) {
                                        $this->sql = file_get_contents($fsql);
                                }
                        } else {
                                $$this->template = "";
                        }
                } else {
                        $this->template = $template;
                }
        }

        function prepTemplate() {
                $this->prepSql();
                $data = $sql=$this->lol->getDB()->data($this->sql);                
                $this->replace_doc_vars_with_array($data);
                return $this->template;
                
        }

        function getSql(){
                $this->prepSql();
                return $this->sql;
        }
        
        function prepSql(){
                
                $vars[] = "([USERID])";
                $vars[] = "([DATAKEY])";
                $values[] = $this->lol->getUserId();
                $values[] = $this->dataKey;
        
                $this->sql =  str_ireplace($vars, $values, $this->sql);                
 
                
        }
    function replace_doc_vars_with_array($data) {
        
        $fields = array_keys($data);
        print_r($fields);
        $values = array();
        $vars = array();
        foreach($fields as $var) {
                $vars[] = "([" . $var . "])";
                $values[] = $data[$var];
        }
        
        $this->template =  str_ireplace($vars, $values, $this->template);	
    }//replace_doc_vars_with_array

    static function populateTemplateFile($template, $data, $templateDir = "../templates/") {
        $templateFullPath = $templateDir . $template;
        //echo "<br/>$templateFullPath<br/>";
        if (file_exists($templateFullPath )) {
            $templateTxt = file_get_contents($templateFullPath);
            $fields = array_keys($data);
//            print_r($fields);
            $values = array();
            $vars = array();
            foreach($fields as $var) {
                    $vars[] = "([" . $var . "])";
                    $values[] = $data[$var];
            }
            
            $templateTxt =  str_ireplace($vars, $values, $templateTxt);
            return $templateTxt;
            
        }   else {
            return "";
        }
    }//replace_doc_vars_with_array
        
        
        












/*
        public function updateClaim($data){
                $filename = "/tmp/claim_update_" . $this->claimID . ".txt";
                $data["PID"] = $this->claimID;
                $sql=$this->lol->getDB()->updateSqlFromMap($this->dbmap,$data);
                $this->lol->getDB()->query($sql);
                file_put_contents($filename, $sql);
        }
        
*/        
}    
                        
                        
                        
                        
                        
                        
                        
                        


?>