<?php
include_once("lolDB.php");

class lol {
    protected $db;
    protected $SYS;
    protected $UserID = 0;
    protected $jwtToken;
    protected $userPolicyID;
    protected $userPolicyProfile;

    
    public function getJwtToken(){
        return $this->jwtToken;
    }
    
    public function getUserId(){
            return $this->UserID;            
    }

    public function lol2011ApiCall($method, $url, $data = false) {
        $curl = curl_init();
        switch ($method)
        {
            case "POST":
                curl_setopt($curl, CURLOPT_POST, 1);
    
                if ($data)
                    curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
                break;
            case "PUT":
                curl_setopt($curl, CURLOPT_PUT, 1);
                break;
            default:
                if ($data)
                    $url = sprintf("%s?%s", $url, http_build_query($data));
        }
        // Optional Authentication:
        curl_setopt($curl, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
        curl_setopt($curl, CURLOPT_USERPWD, "username:password");
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        $result = curl_exec($curl);
        curl_close($curl);
        return trim($result);
    }
    
    public function __construct($sys = null, $_jwtToken = null) {

        if ($_jwtToken) {
            $this->jwtToken = $_jwtToken;
            $this->UserID = $this->jwtToken["User_ID"];
            $this->userPolicyID = $this->jwtToken["Policy_ID"];
            
        }
        if ($sys) {
            $this->SYS = $sys;
            $this->db = new lolDB($this->SYS);    
        }
        
    }    

    public static function result($status, $message, $data = null, $objects = null) {
        $ret = array();
        $res = array();
        $ret["Status"] = $status;
        $ret["Message"] = $message;
        $res["Data"] = $data;
        $res["Objects"] = $objects;
        $ret["Result"] = $res;
        
        return $ret;
        
    }
    
    
    public function login($user, $password) {
        if ($u = $this->db->data("select PID, UserName, Password, LinkedPolicy_ID from users where username='$user'")) {
            //user found
            if ($u["Password"] == $password) {
                //user authenticated
                if ($u["LinkedPolicy_ID"]) {
                    //get policy info
                    $this->userPolicyID = $u["LinkedPolicy_ID"];
                    if ($p = $this->getUserPolicyProfile($u["PID"])) {
                        //policy found
                        $t =array();
                        $t["Policy_ID"] = $p["Policy_ID"];
                        $t["UserName"] = $p["UserName"];
                        $t["User_ID"] = $p["User_ID"];
                        $t["jwtTimeStamp"] = $p["jwtTimeStamp"];
                        $this->jwtToken = $t;
                        $this->UserID = $u["PID"];
                        $res = $this->result(true,"User Authenticated", $p, null);
                    } else {
                        // no policies found
                        $res = $this->result(false,"No policies found", null, null);
                    }
                    
                }
                return $res;
            } else {
                //user authentication failed
                $res = $this->result(false,"Authentication failed", null, null);
                return $res;
            }
            
        } else {
            //user not found
                $res = $this->result(false,"user not registerred", null, null);
                return $res;
            
        }
    }



    // Gert van Eeden 2021/0114 - add DateOfBirth to select statement
    public function getUserPolicyProfile($userid) {
        $sql = "
       select
            p.pid as Policy_ID
            ,p.policycode as PolicyCode
            ,p.client_id as Client_ID
            ,c.initials as Initials
            ,c.FirstNames as Names
            ,c.surname as Surname
            ,c.idnumber as IDNumber
            ,c.DateOfBirth as DateOfBirth
            ,c.clientcommonname as ClientCommonName
            ,c.HomeTelNumber as ClientHomeTel
            ,c.WorkTelNumber as ClientWorkTel
            ,c.cellnumber as ClientCell
            ,c.emailaddress as ClientEmail
            ,c.InsuredPersonOccupation as ClientOccupation
            ,b.brokername as BrokerName
            ,b.CellularNumber as BrokerCell
            ,b.EmailAddress as BrokerEmail
            ,b.FSPNO as BrokerFSP
            ,b.BrokerLogoFileName as BrokerLogoFN
            ,'https://www.lum.co.za/get_lms_logo.php?img=' || b.BrokerLogoFileName as BrokerLogoURL
            ,p.policyprefix_id as Prefix_ID
            ,ppf.insurerscheme_id as InsurerScheme_ID
            ,lis.insurer_ID as Insurer_ID
            ,ppf.policyprefix as PolicyPrefix
            ,i.insurer2 as Insurer
            ,lis.insurerscheme2 as InsurerScheme
            ,lps.status2 as PolicyStatus
            ,p.policystatus_id as PolicyStatus_ID
            ,get_SpecGrp(p.pid) AS SpecialGroups
            ,if(lis.Insurer_ID = 2 and lis.PolicyType_ID = 1 and ppf.pid <> 35 and p.PolicyScheme_Id <> 1078) then 
        		'<a href=https://www.lum.co.za/reports/policywordings/policywording_hollard_non_hv_2.pdf target=_blank>Policy Wording</a>'
         else if(lis.Insurer_ID = 2 and lis.PolicyType_ID = 1 and ppf.pid = 35 and p.PolicyScheme_Id <> 1078) then 
        		'<a href=https://www.lum.co.za/reports/policywordings/policywording_hollard_hv_2.pdf target=_blank>Policy Wording</a>'
         else if(lis.Insurer_ID = 2 and lis.PolicyType_ID = 1 and ppf.pid = 1143 and p.PolicyScheme_Id = 1078) then 
        		'<a href=https://www.lum.co.za/reports/policywordings/policywording_hollard_rh_2.pdf target=_blank>Policy Wording</a>'
         else if(lis.Insurer_ID = 1 and lis.PolicyType_ID = 1 and lis.pid <> 1038) then 
        		'<a href=https://www.lum.co.za/reports/policywordings/policywording_santam_2.pdf target=_blank>Policy Wording</a>'
         else if(lis.Insurer_ID = 1 and lis.PolicyType_ID = 1 and lis.pid = 1038) then 
        		'<a href=https://www.lum.co.za/reports/policywordings/policywording_santam_747_2.pdf target=_blank>Policy Wording</a>'
         else if(lis.Insurer_ID = 1037 and lis.PolicyType_ID = 1 and lis.pid <> 1080 and lis.pid <> 1085 and lis.pid <> 1084) then 
        		'<a href=https://www.lum.co.za/reports/policywordings/policywording_omi_op_2.pdf target=_blank>Policy Wording</a>'
         else if(lis.Insurer_ID = 1037 and lis.PolicyType_ID = 1 and lis.pid = 1080) then 
        		'<a href=https://www.lum.co.za/reports/policywordings/policywording_omi_og_2.pdf target=_blank>Policy Wording</a>'
         else if(lis.Insurer_ID = 1037 and lis.PolicyType_ID = 1 and lis.pid = 1085) then 
        		'<a href=https://www.lum.co.za/reports/policywordings/policywording_omi_dr_2.pdf target=_blank>Policy Wording</a>'
          else if(lis.Insurer_ID = 1037 and lis.PolicyType_ID = 1 and lis.pid = 1084) then 
        		'<a href=https://www.lum.co.za/reports/policywordings/policywording_omi_oc_2.pdf target=_blank>Policy Wording</a>'
         else 
        	''
         endif  endif endif endif endif endif endif  endif endif AS PolicyWording
         ,u.pid as User_ID
         ,u.UserName as UserName
        ,bb.BranchCode as branchcode
        ,bn.BankName1 as bankname
        ,p.AccountHolder as accountname
        ,p.AccountNumber as accountnumber
        ,ifnull(aad.hasAssist,'N',aad.hasAssist) as AssistYN
        ,ifnull(aad.hasAssist,'0861468882',aad.assistTel) as AssistTel
        ,ifnull(aad.hasAssist,'0861468882',aad.assistCompany_ID) as AssistCompanyID
        ,ifnull(aad.hasAssist,'0861468882',aad.assistCompanyName) as AssistCompanyName
        ,now() as jwtTimeStamp
        

            from users as u
            join policy as p on p.pid=u.linkedpolicy_id
            join client as c on c.pid=p.client_id
            left outer join l_broker as b on b.pid=p.activebroker_id
            join l_policyprefix as ppf on ppf.pid=p.policyprefix_id
            join l_insurerscheme as lis on lis.pid=ppf.insurerscheme_id
            join l_insurer as i on i.pid=lis.insurer_id
            join l_policystatus as lps on lps.pid=p.policystatus_id
            left outer join L_BankName as bn on bn.pid=p.Bank_Id
            left outer join L_BankBranch as bb on bb.pid=p.BankBranchCode_ID
            left outer join app_active_assist_details as aad on aad.policy_id=p.pid

            where
            u.pid=$userid
            
        ";
        $prof = $this->db->data($sql);
        $prof["PolicyItems"] = $this->getGrougedPolicyItems($prof["Policy_ID"],'N');
        $sqlPrems = "
        select
IFNULL(p.InvestmentPremiumTotal, 0, p.InvestmentPremiumTotal) as ph_invest   
 ,IFNULL(p.NettPremiumTotal, 0, p.NettPremiumTotal) as ph_nett   
 ,IFNULL(p.VatPremiumTotal, 0, p.VatPremiumTotal) as ph_vat 
 ,IFNULL(SasriaPremiumTotal, 0, p.SasriaPremiumTotal) as ph_sasria    
 ,IFNULL(p.AdminCostTotal, 0, p.AdminCostTotal) as ph_admin    
 ,IFNULL(p.AdminCost1Total, 0, p.AdminCost1Total) as ph_admin1 
 ,IFNULL(p.AdminCost2Total, 0, p.AdminCost2Total) as ph_admin2      
 ,IFNULL(p.BrutoPremiumTotal, 0, p.BrutoPremiumTotal) as ph_bruto   
 ,(SELECT SUM(
                                ifnull(R_HouseHoldAccidentalDamage,0,R_HouseHoldAccidentalDamage)
                                +ifnull(R_MotorVehicleCarRental,0,R_MotorVehicleCarRental)
                                +ifnull(R_ToolsPartsAccPremium,0,R_ToolsPartsAccPremium)
                                +ifnull(R_MotorVehicleHirePurchase,0,R_MotorVehicleHirePurchase)
                                +ifnull(R_MotorVehicle3rdPartyLegal,0,R_MotorVehicle3rdPartyLegal)
                                +ifnull(R_MotorvehicleKeys,0,R_MotorvehicleKeys)
                                +ifnull(R_MotorVehicleCarRadio,0,R_MotorVehicleCarRadio)) FROM POLICYSECTION WHERE POLICY_ID=P.PID AND IFNULL(ISQUOTEYN,'N',ISQUOTEYN)='N' AND DELETEDYN='N') as ph_extras          
 ,lol_CalcCommission(p.pid) as ph_agent_commission                         
 ,p.PolicyStatus_ID                                             
 ,p.ArrearAmount                                               
 ,p.R_CurrentProRata                                               
 ,p.R_ProrataOnDeletedItems 
 ,get_TotProrataForNextCollection(p.pid) as ProrataNextCollection 
                    from users as u
            join policy as p on p.pid=u.linkedpolicy_id
             where
            u.pid=$userid
        ";
        
        
        $prof["Premium"] = $this->db->data($sqlPrems);
        
        $limSql = "select * from pwa_GetClaimLimits(" . $prof["Policy_ID"] .")";
        $prof["ClaimLimits"] = $this->db->data($limSql);
        return $prof;
        
    }
    
    public function register($param, $pass, $otpConfirmed = false){
        $sqlp = "
        select first
            p.pid as Policy_ID
            ,c.CellNumber as CellNumber
            from policy as p
            join client as c on c.pid=p.client_id
            where
            ((c.emailaddress='$param')
                or (c.cellnumber='$param')
                or (p.policycode='$param')
                or (c.idnumber='$param')                
            )
            and p.policystatus_id in (2)
            order by
            p.pid desc
        ";
        
        $sqlu = "
            select first
            LinkedPolicy_ID as LinkedPolicy_ID
            from users
            where
                username='$param'
                
        ";
        
        if ( $p = $this->db->data($sqlp)) {
            if ( $u = $this->db->data($sqlu)) {
                // existing user
                if ($u["LinkedPolicy_ID"] == $p["Policy_ID"]) {
                    //existing user, same policy
                    $res = $this->result(false,"User already exist for this policy", null, null);
                } else {
                    //existing user, different policy
                    $res = $this->result(false,"User already exist, but different policy", null, null);
                }
                
            } else {
                //New User
                //TODO Create User
                if ($otpConfirmed) {
                    $policyid= $p["Policy_ID"];
                    $sqlnew = "
                        call pwa2020_create_user('$param','$pass',$policyid);
                        
                    ";
                    if ( $n = $this->db->query($sqlnew)) {
                        $urec = $this->db->data("select max(PID) as PID from users where username='$param'");
                        $uprofile = $this->getUserPolicyProfile($urec["PID"]);
                        $this->jwtToken = $uprofile;
                        $res = $this->result(true,"Profile created", $uprofile, null);                    
                    } else {
                        $res = $this->result(false,"Could not create user", null, null);                      
                    }
                } else {
//xx                    $uprofile = $this->getUserPolicyProfile($p["Policy_ID"]);
                    $u = array();
                    $xOTP = lolHelperFunctions::genOTP();
                    // send SMS
                    lolHelperFunctions::sendSMS($p["CellNumber"],"Your MyPolicy OTP is: " . $xOTP);
                    //$xOTP ='12345';
                    $uprofile["OTP"] = $xOTP;
                    $this->jwtToken = $uprofile;
                    $res = $this->result(true,"Enter OTP", null, null); 
                }
                

            }
        } else {
            // no client found
            $res = $this->result(false,"No Active Policy found for this Policy Holder.", null, null);
        }
        
        
        return $res;
    }

    
    public function getDB() {
        return $this->db;
    }




    public function getAllLookUps($prefix = 4){
        
        $tabs = array();
        
        $q  = $this->db->query("select distinct lookuptable, trim(check_lookupTableView(lookuptable,$prefix)) as ltab, if duallang='Y' then trim(lookuplistfield) || '2' else trim(lookuplistfield) endif as lookuplistfield from vAllQuestionTables where questiontypeid=2 and length(trim(lookuptable))>2
                                  and lookuptable not in ('l_caravantrailercovertype','L_City','L_City2015','L_Suburb','L_Suburb2015','l_employer','l_farmfencewallmeterial','l_staff','l_vehiclemake','l_vehiclemodel')");
        while ($r = $this->db->row($q)) {
//            $tabs[$r["lookuptable"]] = $this->db->all("select max(pid) as ID, " . $r["lookuplistfield"] . " as Value from " . $r["ltab"] . " group by value order by value");   
            $tabs[$r["lookuptable"]] = $this->db->all("select pid as ID, " . $r["lookuplistfield"] . " as Value from " . $r["ltab"] . "  order by value");   
        }
        

        return json_encode($tabs);
        
        
    }
    public function getPolicyItems($policyID, $del = null, $sec=null, $covertype =null) {
        $sql = "
            select
                ps.pid as PID
                ,ps.PolicySection_ID
                ,ps.DeletedYN
                ,ps.ItemDescription
                ,ps.Policy_ID
                ,p.Client_ID
                ,lps.Policysection2
                ,ps.ItemType_ID
                ,ps.ItemType
                ,ps.R_TotalInsuredAmount
                ,ps.R_NettPremium
                ,ps.R_TotalForLineItem
            from
                policysection as ps
                join policy as p on p.pid=ps.policy_id
                join client as c on c.pid=p.client_id
                join l_policysection as lps on lps.pid=ps.policysection_id
            where
                ps.policy_id=$policyID
                
        ";
        if ($del) {
            $sql .= " and ps.deletedyn='$del'";
        }
        if ($sec) {
            $sql .= " and ps.policysection_id in ($sec)";
        }
        if ($covertype) {
            $sql .= " and ps.policysection_id in ($covertype)";
        }
        return $this->db->all($sql);
        
        
    }

    public function getGrougedPolicyItems($policyID, $del = null, $sec=null, $covertype =null) {
        $sql = "
            select
                ps.pid as PID
                ,ps.PolicySection_ID
                ,ps.DeletedYN
                ,ps.ItemDescription
                ,ps.Policy_ID
                ,p.Client_ID
                ,ps.CellPhoneIEMI
                ,lps.Policysection2
                ,ps.ItemType_ID
                ,ps.ItemType
                ,ps.R_TotalInsuredAmount
                ,ps.R_NettPremium
                ,ps.R_TotalForLineItem
                ,if ps.policysection_id=6 then 'Y' else 'N' endif as Endos_M_YN
            from
                policysection as ps
                join policy as p on p.pid=ps.policy_id
                join client as c on c.pid=p.client_id
                join l_policysection as lps on lps.pid=ps.policysection_id
            where
                ps.policy_id=$policyID
                
        ";
        if ($del) {
            $sql .= " and ps.deletedyn='$del'";
        }
        if ($sec) {
            $sql .= " and ps.policysection_id in ($sec)";
        }
        if ($covertype) {
            $sql .= " and ps.policysection_id in ($covertype)";
        }
        $sql .= " order by ps.policysection_id ";
//echo $sql;
        $q = $this->db->query($sql);
        $res = array();
        $oldSec=0;
        $tmp = null;
        while ($r = $this->db->row($q)) {
            if ($r["PolicySection_ID"] <> $oldSec) {
                if ($oldSec>0){
                    $res[$oldSec] = $tmp;
                    $tmp = array();
                    $tmp[] = $r;
                } else {
                    
                    $tmp = array();
                    $tmp[] = $r;
                    
                }
                $oldSec = $r["PolicySection_ID"];
                
            } else {
                $tmp[] = $r;
                
            }
        }
        if ($tmp) {
            $res[$oldSec] = $tmp;
        }
        return $res;
    }

    /****************
     * Creator: Gert van Eeden
     * Date: 2021-01-13
     * 
     * New functions to get data from system for Add Vehicle App
     * 
     * 
     * */

    public function getTableData($tableName = "", $orderCol = "")
    {
        $tabs = array();
        if($tableName != "")
        {
            $sql = "select * from ". $tableName;
            if($orderCol != "")
            {
                $sql .= " ORDER BY ".$orderCol ."   ";
            }
            
        }
        // echo $sql;
        $q = $this->db->query($sql);

        while ($r = $this->db->row($q)) {
            if($orderCol != "")
            {
                $tabs[$r[$orderCol]] = $r;
            }
            else
            {
                $tabs[$r["PID"]] = $r;
           }
        }
        return json_encode($tabs);
    }

    public function getVehicleMakes()
    {
        $tabs = array();
        
        $sql = "SELECT L_VehicleMake.VehicleMake1, L_VehicleMake.PID 
            FROM L_VehicleMake  
            LEFT OUTER JOIN L_Vehicle ON L_VehicleMake.PID = L_Vehicle.VehicleMake_ID
            WHERE L_Vehicle.VehicleType_ID = 2
            
            GROUP BY L_VehicleMake.VehicleMake1, L_VehicleMake.PID 
            ORDER BY L_VehicleMake.VehicleMake1";
        
        $q = $this->db->query($sql);

        while ($r = $this->db->row($q)) {
            $tabs[$r["VehicleMake1"]] = $r;
        }
        return json_encode($tabs);
    }

    /****************
     * Creator: Gert van Eeden
     * Date: 2021-01-13
     * 
     * New functions to get data from system for Add Vehicle App
     * 
     * 
     * */
    public function getVehicleBrands($VehicleMakePID,$vehicleYear)
    {
        // echo($VehicleMakePID);
        $tabs = array();
        if($VehicleMakePID <> "" AND is_numeric($vehicleYear) AND $vehicleYear >0 )
        {
            
            $vSqlString  = "SELECT m.pid, m.ModelDescription2, v.RetailPrice FROM L_Vehicle v ";
            $vSqlString .= "LEFT OUTER JOIN l_Vehiclemake vm on vm.PID = v.VehicleMake_Id ";
            $vSqlString .= "LEFT OUTER JOIN l_VehicleModel m on m.PID = v.VehicleModel_ID ";
            $vSqlString .= "WHERE vm.pid = ".$VehicleMakePID." AND v.PriceYear = ".$vehicleYear." ORDER BY m.ModelDescription2"; 
            
            // echo ($vSqlString);
            // $preSql = "SELECT 
            //     L_VehicleMake.VehicleMake1, 
            //     L_VehicleModel.ModelDescription1,
            //     MAX(L_Vehicle.PID) AS VehiclePID,
            //     MAX(L_VehicleMake.PID) AS VehicleMakePID, 
            //     MAX(L_VehicleModel.PID) AS L_VehicleModelPID
                
            //     FROM L_Vehicle 
            //     LEFT OUTER JOIN L_VehicleMake ON L_VehicleMake.PID = L_Vehicle.VehicleMake_ID
            //     LEFT OUTER JOIN L_VehicleModel ON L_VehicleModel.PID = L_Vehicle.VehicleModel_ID
            //     WHERE 
            //     ";
            // $postSql ="
            //     GROUP BY 
            //     L_VehicleModel.ModelDescription1,
            //     L_VehicleMake.VehicleMake1
                
            //     ORDER BY L_VehicleModel.ModelDescription1,
            //     L_VehicleMake.VehicleMake1
            //     ";
            // Check for Mercedes will be implemented later
            if($VehicleMakePID == 20162 OR $VehicleMakePID == 20430)
            {
                $wherestring = " L_VehicleMake.PID = 20162
                    OR L_VehicleMake.PID = 20430 ";
            }
            else
            {
                $wherestring = " L_VehicleMake.PID = ". $VehicleMakePID." ";               
            }
            $sql = $preSql . $wherestring . $postSql;
            // echo($sql);


            $q = $this->db->query($vSqlString);
            // echo($q);
            while ($r = $this->db->row($q)) {
            //     $tabs[$r["L_VehicleModelPID"] = $r;
                // echo($r);
                // print_r($r);
                // echo($r["L_VehicleModelPID"]);
                $tabs[$r["ModelDescription2"]] = $r;
            }   
        }
        return json_encode($tabs);

    }

    /****************
     * Creator: Gert van Eeden
     * Date: 2021-01-15
     *
     * New functions to get vehicle retail value
     *
     *
     * */
    public function getRetailValue($VehicleMakeID, $VehicleYear, $VehicleModelID)
    {
        $tabs = array();
        // echo($VehicleMakeID ."-". $VehicleYear."-".$VehicleModelID);

        if($VehicleMakeID > 0 AND $VehicleYear > 0 AND   $VehicleModelID > 0)
        {
            // get Make and Model
            $sql1 = "SELECT MMCode FROM L_Vehicle WHERE VehicleMake_ID = " . $VehicleMakeID . " AND VehicleModel_ID =  " . $VehicleModelID;
            // echo("SQL:");
            // echo($sql1);
            // echo(": END SQL");
            $q1 = $this->db->query($sql1);
            $r1 = $this->db->row($q1);
            $MMCode = $r1['MMCode'];
            
            // echo($MMCode);

            if($MMCode != "")
            {
              $sql = "SELECT * FROM aMandM WHERE MMCode = '". $MMCode. "' AND YearModel ='". $VehicleYear ."' ";
            //   echo $sql;
              $q = $this->db->query($sql);
            //   echo($q);
              while ($r = $this->db->row($q)) {
                $tabs[$r["PID"]] = $r;
              }
            }
        }
        return json_encode($tabs);

    }

    /****************
     * Creator: Gert van Eeden
     * Date: 2021-01-19
     *
     * Get suburbs for drop down list
     *
     *
     * */
    public function getSuburbs($suburb)
    {
        $tabs = array();
        if(strlen($suburb) >= 4)
        {
            $sql = "SELECT * FROM L_Suburb2015 Where Suburb1 LIKE '" .$suburb . "%' ORDER BY Suburb1";
            // echo($sql);
            $q = $this->db->query($sql);
            //   echo($q);
              while ($r = $this->db->row($q)) {
                $tabs[$r["Suburb2"].$r["PID"]] = $r;
              }
        }
        return json_encode($tabs);
    }

    /****************
     * Creator: Gert van Eeden
     * Date: 2021-01-19
     *
     * Get City for drop down list
     *
     * */
    public function getCity($SuburbID="0")
    {
        $tabs = array();
        if(is_numeric($SuburbID) && $SuburbID > 0)
        {
            // $sql = "SELECT * FROM L_City WHERE PID = ".$CityID." ORDER BY City1";
            $vSqlString = "SELECT csa.city_id, c.City2, csa.PostalCode AS pcode, csa.Area_ID FROM city_sub_area_2015 csa ";
			$vSqlString .= "JOIN L_Suburb2015 s ON csa.suburb_ID = s.PID ";
            $vSqlString .= "JOIN L_City2015 c ON csa.City_ID = c.PID WHERE csa.Suburb_ID = " . $SuburbID . " ORDER BY c.City2";	
            
            // echo($vSqlString);

            $q = $this->db->query($vSqlString);
            //   echo($q);
              while ($r = $this->db->row($q)) {
                $tabs[$r["City2"].$r["PID"]] = $r;
              }

        }
        return json_encode($tabs);
    }
    
}


?>