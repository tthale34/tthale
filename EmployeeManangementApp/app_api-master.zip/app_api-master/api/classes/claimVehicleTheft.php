<?php
include_once("claimBase.php");
class claimVehicleTheft extends claimBase {
    private $customDbMap = array(
            "fields" => array(
                    "PolicySection_ID" => array("field" => "PolicySection_Id","tablePrefix" => "pc","readOnly" => false),
                    "TotalLossYN" => array("field" => "TotalLossYN","tablePrefix" => "pc","readOnly" => false),
                    "PossibleRecoveryYN" => array("field" => "PossibleRecoveryYN","tablePrefix" => "pc","readOnly" => false),
                    "SecurityDependantYN" => array("field" => "SecurityDependantYN","tablePrefix" => "pc","readOnly" => false),
                    "GenTheftReportFormYN" => array("field" => "GenTheftReportFormYN","tablePrefix" => "pc","readOnly" => false),
                    "PossibleCounterClaim" => array("field" => "PossibleCounterClaim","tablePrefix" => "pc","readOnly" => false),
                    "WhereYouDrivingYN" => array("field" => "WhereYouDrivingYN","tablePrefix" => "pc","readOnly" => false),
                    "DriverPocessionValidLicence" => array("field" => "DriverPocessionValidLicence","tablePrefix" => "pc","readOnly" => false),
                    "AOLReceivedYN" => array("field" => "AOLReceivedYN","tablePrefix" => "pc","readOnly" => false),
                    "AssessorsReportReceivedYN" => array("field" => "AssessorsReportReceivedYN","tablePrefix" => "pc","readOnly" => false),
                    "RecoverySuccessAction_ID" => array("field" => "RecoverySuccessAction_ID","tablePrefix" => "pc","readOnly" => false),
                    "CarHireStartDate" => array("field" => "CarHireStartDate","tablePrefix" => "pc","readOnly" => false),
                    "CarRentalCompany_ID" => array("field" => "CarRentalCompany_ID","tablePrefix" => "pc","readOnly" => false),
                    "PolicyHolderJobTitle_ID" => array("field" => "PolicyHolderJobTitle_ID","tablePrefix" => "pc","readOnly" => false),
                    "PolicyHolderIDNumber" => array("field" => "PolicyHolderIDNumber","tablePrefix" => "pc","readOnly" => false),
                    "PolicyHolderHomePhone" => array("field" => "PolicyHolderHomePhone","tablePrefix" => "pc","readOnly" => false),
                    "PolicyHolderWorkPhone" => array("field" => "PolicyHolderWorkPhone","tablePrefix" => "pc","readOnly" => false),
                    "PolicyHolderCellPhone" => array("field" => "PolicyHolderCellPhone","tablePrefix" => "pc","readOnly" => false),
                    "EmailAddress" => array("field" => "EmailAddress","tablePrefix" => "pc","readOnly" => false),
                    "ItemDescription" => array("field" => "ItemDescription","tablePrefix" => "pc","readOnly" => false),
                    "CoverType_ID" => array("field" => "CoverType_ID","tablePrefix" => "pc","readOnly" => false),
                    "MotorVehicle_ID" => array("field" => "MotorVehicle_ID","tablePrefix" => "pc","readOnly" => false),
                    "YearModel" => array("field" => "YearModel","tablePrefix" => "pc","readOnly" => false),
                    "RegistrationNumber" => array("field" => "RegistrationNumber","tablePrefix" => "pc","readOnly" => false),
                    "R_InsuredAmount" => array("field" => "R_InsuredAmount","tablePrefix" => "pc","readOnly" => false),
                    "Milage" => array("field" => "Milage","tablePrefix" => "pc","readOnly" => false),
                    "ChassisNumber" => array("field" => "ChassisNumber","tablePrefix" => "pc","readOnly" => false),
                    "EngineNumber" => array("field" => "EngineNumber","tablePrefix" => "pc","readOnly" => false),
                    "InsuredUnderAnotherPolicyYN" => array("field" => "InsuredUnderAnotherPolicyYN","tablePrefix" => "pc","readOnly" => false),
                    "OtherPolicyInsurer_ID" => array("field" => "OtherPolicyInsurer_ID","tablePrefix" => "pc","readOnly" => false),
                    "OtherPolicyPolicyNumber" => array("field" => "OtherPolicyPolicyNumber","tablePrefix" => "pc","readOnly" => false),
                    "OtherPolicyAddress1" => array("field" => "OtherPolicyAddress1","tablePrefix" => "pc","readOnly" => false),
                    "HirePurchaseYN" => array("field" => "HirePurchaseYN","tablePrefix" => "pc","readOnly" => false),
                    "R_HirePurchaseOutstandAmount" => array("field" => "R_HirePurchaseOutstandAmount","tablePrefix" => "pc","readOnly" => false),
                    "HirePurchase_ID" => array("field" => "HirePurchase_ID","tablePrefix" => "pc","readOnly" => false),
                    "HirePurchaseRefNumber" => array("field" => "HirePurchaseRefNumber","tablePrefix" => "pc","readOnly" => false),
                    "RegisteredOwnerYN" => array("field" => "RegisteredOwnerYN","tablePrefix" => "pc","readOnly" => false),
                    "RegisteredOwnerName" => array("field" => "RegisteredOwnerName","tablePrefix" => "pc","readOnly" => false),
                    "RegisteredOwnerAddress1" => array("field" => "RegisteredOwnerAddress1","tablePrefix" => "pc","readOnly" => false),
                    "Interest" => array("field" => "Interest","tablePrefix" => "pc","readOnly" => false),
                    "TheftDate" => array("field" => "TheftDate","tablePrefix" => "pc","readOnly" => false),
                    "AccidentTime" => array("field" => "AccidentTime","tablePrefix" => "pc","readOnly" => false),
                    "AccidentPlace" => array("field" => "AccidentPlace","tablePrefix" => "pc","readOnly" => false),
                    "AccidentReportedYN" => array("field" => "AccidentReportedYN","tablePrefix" => "pc","readOnly" => false),
                    "AccidentReportedSAPDYN" => array("field" => "AccidentReportedSAPDYN","tablePrefix" => "pc","readOnly" => false),
                    "SAPDReferenceNumber" => array("field" => "SAPDReferenceNumber","tablePrefix" => "pc","readOnly" => false),
                    "SAPDReportedByWhom" => array("field" => "SAPDReportedByWhom","tablePrefix" => "pc","readOnly" => false),
                    "SAPDPoliceStation" => array("field" => "SAPDPoliceStation","tablePrefix" => "pc","readOnly" => false),
                    "AccidentDescription" => array("field" => "AccidentDescription","tablePrefix" => "pc","readOnly" => false),
                    "PurchaseDate" => array("field" => "PurchaseDate","tablePrefix" => "pc","readOnly" => false),
                    "R_PurchaseAmount" => array("field" => "R_PurchaseAmount","tablePrefix" => "pc","readOnly" => false),
                    "AntiTTheftDeviceYN" => array("field" => "AntiTTheftDeviceYN","tablePrefix" => "pc","readOnly" => false),
                    "AntiTTheftDeviceMake" => array("field" => "AntiTTheftDeviceMake","tablePrefix" => "pc","readOnly" => false),
                    "AntiTTheftDeviceIntalledBy" => array("field" => "AntiTTheftDeviceIntalledBy","tablePrefix" => "pc","readOnly" => false),
                    "InstallationDate" => array("field" => "InstallationDate","tablePrefix" => "pc","readOnly" => false),
                    "WindowEtchedYN" => array("field" => "WindowEtchedYN","tablePrefix" => "pc","readOnly" => false),
                    "WindowMarking" => array("field" => "WindowMarking","tablePrefix" => "pc","readOnly" => false),
                    "MarkingDesc" => array("field" => "MarkingDesc","tablePrefix" => "pc","readOnly" => false),
                    "NonStandardDesc" => array("field" => "NonStandardDesc","tablePrefix" => "pc","readOnly" => false),
                    "VehicleChangeModification" => array("field" => "VehicleChangeModification","tablePrefix" => "pc","readOnly" => false),
                    "VehicleSmallDefectYN" => array("field" => "VehicleSmallDefectYN","tablePrefix" => "pc","readOnly" => false),
                    "PersonalMarksYN" => array("field" => "PersonalMarksYN","tablePrefix" => "pc","readOnly" => false),
                    "PersonalMarks" => array("field" => "PersonalMarks","tablePrefix" => "pc","readOnly" => false),
                    "VehicleRadioYN" => array("field" => "VehicleRadioYN","tablePrefix" => "pc","readOnly" => false),
                    "RadioMake" => array("field" => "RadioMake","tablePrefix" => "pc","readOnly" => false),
                    "VehicleLockedYN" => array("field" => "VehicleLockedYN","tablePrefix" => "pc","readOnly" => false),
                    "ResponsiblePerson" => array("field" => "ResponsiblePerson","tablePrefix" => "pc","readOnly" => false),
                    "WhoPossessionKeys" => array("field" => "WhoPossessionKeys","tablePrefix" => "pc","readOnly" => false),
                    "VehicleInteriorColour_ID" => array("field" => "VehicleInteriorColour_ID","tablePrefix" => "pc","readOnly" => false),
                    "VehicleExteriorColour_ID" => array("field" => "VehicleExteriorColour_ID","tablePrefix" => "pc","readOnly" => false),
                    "RepudiationYN" => array("field" => "RepudiationYN","tablePrefix" => "pc","readOnly" => false),
                    "RepudiationReason" => array("field" => "RepudiationReason","tablePrefix" => "pc","readOnly" => false),
                    "CatastropheYN" => array("field" => "CatastropheYN","tablePrefix" => "pc","readOnly" => false),
                    "L_RecoverySuccessAction_RecoverySuccessAction_ID_RecoverySuccessAction" => array("field" => "RecoverySuccessAction2","tablePrefix" => "L_RecoverySuccessAction_RecoverySuccessAction_ID","readOnly" => true),
                    "L_vCarRentalCompany_CarRentalCompany_ID_CarRentalCompany" => array("field" => "CarRentalCompany","tablePrefix" => "L_vCarRentalCompany_CarRentalCompany_ID","readOnly" => true),
                    "L_IndustryJobTitle_PolicyHolderJobTitle_ID_IndustryJobTitle" => array("field" => "IndustryJobTitle2","tablePrefix" => "L_IndustryJobTitle_PolicyHolderJobTitle_ID","readOnly" => true),
                    "L_VehicleCoverType_CoverType_ID_CoverType" => array("field" => "CoverType2","tablePrefix" => "L_VehicleCoverType_CoverType_ID","readOnly" => true),
                    "L_Insurer_OtherPolicyInsurer_ID_Insurer" => array("field" => "Insurer2","tablePrefix" => "L_Insurer_OtherPolicyInsurer_ID","readOnly" => true),
                    "L_HirePurchaseCompany_HirePurchase_ID_Name" => array("field" => "Name2","tablePrefix" => "L_HirePurchaseCompany_HirePurchase_ID","readOnly" => true),
                    "L_Colour_VehicleInteriorColour_ID_Colour" => array("field" => "Colour2","tablePrefix" => "L_Colour_VehicleInteriorColour_ID","readOnly" => true),
                    "L_Colour_VehicleExteriorColour_ID_Colour" => array("field" => "Colour2","tablePrefix" => "L_Colour_VehicleExteriorColour_ID","readOnly" => true),
                    ),
            "joins" => array(
                    "L_RecoverySuccessAction_RecoverySuccessAction_ID"=>array("table"=>"L_RecoverySuccessAction","keyField"=>"pid","masterPrefix"=>"pc","masterField"=>"RecoverySuccessAction_ID"),
                    "L_vCarRentalCompany_CarRentalCompany_ID"=>array("table"=>"L_vCarRentalCompany","keyField"=>"pid","masterPrefix"=>"pc","masterField"=>"CarRentalCompany_ID"),
                    "L_IndustryJobTitle_PolicyHolderJobTitle_ID"=>array("table"=>"L_IndustryJobTitle","keyField"=>"pid","masterPrefix"=>"pc","masterField"=>"PolicyHolderJobTitle_ID"),
                    "L_VehicleCoverType_CoverType_ID"=>array("table"=>"L_VehicleCoverType","keyField"=>"pid","masterPrefix"=>"pc","masterField"=>"CoverType_ID"),
                    "L_Insurer_OtherPolicyInsurer_ID"=>array("table"=>"L_Insurer","keyField"=>"pid","masterPrefix"=>"pc","masterField"=>"OtherPolicyInsurer_ID"),
                    "L_HirePurchaseCompany_HirePurchase_ID"=>array("table"=>"L_HirePurchaseCompany","keyField"=>"pid","masterPrefix"=>"pc","masterField"=>"HirePurchase_ID"),
                    "L_Colour_VehicleInteriorColour_ID"=>array("table"=>"L_Colour","keyField"=>"pid","masterPrefix"=>"pc","masterField"=>"VehicleInteriorColour_ID"),
                    "L_Colour_VehicleExteriorColour_ID"=>array("table"=>"L_Colour","keyField"=>"pid","masterPrefix"=>"pc","masterField"=>"VehicleExteriorColour_ID"),                   
                    )

            );
 
    public function __construct($_lol, $ClaimID = null) {
            $this->ClaimTypeID = 5;
            $this->lol = $_lol;
            $this->dbmap = array_merge_recursive($this->baseDbMap,$this->customDbMap);
            if (isset($ClaimID)) {
                $this->claimID = $ClaimID;
                $this->loadClaimDetail();
            }
    }
    public function getDbMap(){
        return $this->dbmap;
    }


}// class


?>