<?php




class LMSFTP {
    public $ftp_server = "192.168.169.101";
    public $ftp_user_pass = "lms";
    public $ftp_user_name = "lmsuser";
    public $ftp_top_root = "/";
    public $conn_id = null;
    
    function __construct($ServerIP, $UserName, $Passw, $toproot = "/") {
        $this->ftp_server = $ServerIP;
        $this->ftp_user_name = $UserName;
        $this->ftp_user_pass = $Passw;
        $this->ftp_top_root = $toproot;
	$this->conn_id = ftp_connect($this->ftp_server); 

    }
    
    

    function get_root($aFile) {
	switch (substr(strtolower($aFile),-3)):
            case "jpg":
                $res = "ScannedImages/";
                break;
            case "png":
                $res = "ScannedImages/";
                break;
            case "peg":
                $res = "ScannedImages/";
                break;
            case "wav":
                $res = "VoiceRecordings/";
                break;
            default:
                $res = "Documents/";
        endswitch;
        
        return $this->ftp_top_root . $res;
    }

    function get_root_by_date($aFileType, $aDate, $Validate = false) {
        $res = $this->get_root($aFileType);
        $res .= date("Y/m/d", $aDate);
        $res .= "/";
        if ($validate) {
            $this->validate_path($res);
        }
        return $res;
    }
    
    function validate_path($aPath) {
	$filetree = explode("/",$aPath);
	// login with username and password
	$login_result = ftp_login($this->conn_id, $this->ftp_user_name, $this->ftp_user_pass); 
        //echo print_r($filetree);
	// check connection
	if ((!$this->conn_id) || (!$login_result)) {
		//die("FTP connection has failed !");
                //echo "ftp login failed\n";
                return false;
		}

	//echo "Current directory: " . ftp_pwd($this->conn_id) . "\n";
	$newdir = "/";
        $newdir = ftp_pwd($this->conn_id); // try fix
        //echo "New Dir: " . $newdir . "\n";
	# change the directory
	for ($i = 0; $i < count($filetree); $i++) {
		if ($thisdir = $filetree[$i]) {
                        //echo "This DIR: " . $thisdir . "\n";
			$newdir .= "/" . $thisdir;
                        //echo "newdir: " . $newdir . "\n";
			if (@ftp_chdir($this->conn_id, $newdir)) {  
				} else { 
					if (ftp_mkdir($this->conn_id, $newdir)) {
					 	//echo "successfully created $aPath <br>";
						} else {
						 	echo "There was a problem while creating $aPath <br>";
							exit(0);
							}
					if (ftp_chdir($this->conn_id, $newdir)) {
						//echo "Current directory is now: " . ftp_pwd($this->conn_id) . "<BR>";
						} else { 
							//echo "Couldn't change directory <BR>";
							exit(0);
							}
					}  
					
			}//if
		}//for
	// upload a file
        
        
    }

    function ftpfiletoserver($remote_folder, $folderdate, $localfilename){
	$this->ftp_user_name = "lmsuser";
	$this->ftp_user_pass = "lms";
	$this->ftp_server = "192.168.169.101";
	// set up basic connection
	
	
	
	if ($folderdate){
		if (!(substr($remote_folder,-1)=="/")) { 
			$remote_folder .= "/";
			};
			
		$remote_folder .= date("Y/m/d");
		} else {
                    $remote_folder = $this->ftp_top_root . "ftptemp";
                };
//        echo "Remote folder: " . $remote_folder . "\n";

// validatepath
	$filetree = explode("/",$remote_folder);
	// login with username and password
	$login_result = ftp_login($this->conn_id, $this->ftp_user_name, $this->ftp_user_pass); 
        //echo print_r($filetree);
	// check connection
	if ((!$this->conn_id) || (!$login_result)) {
		//die("FTP connection has failed !");
                //echo "ftp login failed\n";
                return false;
		}

	//echo "Current directory: " . ftp_pwd($this->conn_id) . "\n";
	$newdir = "/";
        $newdir = ftp_pwd($this->conn_id); // try fix
	# change the directory
	for ($i = 0; $i < count($filetree); $i++) {
		if ($thisdir = $filetree[$i]) {
			$newdir .= "/" . $thisdir;
                        //echo "newdir: " . $newdir . "\n";
			if (@ftp_chdir($this->conn_id, $newdir)) {  
				} else { 
					if (ftp_mkdir($this->conn_id, $newdir)) {
					 	//echo "successfully created $remote_folder <br>";
						} else {
						 	//echo "There was a problem while creating $remote_folder <br>";
							exit(0);
							}
					if (ftp_chdir($this->conn_id, $newdir)) {
						//echo "Current directory is now: " . ftp_pwd($this->conn_id) . "<BR>";
						} else { 
							//echo "Couldn't change directory <BR>";
							exit(0);
							}
					}  
					
			}//if
		}//for
	// upload a file

// validate path end
	if (ftp_put($this->conn_id, basename($localfilename), $localfilename, FTP_BINARY)) {
		//////echo "FTP OK: Successfully uploaded $file\n";
                return true;
                
		} else {
			//////echo "FTP ERROR: There was a problem while uploading $file\n";
                        return false;
			}
    } //ftpfiletoserver
}

?>