<?php

class claimBase{
        protected $lol;
        protected $dbmap;
        protected $itemID;
        protected $itemDetail;
        protected $itemmData;
        protected $itemTypeID;
        protected $baseDbMap = array(
                        "fields" => array(
                                "PID" => array("field" => "pid","tablePrefix" => "ps"),
                                "_Policy_ID" => array("field" => "policy_id","tablePrefix" => "ps"),
                                "_Client_ID" => array("field" => "client_id","tablePrefix" => "p"),
                                "ItemDescription" => array("field" => "ItemDescription","tablePrefix" => "ps"),
                                "_ItemType" => array("field" => "policySection2","tablePrefix" => "lps"),
                                "R_TotalInsuredAmoun" => array("field" => "R_TotalInsuredAmoun","tablePrefix" => "ps"),
                                "R_InsuredAmoun" => array("field" => "R_TotalInsuredAmoun","tablePrefix" => "ps"),
                                "r_NettPremium" => array("field" => "r_NettPremium","tablePrefix" => "ps"),
                                
                                
                                ),
                        "baseTable" => array("table"=>"policysection","prefix"=>"ps", "keyField"=>"PID", "filterField"=>"PID"),
                        "joins" => array(
                                "p"=>array("table"=>"policy","keyField"=>"pid","masterPrefix"=>"ps","masterField"=>"policy_id"),
                                "c"=>array("table"=>"client","keyField"=>"pid","masterPrefix"=>"p","masterField"=>"client_id"),
                                "lps"=>array("table"=>"l_policysection","keyField"=>"pid","masterPrefix"=>"ps","masterField"=>"policysection_id"),
                                )
                        );

        public function __construct($_lol) {
                $this->lol = $_lol;
                $this->dbmap = $this->baseDbMap;
            
        }
        protected function newItem($policySectionID){
//                $sql  = "SELECT new_Claim(".$policySectionID.", ".$this->ClaimTypeID.", '3170', '".$dateOfLoss."') AS NewClaim_ID;";
//                $res = $this->lol->getDB()->data($sql);
                $this->itemID = $res["NewItem_ID"];
                $this->loadItemDetail();
        }
        
        public function loadItemDetail() {
               $this->itemDetail =  $this->lol->getDB()->all($this->lol->getDB()->selectSqlFromMap($this->dbmap,$this->itemID));
        }
        
        public function getItemDetail(){
                return $this->itemDetail;
        }
        
        public function getItemSQL(){
                return $this->lol->getDB()->selectSqlFromMap($this->dbmap,$this->itemID);
        }
        public function updateItem($data){
                $filename = "/tmp/item_update_" . $this->itemID . ".txt";
                $data["PID"] = $this->itemID;
                $sql=$this->lol->getDB()->updateSqlFromMap($this->dbmap,$data);
                $this->lol->getDB()->query($sql);
                file_put_contents($filename, $sql);
        }
}    //class
                        
                        
                        
                        
                        
                        
                        
                        


?>