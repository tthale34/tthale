<?php
class claimBase{
        protected $lol;
        protected $dbmap;
        protected $claimID;
        protected $claimDetail;
        protected $dbValidation;
        protected $dbValidationProc;
        protected $dbFastTrackProc = "pwa_FastTrackClaim";
        protected $claimData;
        protected $ClaimTypeID;
        protected $staticDetail;
        protected $postData;
        protected $templates = array(
            "emailBrokerValidationFail" => "claim/email.broker.validation.fail.html",
            "emailLegacyValidationFail" => "claim/email.legacy.validation.fail.html",
            "emailNewClaimNotifyBroker" => "claim/email.new.claim.notify.broker.html",
            "emailNewClaimPaymentNotifyBroker" => "claim/email.new.claim.payment.notify.broker.html",
            "emailNewClaimValidationPassNotifyBroker" => "claim/email.new.claim.validation.pass.broker.html",
            "smsNewClaimNotify" => "claim/sms.new.claim.notify.txt",
            "smsNewClaimPaymentNotifyClient" => "claim/sms.new.claim.payment.notify.client.txt",
            "smsNewClaimValidationFail" => "claim/sms.new.claim.validation.fail.txt",
            "smsNewClaimValidationPass" => "claim/sms.new.claim.validation.pass.client.txt",
            "emailnewClaimFastTrackFail" => "claim/email.new.claim.fasttrack.fail.lum.html",
            "smsNewClaimNotifyLink" => "claim/spec.all.risk2.sms.txt",
            "emailBrokerNotifyLink" => "claim/spec.all.risk2.brokeremail.html",
            "emailBrokerDamageNotifyLink" => "claim/spec.all.risk2.damaged.brokeremail.html",
            "emailClientNotifyLink" => "claim/spec.all.risk2.cleintemail.html",
            "emailClientDamageNotifyLink" => "claim/spec.all.risk2.damaged.cleintemail.html",
            "emailBrokerSAPSNULL" => "claim/spec.all.risk6.2_EmailBroker.html",
            "emailLUMSAPSNULL" => "claim/spec.all.risk.6.2_EmailLUM.html",
            "emailLUMVehicleNotLocked" => "claim/spec.all.risk51_vlocked_EmailLUM.html",
            "emailLUMVehicleForcedIn" => "claim/spec.all.risk52_vforced_EmailLUM.html",
            "emailLUMItemVisible" => "claim/spec.all.risk53_itemVisible_EmailLUM.html",
            "emailBrokerVehicleNotLocked" => "claim/spec.all.risk51_vlocked_EmailBroker.html",
            "emailBrokerVehicleForcedIn" => "claim/spec.all.risk52_vforced_EmailBroker.html",
            "emailBrokerItemVisible" => "claim/spec.all.risk53_itemVisible_EmailBroker.html",
            "emailLUMBicycleNotify" => "claim/spec.all.risk5ii_bicycle_EmailLUM.html",
            "emailBrokerBicycleNotify" => "claim/spec.all.risk5ii_bicycle_EmailBroker.html",
            "emailLUMMusicNotify" => "claim/spec.all.risk5ii_music_EmailLUM.html",
            "emailBrokerMusicNotify" => "claim/spec.all.risk5ii_music_EmailBroker.html",
            "emailLUMPhotoNotify" => "claim/spec.all.risk5ii_photo_EmailLUM.html",
            "emailBrokerPhotoNotify" => "claim/spec.all.risk5ii_photo_EmailBroker.html",
            "emailLUMSportsNotify" => "claim/spec.all.risk5ii_sports_EmailLUM.html",
            "emailBrokerSportsNotify" => "claim/spec.all.risk5ii_sports_EmailBroker.html",
            "emailLUMJewelryNotify" => "claim/spec.all.risk31i_jewelry_EmailLUM.html",
            "emailBrokerJewelryNotify" => "claim/spec.all.risk31i_jewelry_EmailBroker.html",
            "emailLinkNotification" => "claim/spec.all.risk_docupload_EmailLUM.html",
        );
        protected $baseDbMap = array(
                        "fields" => array(
                                "PID" => array("field" => "pid","tablePrefix" => "pc"),
                                "ClaimCode" => array("field" => "ClaimCode","tablePrefix" => "pc"),
                                "R_BudgetAmount" => array("field" => "R_BudgetAmount","tablePrefix" => "pc"),
                                "R_OriginalBudgetAmount" => array("field" => "R_OriginalBudgetAmount","tablePrefix" => "pc"),
                                "R_OutstandingAmount" => array("field" => "R_OutstandingAmount","tablePrefix" => "pc"),
                                "_Policy_ID" => array("field" => "policy_id","tablePrefix" => "pc"),
                                "_Client_ID" => array("field" => "client_id","tablePrefix" => "p"),
                                "_ItemDescription" => array("field" => "ItemDescription","tablePrefix" => "ps"),
                                "_ClaimType" => array("field" => "ClaimType2","tablePrefix" => "ct"),
                                "ClientCommonName" => array("field" => "ClientCommonName","tablePrefix" => "c"),
                                "ClientCell" => array("field" => "cellnumber","tablePrefix" => "c"),
                                "ClientEmail" => array("field" => "emailaddress","tablePrefix" => "c"),
                                "BrokerCell" => array("field" => "CellularNumber","tablePrefix" => "b"),
                                "BrokerEmail" => array("field" => "EmailAddress","tablePrefix" => "b"),
                                "OccuredDate" => array("field" => "OccuredDate","tablePrefix" => "pc"),
                                ),
                        "baseTable" => array("table"=>"policyclaim","prefix"=>"pc", "keyField"=>"PID", "filterField"=>"PID"),
                        "joins" => array(
                                "p"=>array("table"=>"policy","keyField"=>"pid","masterPrefix"=>"pc","masterField"=>"policy_id"),
                                "c"=>array("table"=>"client","keyField"=>"pid","masterPrefix"=>"p","masterField"=>"client_id"),
                                "ps"=>array("table"=>"policysection","keyField"=>"pid","masterPrefix"=>"pc","masterField"=>"policysection_id"),
                                "ct"=>array("table"=>"l_claimtype","keyField"=>"pid","masterPrefix"=>"pc","masterField"=>"ClaimType_ID"),
                                "b"=>array("table"=>"l_broker","keyField"=>"pid","masterPrefix"=>"p","masterField"=>"ActiveBroker_ID"),
                                )
                        );

        public function __construct($_lol) {
                $this->lol = $_lol;
            
        }
        
        public function getpostData() {
                return $this->postData;
        }
    public function makeNote($note){
        $n = $this->lol->getDB()->dbCleanString($note);
        $sqlNote = "call claim_makenote(" . $this->claimID . "," . $this->lol->getUserId() . ",'" . $n ."');";
        $res = $this->lol->getDB()->query($sqlNote);
        
    }
    
    
    public function addDocument($filename, $docDescription, $CorTypeID = 5){
        $this->loadClaimDetail();
        $filename = basename($filename);
        if (isset($this->claimID)){
                if ($this->claimID>0){
                        $sql = "SELECT LOL_Add_ClaimCorrespondence_Document(".$this->claimID.",0,3170, ".$CorTypeID.", '".$docDescription."', '" . $filename . "') AS NewCorID;";
                        $res = $this->lol->getDB()->data($sql);
                }
                
                
        }
        
        
    }
    
    
        protected function newClaim($policySectionID,$dateOfLoss){
                $sql  = "SELECT new_Claim(".$policySectionID.", ".$this->ClaimTypeID.", '3170', '".$dateOfLoss."') AS NewClaim_ID;";
                $res = $this->lol->getDB()->data($sql);
                $this->claimID = $res["NewClaim_ID"];
                $this->loadClaimDetail();
        }
        
        public function loadClaimDetail() {
            if ($this->claimID > 0) {
               $this->lol->getDB()->query("call lol_update_policysection_on_claimpayment(" . $this->claimID . ");");
               $basicData =  $this->lol->getDB()->data($this->lol->getDB()->selectSqlFromMap($this->dbmap,$this->claimID));
               if (isset($this->staticDetail)) {
                    $this->claimDetail = array_merge_recursive($basicData,$this->staticDetail);
               }
            }
        }
        
        public function getClaimDetail($refresh = false){
                if ($refresh) {
                    $this->loadClaimDetail();
                };
                if (isset($this->claimDetail)) {
                    return $this->claimDetail;    
                } else {
                    $this->loadClaimDetail();
                    return $this->claimDetail;    
                }
                
                
        }

        function getClaimCode($claimID){
                $getCodeSql = "select claimcode from policyclaim where pid = ".$claimID; 
                $claimCode = $this->lol->getDB()->data($getCodeSql);
                if($claimCode){
                        while($row = sasql_fetch_array($claimCode)){
                                $res['claimCode'] = $row['claimcode'];
                        }   
                }
                return $res;
        }
        
        public function getClaimSQL(){
                return $this->lol->getDB()->selectSqlFromMap($this->dbmap,$this->claimID);
        }
        public function updateClaim($data){
                $filename = "/tmp/claim_update_" . $this->claimID . ".txt";
                $data["PID"] = $this->claimID;
                $sql=$this->lol->getDB()->updateSqlFromMap($this->dbmap,$data);
                $this->lol->getDB()->query($sql);
                file_put_contents($filename, $sql);
        }
        public function updateAutoSMSLog($claimID){
                $sql="UPDATE AutomatedSMSLog SET Status_ID = 2 WHERE DataLinkType_ID = 4 and SMSTemplate_ID = 1 and DataKey_ID = ".$claimID."; commit;";;
                $this->lol->getDB()->query($sql);
        }

        public function dbValidate(){
                $sql="select * from " . $this->dbValidationProc . "(" . $this->claimID . ")";
                if ($res = $this->lol->getDB()->data($sql)) {
                        $this->dbValidation = (object) $res;
                }
        }

        public function getDbValidation($refresh = false) {
                if ((is_object($this->dbValidation)) and ($refresh == false)) {
                        return $this->dbValidation;
                } else {
                        if ($this->claimID>0) {
                                $this->dbValidate();
                                if (is_object($this->dbValidation)) {
                                        return $this->dbValidation;
                                } else {
                                        return false;
                                }
                        } else {
                                return false;        
                        }
                }
        }

        public function fastTrack() {
                $sql="select * from " . $this->dbFastTrackProc . "(" . $this->claimID . ")";
                if ($res = $this->lol->getDB()->data($sql)) {
                        return (object) $res;
                }
            
        }
        
/*
        public function sendClientSMS($policyId,$claimCode,$claimID,$msg){
                $cellNumber = $this->lol->getDB()->query("select c.cellNumber as cell from policy as p left outer join client as c on p.client_id = c.pid  where p.pid = '".$policyId."'");
                while ($row = sasql_fetch_array($cellNumber)) {
                        $msg = $msg.' '.$claimCode;
                        $sms = new SMSviaHTTP("LUMSMS01", "TRHITUJT", "https://iweb.itouchsa.co.za/submit");
                        $response = $sms->SendSMS($row['cell'], $msg);
                        if (strtoupper(trim($res[0])) == "SUCCESS") {                    
                                $this->lol->getDB()->query("call claim_makenote(" . $claimID .",0,'SMS to Client: " . $msg  ."');");
                                return 'SMS Sent';
                        } else {
                                return 'error sending sms';
                        }
                }
        }
*/
        
        public function emailBrokerTemplate($TemplateName, $sub = null, $addData = null) {
            if ($templateFile = $this->templates[$TemplateName]) {
                $claimData = $this->getClaimDetail();
                if (isset($sub)) {
                    $s = $sub . " " . $claimData["ClaimCode"];
                } else {
                    $s = "Claim: " . $claimData["ClaimCode"];
                }
                
                if (isset($addData)) {
                    $d = array_merge_recursive($claimData,(array) $addData);
                } else {
                    $d = $claimData;
                }
                $brokerEmail = $claimData["BrokerEmail"];
                if ($t = templateBuilder::populateTemplateFile($templateFile, $d)) {
                    lolHelperFunctions::sendEmail($brokerEmail, $brokerEmail,  "lumunderwriting@lum.co.za", "lumunderwriting@lum.co.za","" ,"",$s, $t );
                    $this->makeNote("Email to Broker ($brokerEmail): " . $s . " : " . $t);
                }
                
            }
            
        }

        public function emailClientTemplate($TemplateName, $sub = null, $addData = null) {
            if ($templateFile = $this->templates[$TemplateName]) {
                $claimData = $this->getClaimDetail();
                if (isset($sub)) {
                    $s = $sub . " " . $claimData["ClaimCode"];
                } else {
                    $s = "Claim: " . $claimData["ClaimCode"];
                }
                
                if (isset($addData)) {
                    $d = array_merge_recursive($claimData,(array) $addData);
                } else {
                    $d = $claimData;
                }
                $clientEmail = $claimData["ClientEmail"];
                if ($t = templateBuilder::populateTemplateFile($templateFile, $d)) {
                    lolHelperFunctions::sendEmail($clientEmail, $clientEmail,  "lumunderwriting@lum.co.za", "lumunderwriting@lum.co.za","" ,"",$s, $t );
                    $this->makeNote("Email to Client ($clientEmail): " . $s . " : " . $t);
                }
                
            }
            
        }

        public function emailLUMTemplate($TemplateName, $sub = null, $addData = null) {
            if ($templateFile = $this->templates[$TemplateName]) {
                $claimData = $this->getClaimDetail();
                if (isset($sub)) {
                    $s = $sub . " " . $claimData["ClaimCode"];
                } else {
                    $s = "Claim: " . $claimData["ClaimCode"];
                }
                
                if (isset($addData)) {
                    $d = array_merge_recursive($claimData,(array) $addData);
                } else {
                    $d = $claimData;
                }
                if ($t = templateBuilder::populateTemplateFile($templateFile, $d)) {
                    lolHelperFunctions::sendEmail("lumunderwriting@lum.co.za", "lumunderwriting@lum.co.za",  "lumunderwriting@lum.co.za", "lumunderwriting@lum.co.za","" ,"",$s, $t );
                    $this->makeNote("Email to LUM (lumunderwriting@lum.co.za): " . $s . " : " . $t);
                }
                
            }
            
        }


        public function smsBrokerTemplate($TemplateName, $addData = null) {
            
        }
        public function smsClientTemplate($TemplateName, $addData = null) {
            if ($templateFile = $this->templates[$TemplateName]) {
                $claimData = $this->getClaimDetail();
/*
                if (isset($sub)) {
                    $s = $sub . " " . $claimData["ClaimCode"];
                } else {
                    $s = "Claim: " . $claimData["ClaimCode"];
                }
*/              
                if (isset($addData)) {
                    $d = array_merge_recursive($claimData,(array) $addData);
                } else {
                    $d = $claimData;
                }
                $clientCell = $claimData["ClientCell"];
                if ($t = templateBuilder::populateTemplateFile($templateFile, $d)) {
                    lolHelperFunctions::sendSMS($clientCell, $t );
                    $this->makeNote("SMS to Client ($clientCell): " . $t);
                }
                
            }
            
        }


        public function automateClaim() {
            $d = $this->getClaimDetail(true);
            $v = $this->getDbValidation(true);
            if ($v->dbvalSuccess == 1) {
                //claim validated
                //notify clinet of new claim
                $this->smsClientTemplate("smsNewClaimNotify");
                //notify broker of new claim
                $this->emailBrokerTemplate("emailNewClaimNotifyBroker","App New Claim:");
                // notify client validation passed
                $this->smsClientTemplate("smsNewClaimValidationPass");
                // notify broker validation passed
                $this->emailBrokerTemplate("emailNewClaimValidationPassNotifyBroker","App Claim Validation Passed:");
                
                //initiate fast-tract claim
                if ($ft = $this->fastTrack()) {
                    // check ft status
                    if ($ft->ftSuccess == 1) {
                        // fast track success
                        // notify client
                        $this->smsClientTemplate("smsNewClaimPaymentNotifyClient",$ft);        
                        // notify broker
                        $this->emailBrokerTemplate("emailNewClaimPaymentNotifyBroker","App Claim Payment:", $ft);
                    } else {
                        $ftNote = print_r($ft,true);
                        $this->makeNote($ftNote);
                        $this->emailLUMTemplate("emailnewClaimFastTrackFail","App Claim fast-Track Fail:");
                    }
                    
                    
                } else {
                    $this->emailLUMTemplate("emailnewClaimFastTrackFail","App Claim fast-Track Fail:");
                }
                
                
                
            } else {
                // claim validation failed
                // notify client
                $this->smsClientTemplate("smsNewClaimValidationFail");
                //notify broker
                $this->emailBrokerTemplate("emailBrokerValidationFail","App Claim Validation Fail:",$v);
                // notify LUM
                $this->emailLUMTemplate("emailLegacyValidationFail","App Claim Validation Fail:",$v);
                
            }
            
            
        }

        
        
/*        
    public function sendEmail($sub,$msg,$to,$cc = '') {
        lolHelperFunctions::sendEmail($to, $to, 'lumunderwriting@lum.co.za', 'lumunderwriting@lum.co.za', $cc,$cc,$sub, $msg );
        $this->makeNote("Client Email to Broker ($to): " . $sub . " : " . $msg);
        //return lol::result(true,"Thank you, we sent your message to your broker");
        return true;
        
        
    }        
  */      
        
        
}    //class
                        
                        
                        
                        
                        
                        
                        
                        


?>
