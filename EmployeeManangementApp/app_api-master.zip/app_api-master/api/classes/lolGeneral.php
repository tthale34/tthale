<?
/*
    public function getPolicy($forcerefresh = null, $policyid = null) {
        if (is_object($this->Policy)) {
            if ($p = $this->Policy->getPolicyID()) {
                if ($policyid) {
                    if ($policyid== $p) {
                        return $this->Policy;    
                    } else {
                        // new policy
                        unset($this->Policy);
                        $this->Policy = new lmsPolicy($this->db, $policyid);
                    }
                    
                } else {
                    return 
                }
            }
        }
    }
*/
    public function getTableData($tableName = "", $orderCol = "")
    {
        $tabs = array();
        if($tableName != "")
        {
            $sql = "select * from ". $tableName;
            if($orderCol != "")
            {
                $sql .= " ORDER BY ".$orderCol ."   ";
            }
            
        }
        // echo $sql;
        $q = $this->db->query($sql);

        while ($r = $this->db->row($q)) {
            if($orderCol != "")
            {
                $tabs[$r[$orderCol]] = $r;
            }
            else
            {
                $tabs[$r["PID"]] = $r;
           }
        }
        return json_encode($tabs);
    }

