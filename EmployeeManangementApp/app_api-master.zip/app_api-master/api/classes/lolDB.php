<?php

class lolDB {
    private $dbName;
    private $dbIP;
    private $dbPort;
    private $dbUser;
    private $dbPass;
    private $db = 0;
    private $SYS;
    private $logSQL = true;
    
    
    public function __construct($sys = null) {
        if ($sys) {
            $this->SYS = $sys;
            $this->connect();    
        }
        
    }
       
    public function connect($sys = null) {
        if ($sys) {
            $this->SYS = $sys;
        }        
        if ($this->SYS="LMS") {
            $this->dbName="lumpdb_s12_live";
            $this->dbIP = "192.168.169.101";
            $this->dbPort = "49152";
            $this->dbUser = "DBA";
            $this->dbPass = "xdsl";
            $this->db = sasql_connect( "commlinks=tcpip(HOST=" . $this->dbIP . ":" . $this->dbPort . ");DBN=" . $this->dbName . "; ENG=" . $this->dbName . ";uid=" . $this->dbUser . ";pwd=" . $this->dbPass . "" );
            return $this->db;
        };
        
    }
    
    public function query($sql) {
        if ($this->logSQL) {
            file_put_contents("/tmp/pwa2020.sql",$sql,FILE_APPEND);
        }
        if ($this->db) {
            if ($q = sasql_query($this->db ,$sql)) {
                return $q;
            } else {
                return null;
            }
        }
        
    }
    
    public function row($query) {
        if ($r = sasql_fetch_assoc($query)) {
            return $r;
        } else {
            if (is_resource($query)) {sasql_free_result($query);};
            return null;
        }
    }

    public function all($sql) {
        $res = array();
        if ($q = $this->query($sql)) {
            while ($r = $this->row($q)) {
                $res[] = $r;
            
            }
            if (is_resource($q)) {sasql_free_result($q);};
            return $res;
        }
    } 
    
    public function data($sql) {
        if ($q = $this->query($sql)) {
            if ($r = $this->row($q)) {
                if (is_resource($q)) {sasql_free_result($q);};
                return $r;
            
            }
        }
    }

    public function selectSqlFromMap($dbmap, $data = null) {
        $sqlget = "";
        $cnt=1;
        foreach($dbmap["fields"] as $k => $v) {
            if (($cnt++)>1) {$sqlget .= ",";};
            $sqlget .=  $v["tablePrefix"] . "." . $v["field"] . " as [" . $k ."]";
        };
        $sqlget = "select " . $sqlget ." from " . $dbmap["baseTable"]["table"] . " as " . $dbmap["baseTable"]["prefix"];
        foreach($dbmap["joins"] as $t => $v) {
            $sqlget .= " left outer join " . $v["table"] . " as " . $t . " on " . $t  . ".". $v["keyField"] . "=" . $v["masterPrefix"] . ".". $v["masterField"] ;
        }
        
        if (isset($data)) {
            if (is_array($data)) {
                $sqlget .=  " where " . $dbmap["baseTable"]["prefix"] . "." . $dbmap["baseTable"]["filterField"] . "=" . $data[$dbmap["baseTable"]["filterField"]] ;
            } else {
                IF (is_integer($data)) {
                    $sqlget .=  " where " . $dbmap["baseTable"]["prefix"] . "." . $dbmap["baseTable"]["filterField"] . "=" . $data ;
                } else {
                    $sqlget .=  " where " . $dbmap["baseTable"]["prefix"] . "." . $dbmap["baseTable"]["filterField"] . "='$data'" ;
                }

            }
        }
        return $sqlget;
    }

    public function updateSqlFromMap($dbmap, $data) {
/*        
        
$dbmap = array(
    "fields" => array(
        "PID" => array("field" => "pid","tablePrefix" => "ps"),
        "item" => array("field" => "Itemdescription","tablePrefix" => "ps"),
        "covertype" => array("field" => "covertype_id","tablePrefix" => "ps"),
        "relation" => array("field" => "VehicleRelationship_ID","tablePrefix" => "ps"),
        "itemtype" => array("field" => "itemtype_id","tablePrefix" => "ps"),
        "clientname" => array("field" => "clientcommonname","tablePrefix" => "c"),
        "policycode" => array("field" => "policycode","tablePrefix" => "p"),
        ),
    "baseTable" => array("table"=>"policysection","prefix"=>"ps", "keyField"=>"PID", "filterField"=>"policy_id"),
    "joins" => array(
                     "policy"=>array("prefix"=>"p","keyField"=>"pid","masterPrefix"=>"ps","masterField"=>"policy_id"),
                     "client"=>array("prefix"=>"c","keyField"=>"pid","masterPrefix"=>"p","masterField"=>"client_id"),
                    )

);
$data = array(
    "PID" => "123456789",
    "policy_id" => "96101",
    "ddSelectVehicle" => "1234",
    "incidentype" => "2",
    "relation" => "1",
    "description" => "he bumped me",
    "clientname" => "Adolf",
    "policycodex" => "HC096101",
              );


        
*/        
        $sqlupdate = "";
        $cnt=1;
        foreach($dbmap["fields"] as $k => $v) {
            if ($v["tablePrefix"]==$dbmap["baseTable"]["prefix"]) {
                if (isset($data[$k])) {
                    if (strtolower($k) != strtolower($dbmap["baseTable"]["keyField"])) {
                        if (($cnt++)>1) {$sqlupdate .= ",";};
                        $sqlupdate .= $v["field"] . "='" . $this->dbCleanString($data[$k]) ."'";
                    }
                }
            }
        };
        if (isset($data[$dbmap["baseTable"]["keyField"]]) ) {
            $sqlupdate = "update " . $dbmap["baseTable"]["table"] . " set " . $sqlupdate . " where " . $dbmap["baseTable"]["keyField"] . "=" . $data[$dbmap["baseTable"]["keyField"]] . ";commit;";
        };
        return $sqlupdate;
    }

    public function dbCleanString($str) {
        $str = str_replace("'", "''", $str);
        return $str;
    }

    public function getNextPID($table, $cnt=1) {
        $res = $this->data("select func_GetNextPID('$table',$cnt) as NEWPID");
        return $res["NEWPID"];
        
    }
    
}


?>