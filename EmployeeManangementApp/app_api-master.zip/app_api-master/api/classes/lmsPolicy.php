<?php

class lmsPolicy {
    private $lol; 
    private $db;
    private $PolicyID;
    private $policyProfile;
    
    public function getLol() {
        return $this->lol;
    }
    public function __construct($LOL,$policyid) {
        $this->lol = $LOL;
        $this->db = $this->lol->getDB();
        $this->PolicyID = $policyid;
        $this->getPolicyProfile(true,$policyid);
    }
    public function getPolicyProfile($forceRefresh = false, $policyid = null) {
        if (isset($policyid)) {
            $this->PolicyID = $policyid;
            $forceRefresh = true;
        } else {
            if (isset($this->PolicyID)) {
                if (!isset($this->policyProfile)) {
                    $forceRefresh = true;
                }
            } else {
                return false;
            }
        }

        $sql = "
        select
            p.pid as Policy_ID
            ,p.policycode as PolicyCode
            ,p.client_id as Client_ID
            ,c.initials as Initials
            ,c.FirstNames as Names
            ,c.surname as Surname
            ,c.idnumber as IDNumber
            ,c.clientcommonname as ClientCommonName
            ,c.HomeTelNumber as ClientHomeTel
            ,c.WorkTelNumber as ClientWorkTel
            ,c.cellnumber as ClientCell
            ,c.emailaddress as ClientEmail
            ,b.brokername as BrokerName
            ,b.CellularNumber as BrokerCell
            ,b.EmailAddress as BrokerEmail
            ,b.FSPNO as BrokerFSP
            ,b.BrokerLogoFileName as BrokerLogoFN
            ,'https://www.lum.co.za/get_lms_logo.php?img=' || b.BrokerLogoFileName as BrokerLogoURL
            ,p.policyprefix_id as Prefix_ID
            ,ppf.insurerscheme_id as InsurerScheme_ID
            ,lis.insurer_ID as Insurer_ID
            ,ppf.policyprefix as PolicyPrefix
            ,i.insurer2 as Insurer
            ,lis.insurerscheme2 as InsurerScheme
            ,lps.status2 as PolicyStatus
            ,p.policystatus_id as PolicyStatus_ID
            ,get_SpecGrp(p.pid) AS SpecialGroups
            ,if(lis.Insurer_ID = 2 and lis.PolicyType_ID = 1 and ppf.pid <> 35 and p.PolicyScheme_Id <> 1078) then 
                        '<a href=https://www.lum.co.za/reports/policywordings/policywording_hollard_non_hv_2.pdf target=_blank>Policy Wording</a>'
                 else if(lis.Insurer_ID = 2 and lis.PolicyType_ID = 1 and ppf.pid = 35 and p.PolicyScheme_Id <> 1078) then 
                        '<a href=https://www.lum.co.za/reports/policywordings/policywording_hollard_hv_2.pdf target=_blank>Policy Wording</a>'
                 else if(lis.Insurer_ID = 2 and lis.PolicyType_ID = 1 and ppf.pid = 1143 and p.PolicyScheme_Id = 1078) then 
                        '<a href=https://www.lum.co.za/reports/policywordings/policywording_hollard_rh_2.pdf target=_blank>Policy Wording</a>'
                 else if(lis.Insurer_ID = 1 and lis.PolicyType_ID = 1 and lis.pid <> 1038) then 
                        '<a href=https://www.lum.co.za/reports/policywordings/policywording_santam_2.pdf target=_blank>Policy Wording</a>'
                 else if(lis.Insurer_ID = 1 and lis.PolicyType_ID = 1 and lis.pid = 1038) then 
                        '<a href=https://www.lum.co.za/reports/policywordings/policywording_santam_747_2.pdf target=_blank>Policy Wording</a>'
                 else if(lis.Insurer_ID = 1037 and lis.PolicyType_ID = 1 and lis.pid <> 1080 and lis.pid <> 1085 and lis.pid <> 1084) then 
                        '<a href=https://www.lum.co.za/reports/policywordings/policywording_omi_op_2.pdf target=_blank>Policy Wording</a>'
                 else if(lis.Insurer_ID = 1037 and lis.PolicyType_ID = 1 and lis.pid = 1080) then 
                        '<a href=https://www.lum.co.za/reports/policywordings/policywording_omi_og_2.pdf target=_blank>Policy Wording</a>'
                 else if(lis.Insurer_ID = 1037 and lis.PolicyType_ID = 1 and lis.pid = 1085) then 
                        '<a href=https://www.lum.co.za/reports/policywordings/policywording_omi_dr_2.pdf target=_blank>Policy Wording</a>'
                  else if(lis.Insurer_ID = 1037 and lis.PolicyType_ID = 1 and lis.pid = 1084) then 
                        '<a href=https://www.lum.co.za/reports/policywordings/policywording_omi_oc_2.pdf target=_blank>Policy Wording</a>'
                 else 
                    ''
                 endif  endif endif endif endif endif endif  endif endif AS PolicyWording
        
        ,ifnull(aad.hasAssist,'N',aad.hasAssist) as AssistYN
        ,ifnull(aad.hasAssist,'0861468882',aad.assistTel) as AssistTel
        ,ifnull(aad.hasAssist,'0861468882',aad.assistCompany_ID) as AssistCompanyID
        ,ifnull(aad.hasAssist,'0861468882',aad.assistCompanyName) as AssistCompanyName
        
        
        
            from policy as p
            join client as c on c.pid=p.client_id
            join l_broker as b on b.pid=p.activebroker_id
            join l_policyprefix as ppf on ppf.pid=p.policyprefix_id
            join l_insurerscheme as lis on lis.pid=ppf.insurerscheme_id
            join l_insurer as i on i.pid=lis.insurer_id
            join l_policystatus as lps on lps.pid=p.policystatus_id
            left outer join app_active_assist_details as aad on aad.policy_id=p.pid
            where
            p.pid=$this->PolicyID
            
        ";
        
        if ($forceRefresh) {
            if ($prof = $this->db->data($sql)) {
                $this->policyProfile = $prof;
                return $this->policyProfile;
            } else {
                return false;
            }
        } else {
            if (isset($this->policyProfile)) {
                return $this->policyProfile;
            } else {
                if ($prof = $this->db->data($sql)) {
                    $this->policyProfile = $prof;
                    return $this->policyProfile;
                } else {
                    return false;
                }
            }
        }
    }

    public function clientEmailBroker($data) {
        $sub = $data->subject;
        $msg = $data->mailMessage;
        $this->makeNote("Client sent mail to broker: " . $sub . " : " . $msg);
        $prof = $this->getPolicyProfile();
        $brokerCell = $prof["BrokerCell"];
        $brokerEmail = $prof["BrokerEmail"];
        $clientCell = $prof["ClientCell"];
        $clientName = $prof["ClientCommonName"];
        $clientEmail = $prof["ClientEmail"];
        $polCode = $prof["PolicyCode"];
        lolHelperFunctions::sendEmail($brokerEmail, $brokerEmail, $clientEmail, $clientEmail, $clientEmail,$clientEmail,$sub, $msg );
        $this->makeNote("Client Email to Broker ($brokerEmail): " . $sub . " : " . $msg);
        //return lol::result(true,"Thank you, we sent your message to your broker");
        return true;
        
        
    }
    public function claimQueryEmail($data) {
        //$this->makeNote("Client sent mail to broker: " . $sub . " : " . $msg);
        $prof = $this->getPolicyProfile();
        $to = $data->ResponsiblePersonEmail;
        $cc = "clientapp@lum.co.za";
        $ClaimCode = $data->claimCode;
        $ClaimID = $data->ClaimID;
        $clientEmail = $prof["ClientEmail"];
        $polCode = $prof["PolicyCode"];
        $sub = $ClaimCode .": Client Query";
        $msg = $data->message;
        lolHelperFunctions::sendEmail($to, $to, $clientEmail, $clientEmail, $cc,$cc,$sub, $msg );
        $this->makeNote($sub . " : " . $msg);
        return true;
        
        
    }
    public function claimCallClient($data) {
        //$this->makeNote("Client sent mail to broker: " . $sub . " : " . $msg);
        $prof = $this->getPolicyProfile();
        $to = $data->ResponsiblePersonEmail;
        $cc = "clientapp@lum.co.za";
        $ClaimCode = $data->claimCode;
        $ClaimID = $data->ClaimID;
        $clientEmail = $prof["ClientEmail"];
        $clientCell = $prof["ClientCell"];
        $polCode = $prof["PolicyCode"];
        $sub = $ClaimCode .": Client Query";
        $msg = "Client requested you to call him regarding his claim on $clientCell";
        lolHelperFunctions::sendEmail($to, $to, $clientEmail, $clientEmail, $cc,$cc,$sub, $msg );
        $this->makeNote($sub . " : " . $msg);
        return true;
        
        
    }

    public function brokerCallClient(){
        $this->makeNote("Client requested broker to call him.");
        $prof = $this->getPolicyProfile();
        $brokerCell = $prof["BrokerCell"];
        $brokerEmail = $prof["BrokerEmail"];
        $clientCell = $prof["ClientCell"];
        $clientName = $prof["ClientCommonName"];
        $polCode = $prof["PolicyCode"];
        
        $sms = "Dear Broker your client, " . $clientName . ", with policy $polCode,  requested a call from you on " . $clientCell;
        
        $this->makeNote("SMS to Broker ($brokerCell): " . $sms);
        
        lolHelperFunctions::sendSMS($brokerCell, $sms);
        return true;
    }
    
    public function getPolicyCode() {
        $sql = "select policycode from policy where pid=$this->PolicyID";
        $x = $this->db->data($sql);
        return $x["policycode"];
    }
    public function getClaims($OpenClaimsOnly=true) {
        $sql="
            select 
                pc.pid as PID
                ,pc.claimcode as ClaimCode
                ,pc.ClaimStatus_Id as ClaimStatus_ID
                ,pc.Policy_ID as Policy_ID
                ,pc.PolicySection_id as PolicySectionItem_ID
                ,pc.ClaimType_ID
                ,ct.claimtype2 as ClaimType
                ,p.policycode as PolicyCode
                ,pc.ClaimAmount
                ,ifnull(pc.R_BudgetAmount,0.00,pc.R_BudgetAmount) as R_BudgetAmount
                ,ifnull(pc.R_OriginalBudgetAmount,0.00,pc.R_OriginalBudgetAmount) as R_OriginalBudgetAmount
                ,ifnull(pc.R_SettleAmount,0.00,pc.R_SettleAmount) as R_SettleAmount
                ,ifnull(pc.R_OutstandingAmount,0.00,pc.R_OutstandingAmount) as R_OutstandingAmount
                ,ifnull(pc.R_WreckAmount,0.00,pc.R_WreckAmount) as R_WreckAmount
                ,ifnull(pc.R_ExcessAmount,0.00,pc.R_ExcessAmount) as R_ExcessAmount
                ,ifnull(pc.R_InsuredAmount,0.00,pc.R_InsuredAmount) as pcR_InsuredAmount
                ,cast(ReportedDate as date) as ReportedDate
                ,cast(OccuredDate as date) as OccuredDate
                ,pc.ResponsiblePerson_Id 
                ,urespon.userfullname as ResponsiblePerson
                ,urespon.UserEMailAddress as ResponsiblePersonEmail
                ,staff.StaffCommonName as ClaimsClerk
                ,uclerk.useremailaddress as claimsClerkEmail
                ,ps.itemdescription as ItemDescription
                ,cs.ClaimStatus2 as ClaimStatus
                ,case pc.claimtype_id
                    when 11 then L_LossTypeAllrisk.losstype2
                    when 10 then L_LossTypeAllrisk.losstype2
                    when 22 then L_LossTypeAllrisk.losstype2
                    when 29 then L_LossTypeAllrisk.losstype2
                    when 46 then L_LossTypeGeyser.losstypegeyser2
                    when 15 then L_LossTypeHouseContents.losstype2
                    when 7 then L_LossTypeHouseContents.losstype2
                    when 6 then L_LossTypeHouseContents.losstype2
                    when 27 then L_LossTypeHouseContents.losstype2
                    when 28 then L_LossTypeHouseContents.losstype2
                    when 16 then L_LossTypeHouseContentsGlass.losstype2
                    when 4 then L_LossTypeLightVessel.losstype2
                    when 3 then L_LossTypeMotorcycle.losstype2
                    when 13 then L_LossTypeMotorcycle.losstype2
                    when 12 then L_LossTypePersonalComputer.losstype2
                    when 30 then L_LossTypePersonalComputer.losstype2
                    when 42 then L_LossTypePersonalComputer.losstype2
                    when 43 then L_LossTypePersonalComputer.losstype2
                    when 44 then L_LossTypePersonalComputer.losstype2
                    when 45 then L_LossTypePersonalComputer.losstype2
                    when 47 then L_LossTypePersonalComputer.losstype2
                    when 48 then L_LossTypePersonalComputer.losstype2
                    when 49 then L_LossTypePersonalComputer.losstype2
                    when 50 then L_LossTypePersonalComputer.losstype2
                    when 8 then L_IncidentType.IncidentType2
                    else ''
                    end as LossType
                ,if pc.claimstatus_id in (1,4,8,13,15,16,17,18,1017,1018) then 'Y' else 'N' endif as OpenYN
                
                
            from policyclaim as pc 
            join policy as p on p.pid=pc.policy_id
            join client as c on c.pid=p.client_id
            left outer join users as urespon on urespon.pid=pc.ResponsiblePerson_Id
            left outer join l_staff as staff on staff.pid=pc.ClaimClerk_ID
            left outer join users as uclerk on uclerk.pid=staff.username_id
            left outer join policysection as ps on ps.pid = pc.policysection_id
            left outer join l_claimstatus as cs on cs.pid=pc.claimstatus_id
            left outer join L_LossTypeAllrisk  as L_LossTypeAllrisk  on L_LossTypeAllrisk .pid=pc.losstype_id
            left outer join L_LossTypePersonalComputer as L_LossTypePersonalComputer on L_LossTypePersonalComputer.pid=pc.losstype_id
            left outer join L_LossTypeHouseContents as L_LossTypeHouseContents on L_LossTypeHouseContents.pid=pc.losstype_id
            left outer join L_LossTypeHouseContentsGlass as L_LossTypeHouseContentsGlass on L_LossTypeHouseContentsGlass.pid=pc.losstype_id
            left outer join L_LossTypeGeyser as L_LossTypeGeyser on L_LossTypeGeyser.pid=pc.losstype_id
            left outer join L_LossTypeLightVessel as L_LossTypeLightVessel on L_LossTypeLightVessel.pid=pc.losstype_id
            left outer join L_LossTypeMotorcycle as L_LossTypeMotorcycle on L_LossTypeMotorcycle.pid=pc.losstype_id
            left outer join L_IncidentType as L_IncidentType on L_IncidentType.pid=pc.IncidentType_ID
            left outer join l_claimtype as ct on ct.pid=pc.claimtype_id
            where
            pc.policy_id=" . $this->PolicyID . "        
        ";
        
        if ($OpenClaimsOnly) {
            $sql .= " and OpenYN = 'Y' ";
        }
        $sql .= " ORDER BY ReportedDate desc ";
        
        return $this->db->all($sql);
        
    }
    
    
    public function getAccounting() {
        $sql = "
            select top 20
                acc.pid as AccID
                ,   if acc.transactiontype_id in (4,6)
                    then
                        if ((acc.doactionday between dateadd(day,-15,now()) and dateadd(day,15,now())) and (acc.transactionsatus_id<>4))
                        then 1
                        else 0
                        endif
                    else 0
                    endif as CanResubmit
                ,lfs_YearMonthToWords(acc.coveryearmonth,2) as YearMonth
                ,case lis.insurer_id
                    when 1 then 'Santam'
                    when 2 then 'Hollard'
                    when 17 then 'Lion'
                    when 1067 then 'Zurich'
                    else 'We'
                    end as insurer_name

                ,case acc.transactiontype_id
                    when 10 then insurer_name || ' refunded you'
                    when 13 then insurer_name || ' paid your Golden Policy Investment to you'
                    when 9 then 'You paid '|| insurer_name || ' via debit order' 
                    when 2 then 'You paid '|| insurer_name || ' via debit order' 
                    when 3 then 'You paid ' || insurer_name || ' cash'
                    when 6 then 'Your debit order failed'
                    when 4 then 'Your premium was unpaid'
                    else acc.transactionDescription
                    end as [Description]
        
                , acc.transactionDescription as [old_Description]
                , ifnull(acc.debit,0,acc.debit) - ifnull(acc.credit,0,acc.credit) as DtCt 
                , transactiontype_id as TransTypeID
                , Transactionsatus_id as TransStatusID
                /* , if CanResubmit = 1 then '<tr><td colspan=\"3\" align=\"center\"><img src=\"resources/icons/resubmit.png\"/></td></tr>' else '' endif as ActionButton */
                ,if acc.transactiontype_id in (4,6) then '#F5E6DA' else '#CCDEC3' endif as BGCol
                ,acc.policy_id as PolicyID
                ,p.policycode as PolicyCode
                ,dateformat(acc.doactionday,'dd/mm/yyyy') as actiondate
            from newlfs_policyaccount as acc
            join policy as p on p.pid=acc.policy_id
            join l_policyprefix as ppf on ppf.pid=p.policyprefix_id
            join l_insurerscheme as lis on lis.pid=ppf.insurerscheme_id

             where
                acc.policy_id =" . $this->PolicyID . "
                and acc.transactiontype_id in (10,13,9,2,3,6,4)
            order by acc.pid desc" ;
        return $this->db->all($sql);
    }

    public function getDocuments() {
        $sql = "select top 10
                    PID
                    ,DocumentDescription
                    ,DocumentFileName
                    ,Policy_ID
                    ,PolicySectionItem_ID
                    ,UserName_ID
                    ,DateAdded
                    ,'https://www.lum.co.za/get_lms_doc.php?file=' || documentfilename || '&fileDate=' || dateadded as DocURL
                from policycorrespondence
                where policy_id=$this->PolicyID " ;
        $sql .= " order by pid desc";
        return $this->db->all($sql);
    }
    
    public function getPolicyID() {
        if ($this->PolicyD) {
            return $this->PolicyID;
        } else {
            return false;
        }
    }
    
    public function getItems($del = null, $sec=null, $covertype =null) {
        $sql = "
            select
                ps.pid as PID
                ,ps.PolicySection_ID
                ,ps.DeletedYN
                ,ps.ItemDescription
                ,ps.Policy_ID
                ,p.Client_ID
                ,lps.Policysection2
            from
                policysection as ps
                join policy as p on p.pid=ps.policy_id
                join client as c on c.pid=p.client_id
                join l_policysection as lps on lps.pid=ps.policysection_id
            where
                ps.policy_id=$this->PolicyID
                
        ";
        if ($del) {
            $sql .= " and ps.deletedyn='$del'";
        }
        if ($sec) {
            $sql .= " and ps.policysection_id in ($sec)";
        }
        if ($covertype) {
            $sql .= " and ps.policysection_id in ($covertype)";
        }
        return $this->db->all($sql);
        
        
    }

    public function getClaimsold($item = null, $sec=null, $type =null, $status= null) {
        $sql = "
            select
                pc.pid as PID
                ,ps.pid as Item_ID
                ,ps.PolicySection_ID
                ,ps.DeletedYN
                ,ps.ItemDescription
                ,ps.Policy_ID
                ,p.Client_ID
                ,lps.Policysection2 as ItemSection
                ,ctps.Policysection2 as ClaimSection
                ,ct.claimtype2 as ClaimType
                ,cs.claimstatus2 as ClaimStatus
                ,pc.claimstatus_id as ClaimStatus_ID
            from
                policyclaim as pc
                join policysection as ps on ps.pid=pc.policysection_id
                join policy as p on p.pid=ps.policy_id
                join client as c on c.pid=p.client_id
                join l_policysection as lps on lps.pid=ps.policysection_id
                join l_claimtype as ct on ct.pid=pc.claimtype_id
                join l_policysection as ctps on ctps.pid=ct.policysectiontype_id
                left outer join l_claimstatus as cs on cs.pid=pc.claimstatus_id
            where
                pc.policy_id=$this->PolicyID
                
        ";
        if ($item) {
            $sql .= " and pc.policysection_id='$item'";
        }
        if ($sec) {
            $sql .= " and ps.policysection_id in ($sec)";
        }
        if ($type) {
            $sql .= " and pc.claimtype_id in ($type)";
        }
        if ($status) {
            $sql .= " and pc.claimstatus_id in ($status)";
        }

        return $this->db->all($sql);
        
        
    }
    
    public function itemUpdate($data){
        $this->makeNote("Client requested to amend his " . $data->oldItemDescription . " to " . $data->newItemDescription . " with a value of " . $data->newInsuredValue);
        $prof = $this->getPolicyProfile();
        $brokerCell = $prof["BrokerCell"];
        $brokerEmail = $prof["BrokerEmail"];
        $clientCell = $prof["ClientCell"];
        $clientName = $prof["ClientCommonName"];
        $polCode = $prof["PolicyCode"];
        
        $sub = "APP: $polCode amend item " . $data->oldItemDescription;
        
        $email = "Dear Broker your client, " . $clientName . ", with policy $polCode,  requested us to amend his " . $data->oldItemDescription . " to " . $data->newItemDescription . " with a value of " . $data->newInsuredValue . " on his policy.";
        $emailccc = "Dear CCC client, " . $clientName . ", with policy $polCode,  requested us to amend his " . $data->oldItemDescription . " to " . $data->newItemDescription . " with a value of " . $data->newInsuredValue . " on his policy.";
        lolHelperFunctions::sendEmail($brokerEmail, $brokerEmail, $clientEmail, $clientEmail, $clientEmail,$clientEmail,$sub, $email );
        lolHelperFunctions::sendEmail("clientapp@lum.co.za", "Client App", $clientEmail, $clientEmail, $clientEmail,$clientEmail,$sub, $emailccc );
        
        $this->makeNote("eMail to Broker ($brokerEmail): " . $email);
        
           

        return true;
        
    }
   
    public function clientUpdate($data){
        $this->makeNote("Client requested to update his contact details Cell: " . $data->cellNumber . ", email address: " . $data->emailAddress );
        $prof = $this->getPolicyProfile();
        $brokerCell = $prof["BrokerCell"];
        $brokerEmail = $prof["BrokerEmail"];
        $clientCell = $prof["ClientCell"];
        $clientName = $prof["ClientCommonName"];
        $polCode = $prof["PolicyCode"];
        
        $sub = "APP: $polCode Update contact details ";
        
        $email = "Dear CCC  client requested an update to his contact details, cell: " . $data->cellNumber . ", email address: " . $data->emailAddress;
        lolHelperFunctions::sendEmail("clientapp@lum.co.za", "Client App", $clientEmail, $clientEmail, $clientEmail,$clientEmail,$sub, $email );
        
        return true;
        
    }

    public function bankDetailsupdate($data){
        $this->makeNote("Client requested to update his Bank details Bank: " . $data->bankName . ", branch code: " . $data->branchCode . ", acc no: " . $data->accountNumber .", Acc Holder: " . $data->accountHolder);
        $prof = $this->getPolicyProfile();
        $brokerCell = $prof["BrokerCell"];
        $brokerEmail = $prof["BrokerEmail"];
        $clientCell = $prof["ClientCell"];
        $clientName = $prof["ClientCommonName"];
        $polCode = $prof["PolicyCode"];
        
        $sub = "APP: $polCode Update bank details ";
        
        $email = "Dear CCC  Client requested to update his Bank details Bank: " . $data->bankName . ", branch code: " . $data->branchCode . ", acc no: " . $data->accountNumber .", Acc Holder: " . $data->accountHolder;
        lolHelperFunctions::sendEmail("clientapp@lum.co.za", "Client App", $clientEmail, $clientEmail, $clientEmail,$clientEmail,$sub, $email );
        
        return true;
        
    }
    
    
    public function itemAdd($data){
        $this->makeNote("Client requested to add a new " . $data->itemType . ", " . $data->itemDescNewItem . ",  with a value of: " . $data->itemAMTNewItem);
        $prof = $this->getPolicyProfile();
        $brokerCell = $prof["BrokerCell"];
        $brokerEmail = $prof["BrokerEmail"];
        $clientCell = $prof["ClientCell"];
        $clientName = $prof["ClientCommonName"];
        $polCode = $prof["PolicyCode"];
        
        $sub = "APP: $polCode add item " . $data->itemDescNewItem;
        
        $email = "Dear Broker your client, " . $clientName . ", with policy $polCode,  requested us to add " . $data->itemType . " " . $data->itemDescNewItem . " with a value of " . $data->itemAMTNewItem . " to his policy.";
        $emailccc = "Dear CCC client, " . $clientName . ", with policy $polCode,  requested us to add " . $data->itemType . " " . $data->itemDescNewItem . " with a value of " . $data->itemAMTNewItem . " to his policy.";
        lolHelperFunctions::sendEmail($brokerEmail, $brokerEmail, $clientEmail, $clientEmail, $clientEmail,$clientEmail,$sub, $email );
        lolHelperFunctions::sendEmail("clientapp@lum.co.za", "Client App", $clientEmail, $clientEmail, $clientEmail,$clientEmail,$sub, $emailccc );
        
        $this->makeNote("eMail to Broker ($brokerEmail): " . $email);
        
           

        return true;
        
    }
    
  
    public function makeNote($note){
        $sqlNote = "call policy_makenote(" . $this->PolicyID . "," . $this->lol->getUserId() . ",'" . $note ."');";
        $res = $this->lol->getDB()->query($sqlNote);
    }
    public function itemRemove($itemID, $removeDate) {
        $userID = $this->lol->getUserId();
        
//        $sql  = "select * FROM LOL_PolicySection_Remove(".$userID.", ".$itemID.", '".$removeDate."');";
        $sql  = "select * from policy where pid=96101";
        if ($this->db->data($sql)) {

            $sql = "call LOL_Add_Policy_History_Log(0, 0, ".$itemID.", 3, ".$userID.", 'Item Removed');";    
            $this->db->query($sql);
            return true;
        } else {
            return false;
        }

    
        
        
    }
    

    public function logAssistCall() {
        $this->makeNote("Client called for assist service.");
        $prof = $this->getPolicyProfile();
        $brokerCell = $prof["BrokerCell"];
        $brokerEmail = $prof["BrokerEmail"];
        $clientCell = $prof["ClientCell"];
        $clientName = $prof["ClientCommonName"];
        $polCode = $prof["PolicyCode"];
        
        
        $sql = "call app_logAssistCall(" . $this->PolicyID . ",'" . $prof["AssistYN"] . "','" . $prof["AssistTel"] ."');";
        $res = $this->db->data($sql);        
        
        
        $sms = "Dear $clientName Thank you for contacting Assist Services. Please rate the service you received: Reply 1 (Satisfied), Reply 2 (Not satisfied).";
        $this->makeNote("SMS to client: ($clientCell): " . $sms);
        $smsReplyRef = "DB;LMS|POL;" . $this->PolicyID . "|UID;3170|CID;6|REF;" . $res["newPid"];
        lolHelperFunctions::sendSMS($clientCell, $sms, $smsReplyRef);
        return true;


        
    }


}


?>