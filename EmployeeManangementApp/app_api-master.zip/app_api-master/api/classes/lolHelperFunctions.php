<?php
class lolHelperFunctions {


    public static function log($var, $file = "/tmp/app_res.log") {
        $x = print_r($var, true);
        file_put_contents($file,$x,FILE_APPEND);
    }

    public static function app2011GenerateBorderLetter($data){
        if ($jwt = getJWTData($data)) {
        
            if ($polID  = $jwt["Policy_ID"]) {
                $_fromdate = $data->fromDate;
                $_todate = $data->toDate;
                $_datakey = $data->dataKey;
                $lms = new lol("LMS",$jwt);
                $pol = new lmsPolicy($lms,$polID);
                $doc = new documentGenerator($pol);
                $borderdatesql = "update policysection set BorderletterFromDate='" . $data->fromDate . "', BorderletterToDate='" . $data->toDate . "' where pid=$_datakey;commit;";
//                file_put_contents("/tmp/border.sql",$borderdatesql);
                $lms->getDB()->query($borderdatesql);
                    if ($res = json_decode($doc->appMakeRtfDocument(453, $_datakey,"Border Letter"))) {
                      if ($res->Success == 1) {
                          echo json_encode(lol::result(true,"For your safety we have emailed you your document.",null,null));
                      } else {
                          echo json_encode(lol::result(false,"Sorry we could not generate your document, please contact your broker.",null,null));
                      }
                    } else {
                        echo json_encode(lol::result(false,"Sorry we could not generate your document, please contact your broker.",null,null));
                    }
            } else {
                echo json_encode(lol::result(false,"Sorry we could not identify your policy try logging in again.",null,null));
            }
        } else {
            echo json_encode(lol::result(false,"Please login first",null,null));
        }
    }

    public static function app2011GenerateTaxPolicy($data){
        if ($jwt = getJWTData($data)) {
        
            if ($polID  = $jwt["Policy_ID"]) {
                $_fromdate = $data->fromDate;
                $_todate = $data->toDate;
            
                $lms = new lol("LMS",$jwt);
                $pol = new lmsPolicy($lms,$polID);
                $doc = new documentGenerator($pol);
//                $lms->getDB()->query("update policysection set BorderletterFromDate='" . $data->fromDate . "', BorderletterToDate='" . $data->toDate . "' where pid=$dataKey;commit;");
                    if ($res = json_decode($doc->appMakeTaxCertForPolicy($_fromdate,$_todate))) {
                      if ($res->Success == 1) {
                          echo json_encode(lol::result(true,"For your safety we have emailed you your document.",null,null));
                      } else {
                          echo json_encode(lol::result(false,"(1)Sorry we could not generate your document, please contact your broker.",null,null));
                      }
                    } else {
                        echo json_encode(lol::result(false,"(2)Sorry we could not generate your document, please contact your broker.",null,null));
                    }
            } else {
                echo json_encode(lol::result(false,"Sorry we could not identify your policy try logging in again.",null,null));
            }
        } else {
            echo json_encode(lol::result(false,"Please login first",null,null));
        }
    }
    public static function app2011GenerateTaxItem($data){
        if ($jwt = getJWTData($data)) {
        
            if ($polID  = $jwt["Policy_ID"]) {
                $_fromdate = $data->dateFrom;
                $_todate = $data->dateTo;
                $_datakey = $data->itemID;
                lolHelperFunctions::log("tax 1");
//                lolHelperFunctions::log($_datakey);

                $lms = new lol("LMS",$jwt);
                lolHelperFunctions::log("tax 2");
                $pol = new lmsPolicy($lms,$polID);
//                lolHelperFunctions::log($pol);
//                lolHelperFunctions::log($lms);
                $doc = new documentGenerator($pol);
                lolHelperFunctions::log("tax 3");

                    if ($res = json_decode($doc->appMakeTaxCertForItem($_fromdate,$_todate, $_datakey))) {
                lolHelperFunctions::log("tax 4");
                lolHelperFunctions::log($res);
                      if ($res->Success == 1) {
                          echo json_encode(lol::result(true,"For your safety we have emailed you your document.",null,null));
                      } else {
                          echo json_encode(lol::result(false,"(1)Sorry we could not generate your document, please contact your broker.",null,null));
                      }
                    } else {
                        
lolHelperFunctions::log("tax 4");
                lolHelperFunctions::log($res);                        
                        echo json_encode(lol::result(false,"(2)Sorry we could not generate your document, please contact your broker.",null,null));
                    }
            } else {
                echo json_encode(lol::result(false,"Sorry we could not identify your policy try logging in again.",null,null));
            }
        } else {
            echo json_encode(lol::result(false,"Please login first",null,null));
        }
    }
    
    public static function genOTP($digits = 4){
        return rand(pow(10, $digits-1), pow(10, $digits)-1);
        
    }
    
    public static function sendEmail($toEmail, $toName, $replyEmail, $replyName, $ccEmail, $ccName, $subject, $body){
//        $toEmail = "adolfhartsenberg@gmail.com";
        $data = array("toEmail"=>$toEmail,
                      "toName"=>$toName,
                      "replyEmail"=>$replyEmail,
                      "replyName"=>$replyName,
                      "ccEmail"=>$ccEmail,
                      "ccName"=>$ccName,
                      "subject"=>$subject,
                      "body"=>$body
                      
                      );
        $res = lolHelperFunctions::lol2011ApiCall("GET","https://www.lum.co.za/mypolicy.lum.co.za/send.email.php",$data);
        return $res;
        
        
        
    }

    public static function sendSMS($toCell, $msg, $replyRef = null){

        $data = array("cell"=>$toCell,
                      "msg"=>$msg);
        
        if (isset($replyRef)) {
            $data["replyRef"] = $replyRef;
        };
        
        $res = lolHelperFunctions::lol2011ApiCall("GET","https://www.lum.co.za/mypolicy.lum.co.za/send.sms.php",$data);
//copy erika
/*
        $data = array("cell"=>"0722779880",
                      "msg"=>$msg);
        $res = lolHelperFunctions::lol2011ApiCall("GET","https://www.lum.co.za/mypolicy.lum.co.za/send.sms.php",$data);
*/
        return $res;
    }
    
    
    
    public static function lol2011ApiCall($method, $url, $data = false) {
        $curl = curl_init();
        switch ($method)
        {
            case "POST":
                curl_setopt($curl, CURLOPT_POST, 1);
    
                if ($data)
                    curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
                break;
            case "PUT":
                curl_setopt($curl, CURLOPT_PUT, 1);
                break;
            default:
                if ($data)
                    $url = sprintf("%s?%s", $url, http_build_query($data));
        }
        // Optional Authentication:
        curl_setopt($curl, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
        curl_setopt($curl, CURLOPT_USERPWD, "username:password");
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        $result = curl_exec($curl);
        curl_close($curl);
        return trim($result);
    }    
    public static function app2011GenerateDocument($data, $_DocID, $_DocDesc, $_DataKeyID = null){

        if ($jwt = getJWTData($data)) {
        
            if ($polID  = $jwt["Policy_ID"]) {
                if (!$_DataKeyID) {
                    if ($_DataKeyID = $data->dataKey) {
                        $_DataKeyID = $data->dataKey;
                    } else {
                        $_DataKeyID = $polID;
                    }
                }
                $lms = new lol("LMS",$jwt);
                $pol = new lmsPolicy($lms,$polID);
                $doc = new documentGenerator($pol);
                if (($docID = $_DocID) && ($dataKey = $_DataKeyID)) {
                    if ($res = json_decode($doc->appMakeRtfDocument($docID, $dataKey,$_DocDesc))) {
                      if ($res->Success == 1) {
                          echo json_encode(lol::result(true,"For your safety we have emailed you your document.",null,null));
                      } else {
                          echo json_encode(lol::result(false,"Sorry we could not generate your document, please contact your broker.",null,null));
                      }
                    } else {
                        echo json_encode(lol::result(false,"Sorry we could not generate your document, please contact your broker.",null,null));
                    }
                } else {
                    echo json_encode(lol::result(false,"Sorry no template selected or no item selected.",null,null));
                }
            } else {
                echo json_encode(lol::result(false,"Sorry we could not identify your policy try logging in again.",null,null));
            }
        } else {
            echo json_encode(lol::result(false,"Please login first",null,null));
        }
    }



}

?>
