<?php

class documentGenerator {
    protected $lolPolicy;
        public function __construct($_lolPolicy) {
            $this->lolPolicy = $_lolPolicy;
        }
        
        
    public function makeRtfDocument() {
        
        
    }
    
    public function makeHtmlDocument() {
            
    }    
    
    public function makeSchedule() {
            
    }    

    
    public function appMakeRtfDocument($dcoId, $dataKeyId, $docDescription=null) {
        
        if (!$docDescription){
            $docDescription = "Client Generated Document";
        }
        
        if ($p = $this->lolPolicy->getPolicyProfile()) {
            $docdata = array(
                "sysPolicyID"=>$p["Policy_ID"],
                "CLIENTEMAIL"=>$p["ClientEmail"],
                "CLIENTNAME"=>$p["ClientCommonName"],
                "DocDesc"=>$docDescription,
                "DocKeyID"=>$dataKeyId,
                "DocID"=>$dcoId,
                "sysUserNameID"=>"0"
            );
        
            if ($d = $this->lolPolicy->getLol()->lol2011ApiCall("GET", "http://www.lum.co.za/mypolicy.lum.co.za/mobi.mypolicy.gen.document.php",$docdata)) {
                return $d;                
            } else {
                return false;
            }
        } else {
            return false;
        }
        
        
    }

    public function appMakeHtmlDocument() {
        
        
    }

    public function appMakeTaxCertForPolicy($_from_date,$_to_date){
        if ($p = $this->lolPolicy->getPolicyProfile()) {
            $taxData = array(
                "Policy_ID"=>$p["Policy_ID"]
                ,"POLICYCODE"=>$p["PolicyCode"]
                ,"from_date"=>$_from_date
                ,"to_date"=>$_to_date
                ,"userID"=>$this->lolPolicy->getLol()->getuserId()
                ,"CLIENTEMAIL"=>$p["ClientEmail"]
                ,"CLIENTNAME"=>$p["ClientCommonName"]
            );
            if ($d = $this->lolPolicy->getLol()->lol2011ApiCall("GET", "http://www.lum.co.za/mypolicy.lum.co.za/lms.gen.tax.cert.php",$taxData)) {
                return $d;                
            } else {
                return false;
            }
        } else {
            return false;
        }
    }
    
    public function appMakeTaxCertForItem($_from_date,$_to_date,$_itemID){
        if ($p = $this->lolPolicy->getPolicyProfile()) {
            $taxData = array(
                "policy_ID"=>$p["Policy_ID"]
                ,"POLICYCODE"=>$p["PolicyCode"]
                ,"from_date"=>$_from_date
                ,"to_date"=>$_to_date
                ,"Item_ID"=>$_itemID
                ,"userID"=>$this->lolPolicy->getLol()->getuserId()
                ,"CLIENTEMAIL"=>$p["ClientEmail"]
                ,"CLIENTNAME"=>$p["ClientCommonName"]
            );
            lolHelperFunctions::log($taxData);

            if ($d = $this->lolPolicy->getLol()->lol2011ApiCall("GET", "http://www.lum.co.za/mypolicy.lum.co.za/lms.gen.item.tax.cert.php",$taxData)) {
                return $d;                
            } else {
                return false;
            }
        } else {
            return false;
        }
        
        
    }
    
    
    public function appMakeSchedule() {
        if ($p = $this->lolPolicy->getPolicyProfile()) {
            $cheddata = array(
                "POLICYID"=>$p["Policy_ID"],
                "CLIENTEMAIL"=>$p["ClientEmail"],
                "CLIENTNAME"=>$p["ClientCommonName"],
                "sysUserNameID"=>$this->lolPolicy->getLol()->getuserId()
            );        
        
            if ($d = $this->lolPolicy->getLol()->lol2011ApiCall("GET", "http://www.lum.co.za/mypolicy.lum.co.za/mobi.mypolicy.send.schedule.php",$cheddata)) {
                return $d;                
            } else {
                return false;
            }
        } else {
            return false;
        }
        
        
    }
    
        
}

?>