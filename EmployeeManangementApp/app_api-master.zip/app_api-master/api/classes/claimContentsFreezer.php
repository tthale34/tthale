<?php
include_once("claimBase.php");
class claimContentsFreezer extends claimBase {
    private $customDbMap = array(
            "fields" => array(
                "PolicySection_ID" => array("field" => "PolicySection_Id","tablePrefix" => "pc","readOnly" => false),
                "PossibleRecoveryYN" => array("field" => "PossibleRecoveryYN","tablePrefix" => "pc","readOnly" => false),
                "PossibleCounterClaim" => array("field" => "PossibleCounterClaim","tablePrefix" => "pc","readOnly" => false),
                "AOLReceivedYN" => array("field" => "AOLReceivedYN","tablePrefix" => "pc","readOnly" => false),
                "AssessorsReportReceivedYN" => array("field" => "AssessorsReportReceivedYN","tablePrefix" => "pc","readOnly" => false),
                "PolicyHolderJobTitle_ID" => array("field" => "PolicyHolderJobTitle_ID","tablePrefix" => "pc","readOnly" => false),
                "PolicyHolderIDNumber" => array("field" => "PolicyHolderIDNumber","tablePrefix" => "pc","readOnly" => false),
                "PolicyHolderHomePhone" => array("field" => "PolicyHolderHomePhone","tablePrefix" => "pc","readOnly" => false),
                "PolicyHolderWorkPhone" => array("field" => "PolicyHolderWorkPhone","tablePrefix" => "pc","readOnly" => false),
                "PolicyHolderCellPhone" => array("field" => "PolicyHolderCellPhone","tablePrefix" => "pc","readOnly" => false),
                "EmailAddress" => array("field" => "EmailAddress","tablePrefix" => "pc","readOnly" => false),
                "AccidentTime" => array("field" => "AccidentTime","tablePrefix" => "pc","readOnly" => false),
                "LossDamageDiscoverDate" => array("field" => "LossDamageDiscoverDate","tablePrefix" => "pc","readOnly" => false),
                "LossType_ID" => array("field" => "LossType_ID","tablePrefix" => "pc","readOnly" => false),
                "LossDamageAddress1" => array("field" => "LossDamageAddress1","tablePrefix" => "pc","readOnly" => false),
                "LossDamageAddress2" => array("field" => "LossDamageAddress2","tablePrefix" => "pc","readOnly" => false),
                "LossDamageSuburb_ID" => array("field" => "LossDamageSuburb_ID","tablePrefix" => "pc","readOnly" => false),
                "LossDamageCity_ID" => array("field" => "LossDamageCity_ID","tablePrefix" => "pc","readOnly" => false),
                "PropertyOccupiedYN" => array("field" => "PropertyOccupiedYN","tablePrefix" => "pc","readOnly" => false),
                "OccupantName" => array("field" => "OccupantName","tablePrefix" => "pc","readOnly" => false),
                "UnoccupiedLonger60DaysYN" => array("field" => "UnoccupiedLonger60DaysYN","tablePrefix" => "pc","readOnly" => false),
                "LastOccupiedDate" => array("field" => "LastOccupiedDate","tablePrefix" => "pc","readOnly" => false),
                "PremisesUse" => array("field" => "PremisesUse","tablePrefix" => "pc","readOnly" => false),
                "LossDamagePrpoertyDesc" => array("field" => "LossDamagePrpoertyDesc","tablePrefix" => "pc","readOnly" => false),
                "UnlawfulEntryPremisesYN" => array("field" => "UnlawfulEntryPremisesYN","tablePrefix" => "pc","readOnly" => false),
                "EntryObtainedDesc" => array("field" => "EntryObtainedDesc","tablePrefix" => "pc","readOnly" => false),
                "DoorslockedYN" => array("field" => "DoorslockedYN","tablePrefix" => "pc","readOnly" => false),
                "AlarmInstalledYN" => array("field" => "AlarmInstalledYN","tablePrefix" => "pc","readOnly" => false),
                "AlarmActivatedYN" => array("field" => "AlarmActivatedYN","tablePrefix" => "pc","readOnly" => false),
                "YourLightsYN" => array("field" => "YourLightsYN","tablePrefix" => "pc","readOnly" => false),
                "LossDamageCausedAnotherPersonYN" => array("field" => "LossDamageCausedAnotherPersonYN","tablePrefix" => "pc","readOnly" => false),
                "HirePurchaseYN" => array("field" => "HirePurchaseYN","tablePrefix" => "pc","readOnly" => false),
                "LossDamagedPersonName" => array("field" => "LossDamagedPersonName","tablePrefix" => "pc","readOnly" => false),
                "LossDamagedPersonPostAddress1" => array("field" => "LossDamagedPersonPostAddress1","tablePrefix" => "pc","readOnly" => false),
                "LossDamagedPersonHomePhone" => array("field" => "LossDamagedPersonHomePhone","tablePrefix" => "pc","readOnly" => false),
                "LossDamagedPersonWorkPhone" => array("field" => "LossDamagedPersonWorkPhone","tablePrefix" => "pc","readOnly" => false),
                "PreviousLossDamageYN" => array("field" => "PreviousLossDamageYN","tablePrefix" => "pc","readOnly" => false),
                "PreviousLossDamageLossType_ID" => array("field" => "PreviousLossDamageLossType_ID","tablePrefix" => "pc","readOnly" => false),
                "R_PreviousLossDamageAmount" => array("field" => "R_PreviousLossDamageAmount","tablePrefix" => "pc","readOnly" => false),
                "AccidentReportedSAPDYN" => array("field" => "AccidentReportedSAPDYN","tablePrefix" => "pc","readOnly" => false),
                "SAPDPoliceStation" => array("field" => "SAPDPoliceStation","tablePrefix" => "pc","readOnly" => false),
                "SAPDReferenceNumber" => array("field" => "SAPDReferenceNumber","tablePrefix" => "pc","readOnly" => false),
                "ReportedDate" => array("field" => "ReportedDate","tablePrefix" => "pc","readOnly" => false),
                "ReasonNotReported" => array("field" => "ReasonNotReported","tablePrefix" => "pc","readOnly" => false),
                "OtherPartyInvolvedYN" => array("field" => "OtherPartyInvolvedYN","tablePrefix" => "pc","readOnly" => false),
                "HirePurchase_ID" => array("field" => "HirePurchase_ID","tablePrefix" => "pc","readOnly" => false),
                "HirePurchaseRefNumber" => array("field" => "HirePurchaseRefNumber","tablePrefix" => "pc","readOnly" => false),
                "InsuredUnderAnotherPolicyYN" => array("field" => "InsuredUnderAnotherPolicyYN","tablePrefix" => "pc","readOnly" => false),
                "OtherPolicyInsurer_ID" => array("field" => "OtherPolicyInsurer_ID","tablePrefix" => "pc","readOnly" => false),
                "OtherPolicyPolicyNumber" => array("field" => "OtherPolicyPolicyNumber","tablePrefix" => "pc","readOnly" => false),
                "R_FullInsuredAmount" => array("field" => "R_FullInsuredAmount","tablePrefix" => "pc","readOnly" => false),
                "LossDamageOccuredDesc" => array("field" => "LossDamageOccuredDesc","tablePrefix" => "pc","readOnly" => false),
                "NonStandardDesc" => array("field" => "NonStandardDesc","tablePrefix" => "pc","readOnly" => false),
                "RepudiationYN" => array("field" => "RepudiationYN","tablePrefix" => "pc","readOnly" => false),
                "RepudiationReason" => array("field" => "RepudiationReason","tablePrefix" => "pc","readOnly" => false),
                "CatastropheYN" => array("field" => "CatastropheYN","tablePrefix" => "pc","readOnly" => false),
                "L_IndustryJobTitle_PolicyHolderJobTitle_ID_IndustryJobTitle" => array("field" => "IndustryJobTitle2","tablePrefix" => "L_IndustryJobTitle_PolicyHolderJobTitle_ID","readOnly" => true),
                "L_LossTypeHouseContents_LossType_ID_LossType" => array("field" => "LossType2","tablePrefix" => "L_LossTypeHouseContents_LossType_ID","readOnly" => true),
                "L_Suburb2015_LossDamageSuburb_ID_Suburb1" => array("field" => "Suburb1","tablePrefix" => "L_Suburb2015_LossDamageSuburb_ID","readOnly" => true),
                "L_City2015_LossDamageCity_ID_City1" => array("field" => "City1","tablePrefix" => "L_City2015_LossDamageCity_ID","readOnly" => true),
                "L_LossTypeHouseContents_PreviousLossDamageLossType_ID_LossType" => array("field" => "LossType2","tablePrefix" => "L_LossTypeHouseContents_PreviousLossDamageLossType_ID","readOnly" => true),
                "L_HirePurchaseCompany_HirePurchase_ID_Name" => array("field" => "Name2","tablePrefix" => "L_HirePurchaseCompany_HirePurchase_ID","readOnly" => true),
                "L_Insurer_OtherPolicyInsurer_ID_Insurer" => array("field" => "Insurer2","tablePrefix" => "L_Insurer_OtherPolicyInsurer_ID","readOnly" => true),

                
                ),
            "joins" => array(
                "L_IndustryJobTitle_PolicyHolderJobTitle_ID"=>array("table"=>"L_IndustryJobTitle","keyField"=>"pid","masterPrefix"=>"pc","masterField"=>"PolicyHolderJobTitle_ID"),
                "L_LossTypeHouseContents_LossType_ID"=>array("table"=>"L_LossTypeHouseContents","keyField"=>"pid","masterPrefix"=>"pc","masterField"=>"LossType_ID"),
                "L_Suburb2015_LossDamageSuburb_ID"=>array("table"=>"L_Suburb2015","keyField"=>"pid","masterPrefix"=>"pc","masterField"=>"LossDamageSuburb_ID"),
                "L_City2015_LossDamageCity_ID"=>array("table"=>"L_City2015","keyField"=>"pid","masterPrefix"=>"pc","masterField"=>"LossDamageCity_ID"),
                "L_LossTypeHouseContents_PreviousLossDamageLossType_ID"=>array("table"=>"L_LossTypeHouseContents","keyField"=>"pid","masterPrefix"=>"pc","masterField"=>"PreviousLossDamageLossType_ID"),
                "L_HirePurchaseCompany_HirePurchase_ID"=>array("table"=>"L_HirePurchaseCompany","keyField"=>"pid","masterPrefix"=>"pc","masterField"=>"HirePurchase_ID"),
                "L_Insurer_OtherPolicyInsurer_ID"=>array("table"=>"L_Insurer","keyField"=>"pid","masterPrefix"=>"pc","masterField"=>"OtherPolicyInsurer_ID"),
                )
            );
 
    public function __construct($_lol, $ClaimID = null,$data = null) {
            $this->ClaimTypeID = 15;
            $this->staticDetail = array(
                "appClaimTypeDescription"  => "Fridge/Freezer Contents claim"
            );
            $this->dbValidationProc = 'app_ValidateClaim_ContentsFridgeFreezer';
            $this->lol = $_lol;
            $this->dbmap = array_merge_recursive($this->baseDbMap,$this->customDbMap);
            if (isset($ClaimID)) {
                if ($ClaimID>0) {
                    $this->claimID = $ClaimID;
                    $this->loadClaimDetail();
                } else {
                    if ($ClaimID == 0) {
                        //new claim
                        if (isset($data)) {
                            $this->newClaim($data->PolicySection_ID,$data->dateOfLoss);
                            $dataArray = (array) $data;
                            $this->updateClaim($dataArray);
                            $n = str_replace(chr(10), "<br/>", $dataArray["LossDamagePrpoertyDesc"]);
                            $this->makeNote($n);
                        }
                        
                    }
                }
            }
    }
    public function getDbMap(){
        return $this->dbmap;
    }


}// class


?>