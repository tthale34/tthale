<?php
include_once("claimBase.php");
class claimVehicleWindscreen extends claimBase {
    private $customDbMap = array(
            "fields" => array(
                    "damageDesc" => array("field" => "Damadge_ID","tablePrefix" => "pc","readOnly" => false),
                    "PolicySection_ID" => array("field" => "PolicySection_Id","tablePrefix" => "pc","readOnly" => false),
                    "glassDesc" => array("field" => "GlassDescription_ID","tablePrefix" => "pc","readOnly" => false),
                    "dateOfLoss" => array("field" => "OccuredDate","tablePrefix" => "pc","readOnly" => false),
                    "driver" => array("field" => "DriverRelatio_ID","tablePrefix" => "pc","readOnly" => false),
                    "L_WindscreenClaimDescription_GlassDescription_ID_Description" => array("field" => "Description2","tablePrefix" => "L_WindscreenClaimDescription_GlassDescription_ID","readOnly" => true),
                    "L_DriverRelationship_DriverRelatio_ID_RelationshipType" => array("field" => "RelationshipType2","tablePrefix" => "L_DriverRelationship_DriverRelatio_ID","readOnly" => true),
                    ),
            "joins" => array(
                    "L_DriverRelationship_DriverRelatio_ID"=>array("table"=>"L_DriverRelationship","keyField"=>"pid","masterPrefix"=>"pc","masterField"=>"DriverRelatio_ID"),
                    "L_WindscreenClaimDamadge_Damadge_ID"=>array("table"=>"L_WindscreenClaimDamadge","keyField"=>"pid","masterPrefix"=>"pc","masterField"=>"Damadge_ID"),
                    "L_WindscreenClaimDescription_GlassDescription_ID"=>array("table"=>"L_WindscreenClaimDescription","keyField"=>"pid","masterPrefix"=>"pc","masterField"=>"GlassDescription_ID"),
                    )
            );
 
    public function __construct($_lol, $ClaimID = null, $data = null) {
            $this->ClaimTypeID = 1;
            $this->lol = $_lol;
            $this->dbmap = array_merge_recursive($this->baseDbMap,$this->customDbMap);
            if (isset($ClaimID)) {
                if ($ClaimID>0) {
                    $this->claimID = $ClaimID;
                    $this->loadClaimDetail();
                } else {
                    if ($ClaimID == 0) {
                        //new claim
                        if (isset($data)) {
                            $this->newClaim($data->PolicySection_ID,$data->dateOfLoss);
                            $dataArray = (array) $data;
                            $this->updateClaim($dataArray);
                            $this->automateClaim();
                        }
                        
                    }
                }
            }
    }
    public function getDbMap(){
        return $this->dbmap;
    }



    public function automateClaim() {
        $d = (array) $this->getClaimDetail(true);
//        $v = (array) $this->getDbValidation(true);
        $data = array(
            "claimID" => $d["PID"],
            "policyId" => $d["_Policy_ID"]
            
        );

        $res = lolHelperFunctions::lol2011ApiCall("GET","https://www.lum.co.za/mobi.add.new.windscreenclaim_pwa.php",$data);

    }

    

}// class


?>