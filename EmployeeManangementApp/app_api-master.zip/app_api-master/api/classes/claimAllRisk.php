<?php
include_once("claimBase.php");
use \Firebase\JWT\JWT;
class claimAllRisk extends claimBase {
    private $customDbMap = array(
            "fields" => array(
"PossibleRecoveryYN" => array("field" => "PossibleRecoveryYN","tablePrefix" => "pc","readOnly" => false),
"PossibleCounterClaim" => array("field" => "PossibleCounterClaim","tablePrefix" => "pc","readOnly" => false),
"TotalLossYN" => array("field" => "TotalLossYN","tablePrefix" => "pc","readOnly" => false),
"PolicyHolderJobTitle_ID" => array("field" => "PolicyHolderJobTitle_ID","tablePrefix" => "pc","readOnly" => false),
"PolicyHolderIDNumber" => array("field" => "PolicyHolderIDNumber","tablePrefix" => "pc","readOnly" => false),
"PolicyHolderHomePhone" => array("field" => "PolicyHolderHomePhone","tablePrefix" => "pc","readOnly" => false),
"PolicyHolderWorkPhone" => array("field" => "PolicyHolderWorkPhone","tablePrefix" => "pc","readOnly" => false),
"PolicyHolderCellPhone" => array("field" => "PolicyHolderCellPhone","tablePrefix" => "pc","readOnly" => false),
"EmailAddress" => array("field" => "EmailAddress","tablePrefix" => "pc","readOnly" => false),
"LossDetail" => array("field" => "LossDetail","tablePrefix" => "pc","readOnly" => false),
"ItemDescription" => array("field" => "ItemDescription","tablePrefix" => "pc","readOnly" => false),
"AccidentTime" => array("field" => "AccidentTime","tablePrefix" => "pc","readOnly" => false),
"LossDate" => array("field" => "LossDate","tablePrefix" => "pc","readOnly" => false),
"LossType_ID" => array("field" => "LossType_ID","tablePrefix" => "pc","readOnly" => false),
"LossDamagePostalCode" => array("field" => "LossDamagePostalCode","tablePrefix" => "pc","readOnly" => false),
"LossDamageAddress2" => array("field" => "LossDamageAddress2","tablePrefix" => "pc","readOnly" => false),
"LossDamageCity_ID" => array("field" => "LossDamageCity_ID","tablePrefix" => "pc","readOnly" => false),
"LossDamageAddress1" => array("field" => "LossDamageAddress1","tablePrefix" => "pc","readOnly" => false),
"LossDamageSuburb_ID" => array("field" => "LossDamageSuburb_ID","tablePrefix" => "pc","readOnly" => false),
"LossDamageOccuredDesc" => array("field" => "LossDamageOccuredDesc","tablePrefix" => "pc","readOnly" => false),
"PreviousLossDamageYN" => array("field" => "PreviousLossDamageYN","tablePrefix" => "pc","readOnly" => false),
"R_PreviousLossDamageAmount" => array("field" => "R_PreviousLossDamageAmount","tablePrefix" => "pc","readOnly" => false),
"LossDamagePropertyDesc" => array("field" => "LossDamagePrpoertyDesc","tablePrefix" => "pc","readOnly" => false),
"PreviousLossDamageLossType_ID" => array("field" => "PreviousLossDamageLossType_ID","tablePrefix" => "pc","readOnly" => false),
"PreviousLossDamageDate" => array("field" => "PreviousLossDamageDate","tablePrefix" => "pc","readOnly" => false),
"PreviousLossDamageInsurer_ID" => array("field" => "PreviousLossDamageInsurer_ID","tablePrefix" => "pc","readOnly" => false),
"AccidentReportedSAPDYN" => array("field" => "AccidentReportedSAPDYN","tablePrefix" => "pc","readOnly" => false),
"OriginalSupplier" => array("field" => "OriginalSupplier","tablePrefix" => "pc","readOnly" => false),
"SAPDReferenceNumber" => array("field" => "SAPDReferenceNumber","tablePrefix" => "pc","readOnly" => false),
"SAPDReportedDate" => array("field" => "SAPDReportedDate","tablePrefix" => "pc","readOnly" => false),
"HirePurchaseYN" => array("field" => "HirePurchaseYN","tablePrefix" => "pc","readOnly" => false),
"HirePurchaseRefNumber" => array("field" => "HirePurchaseRefNumber","tablePrefix" => "pc","readOnly" => false),
"HirePurchase_ID" => array("field" => "HirePurchase_ID","tablePrefix" => "pc","readOnly" => false),
"InsuredUnderAnotherPolicyYN" => array("field" => "InsuredUnderAnotherPolicyYN","tablePrefix" => "pc","readOnly" => false),
"OtherPolicyInsurer_ID" => array("field" => "OtherPolicyInsurer_ID","tablePrefix" => "pc","readOnly" => false),
"R_InsuredAmount" => array("field" => "R_InsuredAmount","tablePrefix" => "pc","readOnly" => false),
"LossDamagePrpoertyDesc" => array("field" => "LossDamagePrpoertyDesc","tablePrefix" => "pc","readOnly" => false),
"RepudiationYN" => array("field" => "RepudiationYN","tablePrefix" => "pc","readOnly" => false),
"RepudiationReason" => array("field" => "RepudiationReason","tablePrefix" => "pc","readOnly" => false),
"CatastropheYN" => array("field" => "CatastropheYN","tablePrefix" => "pc","readOnly" => false),
"HasSimilarItemsYN" => array("field" => "HasSimilarItemsYN","tablePrefix" => "pc","readOnly" => false),
"HadSimilarItemsYN" => array("field" => "HadSimilarItemsYN","tablePrefix" => "pc","readOnly" => false),
"ReasonNoProofOfPurchase" => array("field" => "ReasonNoProofOfPurchase","tablePrefix" => "pc","readOnly" => false),
"ProofOfPurchaseType" => array("field" => "ProofOfPurchaseType","tablePrefix" => "pc","readOnly" => false),
"HasProofOfPurchaseYN" => array("field" => "HasProofOfPurchaseYN","tablePrefix" => "pc","readOnly" => false),
"OriginalPrice" => array("field" => "OriginalPrice","tablePrefix" => "pc","readOnly" => false),
"OriginalSupplier" => array("field" => "OriginalSupplier","tablePrefix" => "pc","readOnly" => false),
"OriginalPurchaceDate" => array("field" => "OriginalPurchaceDate","tablePrefix" => "pc","readOnly" => false),
"L_IndustryJobTitle_PolicyHolderJobTitle_ID_IndustryJobTitle" => array("field" => "IndustryJobTitle2","tablePrefix" => "L_IndustryJobTitle_PolicyHolderJobTitle_ID","readOnly" => true),
"L_LossTypeAllrisk_LossType_ID_LossType" => array("field" => "LossType2","tablePrefix" => "L_LossTypeAllrisk_LossType_ID","readOnly" => true),
"L_City2015_LossDamageCity_ID_City1" => array("field" => "City1","tablePrefix" => "L_City2015_LossDamageCity_ID","readOnly" => true),
"L_Suburb2015_LossDamageSuburb_ID_Suburb1" => array("field" => "Suburb1","tablePrefix" => "L_Suburb2015_LossDamageSuburb_ID","readOnly" => true),
"L_LossTypeAllrisk_PreviousLossDamageLossType_ID_LossType" => array("field" => "LossType2","tablePrefix" => "L_LossTypeAllrisk_PreviousLossDamageLossType_ID","readOnly" => true),
"L_Insurer_PreviousLossDamageInsurer_ID_Insurer" => array("field" => "Insurer2","tablePrefix" => "L_Insurer_PreviousLossDamageInsurer_ID","readOnly" => true),
"L_HirePurchaseCompany_HirePurchase_ID_Name" => array("field" => "Name2","tablePrefix" => "L_HirePurchaseCompany_HirePurchase_ID","readOnly" => true),
"L_Insurer_OtherPolicyInsurer_ID_Insurer" => array("field" => "Insurer2","tablePrefix" => "L_Insurer_OtherPolicyInsurer_ID","readOnly" => true),
"L_RepudiationReason_RepudiationReason_RepudiationReason" => array("field" => "RepudiationReason2","tablePrefix" => "L_RepudiationReason_RepudiationReason","readOnly" => true),
                ),
            "joins" => array(
"L_IndustryJobTitle_PolicyHolderJobTitle_ID"=>array("table"=>"L_IndustryJobTitle","keyField"=>"pid","masterPrefix"=>"pc","masterField"=>"PolicyHolderJobTitle_ID"),
"L_LossTypeAllrisk_LossType_ID"=>array("table"=>"L_LossTypeAllrisk","keyField"=>"pid","masterPrefix"=>"pc","masterField"=>"LossType_ID"),
"L_City2015_LossDamageCity_ID"=>array("table"=>"L_City2015","keyField"=>"pid","masterPrefix"=>"pc","masterField"=>"LossDamageCity_ID"),
"L_Suburb2015_LossDamageSuburb_ID"=>array("table"=>"L_Suburb2015","keyField"=>"pid","masterPrefix"=>"pc","masterField"=>"LossDamageSuburb_ID"),
"L_LossTypeAllrisk_PreviousLossDamageLossType_ID"=>array("table"=>"L_LossTypeAllrisk","keyField"=>"pid","masterPrefix"=>"pc","masterField"=>"PreviousLossDamageLossType_ID"),
"L_Insurer_PreviousLossDamageInsurer_ID"=>array("table"=>"L_Insurer","keyField"=>"pid","masterPrefix"=>"pc","masterField"=>"PreviousLossDamageInsurer_ID"),
"L_HirePurchaseCompany_HirePurchase_ID"=>array("table"=>"L_HirePurchaseCompany","keyField"=>"pid","masterPrefix"=>"pc","masterField"=>"HirePurchase_ID"),
"L_Insurer_OtherPolicyInsurer_ID"=>array("table"=>"L_Insurer","keyField"=>"pid","masterPrefix"=>"pc","masterField"=>"OtherPolicyInsurer_ID"),
"L_RepudiationReason_RepudiationReason"=>array("table"=>"L_RepudiationReason","keyField"=>"pid","masterPrefix"=>"pc","masterField"=>"RepudiationReason"),
)
            );
 
    public function __construct($_lol, $ClaimID = null, $data = null) {
            $this->ClaimTypeID = 11;
            $this->staticDetail = array(
                "appClaimTypeDescription"  => "Specified All Risk claim"
            );
            $this->dbValidationProc = 'pwa2021_AllriskClaimValidate';
            $this->lol = $_lol;
            $this->dbmap = array_merge_recursive($this->baseDbMap,$this->customDbMap);
            if (isset($ClaimID)) {
                if ($ClaimID>0) {
                    $this->claimID = $ClaimID;
                    $this->loadClaimDetail();
                } else {
                    if ($ClaimID == 0) {
                        //new claim
                        if (isset($data)) {
                            $this->newClaim($data->PolicySection_ID,$data->LossDate);
                            $this->postData = $data;
                            $dataArray = (array) $data;
                            $this->updateClaim($dataArray);
                        }
                        
                    }
                }
            }
    }
    public function getDbMap(){
        return $this->dbmap;
    }
    public function automateClaim_Lost($data,$v) { 
        
        //notify clinet of new claim
        $this->smsClientTemplate("smsNewClaimNotify");
        //notify broker of new claim
        $this->emailBrokerTemplate("emailNewClaimNotifyBroker","App New Claim:");
        //notify with link to request quotation
        $linkToken = array(
            "ClaimID" => $v["ClaimID"],
            "ClientName" => $v["ClientName"]
        );
        $jwt = setJWTData($linkToken);
        $v["link"] = "http://localhost:4200/client-claim-upload/?jwt=" . $jwt;
        $this->emailClientTemplate("emailClientNotifyLink","App Add Quote Link:",$v);
        $this->emailBrokerTemplate("smsNewBrokerNotifyLink","App Add Quote Link:",$v);
    }
    public function automateClaim_theft($data,$v) {        
        //notify clinet of new claim
        $this->smsClientTemplate("smsNewClaimNotify");
        //notify broker of new claim
        $this->emailBrokerTemplate("emailNewClaimNotifyBroker","App New Claim:");
        //notify with link to request quotation
        $linkToken = array(
            "ClaimID" => $v["ClaimID"],
            "ClientName" => $v["ClientName"]
        );
        $jwt = setJWTData($linkToken);
        $v["link"] = "http://localhost:4200/client-claim-upload/?jwt=" . $jwt;
        $this->emailClientTemplate("emailClientNotifyLink","App Add Quote Link:",$v);
        $this->emailBrokerTemplate("smsNewBrokerNotifyLink","App Add Quote Link:",$v);
    }
    public function automateClaim_damage($data,$v) {
        
        if ($v["dbvalSuccess"] == 1) {
            //claim validated
            //notify clinet of new claim
            $this->smsClientTemplate("smsNewClaimNotify");
            //notify broker of new claim
            $this->emailBrokerTemplate("emailNewClaimNotifyBroker","App New Claim:");
            // notify client validation passed
            $this->smsClientTemplate("smsNewClaimValidationPass");
            // notify broker validation passed
            $this->emailBrokerTemplate("emailNewClaimValidationPassNotifyBroker","App Claim Validation Passed:");
            
            //initiate fast-tract claim
            if ($ft = $this->fastTrack()) {
                // check ft status
                if ($ft->ftSuccess == 1) {
                    // fast track success
                    // notify client
                    $this->smsClientTemplate("smsNewClaimPaymentNotifyClient",$ft);        
                    // notify broker
                    $this->emailBrokerTemplate("emailNewClaimPaymentNotifyBroker","App Claim Payment:", $ft);
                } else {
                    $ftNote = print_r($ft,true);
                    $this->makeNote($ftNote);
                    $this->emailLUMTemplate("emailnewClaimFastTrackFail","App Claim fast-Track Fail:");
                    //ADD send email with link to request quotation
                    $linkToken = array(
                        "ClaimID" => $this->claimID,
                        "ClientName" => $v["ClientName"]
                    );
                    $jwt = setJWTData($linkToken);
                    $v["link"] = "http://localhost:4200/client-claim-upload/?jwt=" . $jwt;
                    $this->emailClientTemplate("emailClientDamageNotifyLink","App Add Quote Link:",$v);
                    $this->emailBrokerTemplate("smsNewBrokerDamageNotifyLink","App Add Quote Link:",$v);
                }                
            } else {
                $this->emailLUMTemplate("emailnewClaimFastTrackFail","App Claim fast-Track Fail:");
                //ADD send email with link to request quotation
                $linkToken = array(
                    "ClaimID" => $this->claimID,
                    "ClientName" => $v["ClientName"]
                );
                $jwt = setJWTData($linkToken);
                $v["link"] = "http://localhost:4200/client-claim-upload/?jwt=" . $jwt;
                $this->emailClientTemplate("emailClientDamageNotifyLink","App Add Quote Link:",$v);
                $this->emailBrokerTemplate("smsNewBrokerDamageNotifyLink","App Add Quote Link:",$v);
            }
        } else {
            // claim validation failed
            // notify client
            $this->smsClientTemplate("smsNewClaimValidationFail");
            //notify broker
            $this->emailBrokerTemplate("emailBrokerValidationFail","App Claim Validation Fail:",$v);
            // notify LUM
            $this->emailLUMTemplate("emailLegacyValidationFail","App Claim Validation Fail:",$v);
            //ADD send email with link to request quotation
            $linkToken = array(
                "ClaimID" => $this->claimID,
                "ClientName" => $v["ClientName"]
            );
            $jwt = setJWTData($linkToken);
            $v["link"] = "http://localhost:4200/client-claim-upload/?jwt=" . $jwt;
            $this->emailClientTemplate("emailClientDamageNotifyLink","App Add Quote Link:",$v);
            $this->emailBrokerTemplate("smsNewBrokerDamageNotifyLink","App Add Quote Link:",$v);
        }
    }
    public function automateClaim() {
        $d = $this->getClaimDetail(true);
        $v = $this->getDbValidation(true);
        $dataArray = (array) $this->getpostData();        
        $variables = array(
            "dbvalSuccess"=>$v->dbvalSuccess,
            "dbvalMsg"=>$v->dbvalMsg,
            "ClaimID"=>$d["PID"],
            "ClientName"=>$d["ClientCommonName"],
            "item"=>$dataArray["riskItem"],
            "repairOrReplace"=>$dataArray["LossType"],
            "bicycleUse"=>$dataArray["purposeOfUse"],
            "musicEquipUse"=>$dataArray["musicEquipPurpose"],
            "link"=>"link"
        );
        //make note on claim about all the questions
        $n = "<br/>Vehicle Locked: ". $dataArray["vehicleLocked"];
        $n = $n."<br/>Vehicle Forced In: ". $dataArray["vehicleForcedIn"];
        $n = $n."<br/>Equipment Visible: ". $dataArray["equipmentVisible"];
        $n = $n."<br/>Unknown Place: ".$dataArray["unknownPlace"];
        $n = $n."<br/>Total Claim Amount: ". $dataArray["totalClaimAmount"];
        $n = $n."<br/>Purpose of Use: ".$dataArray["purposeOfUse"];
        $n = $n."<br/>Sponsored: ".$dataArray["sponsored"];
        $n = $n."<br/>Locked in safe: ".$dataArray["jewelryLockedSafe"];
        $n = $n."<br/>Music equipment purpose: ".$dataArray["musicEquipPurpose"];
        $n = $n."<br/>Musical equipment damaged whilst in use: ".$dataArray["musicDamagedInUse"];
        $n = $n."<br/>Income Earned whilst in loss: ".$dataArray["photoIncomeInLoss"];
        $n = $n."<br/>Equipment damaged whilst in game: ".$dataArray["equipDamagedInGame"];
        $n = $n."<br/>SAPS Check: ".$dataArray["sapsCheck"];
        $n = $n."<br/>SAPS Station: ".$dataArray["sapsStation"];
        $n = $n."<br/>SAPS Reference Number: ".$dataArray["sapsRefNum"];        
        $n = $n."<br/>Loss Type: ".$dataArray["LossType"];
        $n = $n."<br/>Budget Amount: ".$dataArray["R_OriginalBudgetAmount"];
        $n = $n."<br/>Endorsement M: ".$dataArray["Endos_M_YN"];
        $this->makeNote($n);
        //if lost
        if ($dataArray["LossType"] == "Lost") {
            $this->automateClaim_Lost($dataArray,$variables);
        }
        //if theft
        if ($dataArray["LossType"] == "Theft") {
            //Check SAPS ref number populated
            if($dataArray["sapsCheck"]){
                $this->automateClaim_Theft($dataArray,$variables);
            }else{
                //Notify Broker No SAPS Ref number provided as yet
                $this->emailBrokerTemplate("emailBrokerSAPSNULL","App Claim Validation Fail:",$variables);
                //Notify LUM No SAPS Ref number provided as yet
                $this->emailLUMTemplate("emailLUMSAPSNULL","App Claim Validation Fail:",$variables);
            }
        }
        //if damage
        if ($dataArray["LossType"] == "Damage - Can be repaired" || $dataArray["LossType"] == "Damage - Needs to be replaced") {            
            $this->automateClaim_damage($dataArray,$variables);
        }
        //If vehicle not locked notify LUM and broker for frther attention
        if ($dataArray["vehicleLocked"] == "No") {
            $this->emailLUMTemplate("emailLUMVehicleNotLocked","App Vehicle Not Locked:",$variables);
            $this->emailBrokerTemplate("emailBrokerVehicleNotLocked","App Vehicle Not Locked:",$variables);
        }        
        //If vehicle forced into notify LUM and broker for further attention
        if ($dataArray["vehicleForcedIn"] == "No") {
            $this->emailLUMTemplate("emailLUMVehicleForcedIn","App Vehicle Forced Into:",$variables);
            $this->emailBrokerTemplate("emailBrokerVehicleForcedIn","App Vehicle Forced Into:",$variables);
        }        
        //If stolen equipment visible in vehicle notify LUM and broker for further attention
        if ($dataArray["equipmentVisible"] == "Yes") {
            $this->emailLUMTemplate("emailLUMItemVisible","App Item Visible in Vehicle:",$variables);
            $this->emailBrokerTemplate("emailBrokerItemVisible","App Item Visible in Vehicle:",$variables);
        }
        //If bicycle item notify as per item question/s
        if($dataArray["sponsored"] == "Yes"){
            $this->emailLUMTemplate("emailLUMBicycleNotify","App Bicycle Claim:",$variables);
            $this->emailBrokerTemplate("emailBrokerBicycleNotify","App Bicycle Claim:",$variables);
        }
        //If musical equipment item notify as per item question/s
        if($dataArray["musicDamagedInUse"] =="Yes"){
            $this->emailLUMTemplate("emailLUMMusicNotify","App Musical Equipment Claim:",$variables);
            $this->emailBrokerTemplate("emailBrokerMusicNotify","App Musical Equipment Claim:",$variables);
        }
        //If photographic equipment item notify as per item question/s
        if($dataArray["photoIncomeInLoss"] == "Yes"){
            $this->emailLUMTemplate("emailLUMPhotoNotify","App Photographic Equipment Claim:",$variables);
            $this->emailBrokerTemplate("emailBrokerPhotoNotify","App Photographic Equipment Claim:",$variables);
        }
        //If sports/golf equipment item notify as per item question/s
        if($dataArray["equipDamagedInGame"] == "Yes"){
            $this->emailLUMTemplate("emailLUMSportsNotify","App Sports Equipment Claim:",$variables);
            $this->emailBrokerTemplate("emailBrokerSportsNotify","App Sports Equipment Claim:",$variables);
        }
        //If jewellery item notify as per item question/s
        if($dataArray["jewelryLockedSafe"] == "No" && ($dataArray["R_OriginalBudgetAmount"] >= 50000 || $dataArray["Endos_M_YN"] == "No")){
            $this->emailLUMTemplate("emailLUMJewelryNotify","App Jewellery Claim:",$variables);
            $this->emailBrokerTemplate("emailBrokerJewelryNotify","App Jewellery Claim:",$variables);
        }        
    }
}// class
?>