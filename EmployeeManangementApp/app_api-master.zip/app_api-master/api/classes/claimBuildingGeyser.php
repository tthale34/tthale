<?php
include_once("claimBase.php");
class claimBuildingGeyser extends claimBase {
    private $customDbMap = array(
            "fields" => array(
                    "damageDesc" => array("field" => "LossType_ID","tablePrefix" => "pc","readOnly" => false),
                    "policySection_ID" => array("field" => "PolicySection_Id","tablePrefix" => "pc","readOnly" => false),
                    "selectedBuilding" => array("field" => "PolicySection_Id","tablePrefix" => "pc","readOnly" => false),
                    "property60Day" => array("field" => "UnoccupiedLonger60DaysYN","tablePrefix" => "pc","readOnly" => false),
                    "lossDate" => array("field" => "OccuredDate","tablePrefix" => "pc","readOnly" => false),
                    "L_LossTypeGeyser_LossType_ID_LossTypeGeyser" => array("field" => "LossTypeGeyser2","tablePrefix" => "L_LossTypeGeyser_LossType_ID","readOnly" => true),

                    ),
            "joins" => array(
                    "L_LossTypeGeyser_LossType_ID"=>array("table"=>"L_LossTypeGeyser","keyField"=>"pid","masterPrefix"=>"pc","masterField"=>"LossType_ID"),
                    )
            );
 
    public function __construct($_lol, $ClaimID = null,$data = null) {
            $this->ClaimTypeID = 46;
            $this->lol = $_lol;
            $this->dbmap = array_merge_recursive($this->baseDbMap,$this->customDbMap);
            if (isset($ClaimID)) {
                if ($ClaimID>0) {
                    $this->claimID = $ClaimID;
                    $this->loadClaimDetail();
                } else {
                    if ($ClaimID == 0) {
                        //New claim
                        if (isset($data)) {
                            //Create claim
                            $this->newClaim($data->selectedBuilding,$data->lossDate);
                            $dataArray = (array) $data;
                            $this->updateClaim($dataArray);
                        }
                        
                    }
                }
            }
    }
    public function getDbMap(){
        return $this->dbmap;
    }


}// class


?>