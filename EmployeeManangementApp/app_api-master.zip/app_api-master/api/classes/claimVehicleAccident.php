<?php
include_once("claimBase.php");
class claimVehicleAccident extends claimBase {
    private $customDbMap = array(
            "fields" => array(
                    "PolicySection_ID" => array("field" => "PolicySection_Id","tablePrefix" => "pc","readOnly" => false),
                    "TotalLossYN" => array("field" => "TotalLossYN","tablePrefix" => "pc","readOnly" => false),
                    "codeplex_id" => array("field" => "codeplex_id","tablePrefix" => "pc","readOnly" => false),
                    "CarHireStartDate" => array("field" => "CarHireStartDate","tablePrefix" => "pc","readOnly" => false),
                    "CarRentalCompany_ID" => array("field" => "CarRentalCompany_ID","tablePrefix" => "pc","readOnly" => false),
                    "ItemDescription" => array("field" => "ItemDescription","tablePrefix" => "pc","readOnly" => false),
                    "CoverType_ID" => array("field" => "CoverType_ID","tablePrefix" => "pc","readOnly" => false),
                    "YearModel" => array("field" => "YearModel","tablePrefix" => "pc","readOnly" => false),
                    "RegistrationNumber" => array("field" => "RegistrationNumber","tablePrefix" => "pc","readOnly" => false),
                    "IncidentType_ID" => array("field" => "IncidentType_ID","tablePrefix" => "pc","readOnly" => false),
                    "WhereYouDrivingYN" => array("field" => "WhereYouDrivingYN","tablePrefix" => "pc","readOnly" => false),
                    "DriverRelatio_ID" => array("field" => "DriverRelatio_ID","tablePrefix" => "pc","readOnly" => false),
                    "DriverName" => array("field" => "DriverName","tablePrefix" => "pc","readOnly" => false),
                    "DriverIDNumber" => array("field" => "DriverIDNumber","tablePrefix" => "pc","readOnly" => false),
                    "DriverLicenceNumber" => array("field" => "DriverLicenceNumber","tablePrefix" => "pc","readOnly" => false),
                    "DriverUseMedicationAlcoholYN" => array("field" => "DriverUseMedicationAlcoholYN","tablePrefix" => "pc","readOnly" => false),
                    "OccuredDate" => array("field" => "OccuredDate","tablePrefix" => "pc","readOnly" => false),
                    "AccidentTime" => array("field" => "AccidentTime","tablePrefix" => "pc","readOnly" => false),
                    "AccidentPlace" => array("field" => "AccidentPlace","tablePrefix" => "pc","readOnly" => false),
                    "AccidentReportedYN" => array("field" => "AccidentReportedYN","tablePrefix" => "pc","readOnly" => false),
                    "SAPDReferenceNumber" => array("field" => "SAPDReferenceNumber","tablePrefix" => "pc","readOnly" => false),
                    "SAPDPoliceStation" => array("field" => "SAPDPoliceStation","tablePrefix" => "pc","readOnly" => false),
                    "WitnessYN" => array("field" => "WitnessYN","tablePrefix" => "pc","readOnly" => false),
                    "VehiclePurpose_ID" => array("field" => "VehiclePurpose_ID","tablePrefix" => "pc","readOnly" => false),
                    "OtherPartyInvolvedYN" => array("field" => "OtherPartyInvolvedYN","tablePrefix" => "pc","readOnly" => false),
                    "ThirdPartyRecoveryType_ID" => array("field" => "ThirdPartyRecoveryType_ID","tablePrefix" => "pc","readOnly" => false),
                    "OtherPartyInitial" => array("field" => "OtherPartyInitial","tablePrefix" => "pc","readOnly" => false),
                    "OtherPartySurname" => array("field" => "OtherPartySurname","tablePrefix" => "pc","readOnly" => false),
                    "thirdpIDNumber" => array("field" => "thirdpIDNumber","tablePrefix" => "pc","readOnly" => false),
                    "thirdpModel" => array("field" => "thirdpModel","tablePrefix" => "pc","readOnly" => false),
                    "thirdpRegNumber" => array("field" => "thirdpRegNumber","tablePrefix" => "pc","readOnly" => false),
                    "OtherPartyCellPhone" => array("field" => "OtherPartyCellPhone","tablePrefix" => "pc","readOnly" => false),
                    "AnyOtherPersonPropertyDamageYN" => array("field" => "AnyOtherPersonPropertyDamageYN","tablePrefix" => "pc","readOnly" => false),
                    "AccidentDescription" => array("field" => "AccidentDescription","tablePrefix" => "pc","readOnly" => false),
                    "BrokenGlassDescription" => array("field" => "BrokenGlassDescription","tablePrefix" => "pc","readOnly" => false),
                    "WriteOffYN" => array("field" => "WriteOffYN","tablePrefix" => "pc","readOnly" => false),
                    "CatastropheYN" => array("field" => "CatastropheYN","tablePrefix" => "pc","readOnly" => false),                    ),
                    "L_vCarRentalCompany_CarRentalCompany_ID_CarRentalCompany" => array("field" => "CarRentalCompany","tablePrefix" => "L_vCarRentalCompany_CarRentalCompany_ID","readOnly" => true),
                    "L_VehicleCoverType_CoverType_ID_CoverType" => array("field" => "CoverType2","tablePrefix" => "L_VehicleCoverType_CoverType_ID","readOnly" => true),
                    "L_IncidentType_IncidentType_ID_IncidentType" => array("field" => "IncidentType2","tablePrefix" => "L_IncidentType_IncidentType_ID","readOnly" => true),
                    "L_VehiclePurpose_VehiclePurpose_ID_VehiclePurpose" => array("field" => "VehiclePurpose2","tablePrefix" => "L_VehiclePurpose_VehiclePurpose_ID","readOnly" => true),
                    "L_ThirdPartyRecoveryType_ThirdPartyRecoveryType_ID_ThirdPartyRecoveryType" => array("field" => "ThirdPartyRecoveryType2","tablePrefix" => "L_ThirdPartyRecoveryType_ThirdPartyRecoveryType_ID","readOnly" => true),

            "joins" => array(
                    "L_DriverRelationship_DriverRelatio_ID"=>array("table"=>"L_DriverRelationship","keyField"=>"pid","masterPrefix"=>"pc","masterField"=>"DriverRelatio_ID"),
                    "L_vCarRentalCompany_CarRentalCompany_ID"=>array("table"=>"L_vCarRentalCompany","keyField"=>"pid","masterPrefix"=>"pc","masterField"=>"CarRentalCompany_ID"),
                    "L_VehicleCoverType_CoverType_ID"=>array("table"=>"L_VehicleCoverType","keyField"=>"pid","masterPrefix"=>"pc","masterField"=>"CoverType_ID"),
                    "L_IncidentType_IncidentType_ID"=>array("table"=>"L_IncidentType","keyField"=>"pid","masterPrefix"=>"pc","masterField"=>"IncidentType_ID"),
                    "L_VehiclePurpose_VehiclePurpose_ID"=>array("table"=>"L_VehiclePurpose","keyField"=>"pid","masterPrefix"=>"pc","masterField"=>"VehiclePurpose_ID"),
                    "L_ThirdPartyRecoveryType_ThirdPartyRecoveryType_ID"=>array("table"=>"L_ThirdPartyRecoveryType","keyField"=>"pid","masterPrefix"=>"pc","masterField"=>"ThirdPartyRecoveryType_ID"),
                    )
            );
 
    public function __construct($_lol, $ClaimID = null, $data = null) {
            $this->ClaimTypeID = 8;
            $this->lol = $_lol;
            $this->dbmap = array_merge_recursive($this->baseDbMap,$this->customDbMap);
            if (isset($ClaimID)) {
                if ($ClaimID>0) {
                    $this->claimID = $ClaimID;
                    $this->loadClaimDetail();
                } else {
                    if ($ClaimID == 0) {
                        //new claim
                        if (isset($data)) {
                            $this->newClaim($data->PolicySection_ID,$data->OccuredDate);
                            $dataArray = (array) $data;
                            $this->updateClaim($dataArray);
                        }
                        
                    }
                }
            }
    }
    public function getDbMap(){
        return $this->dbmap;
    }


}// class


?>