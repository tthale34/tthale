<?php 
error_reporting(E_ALL); 
date_default_timezone_set('UCT'); 
$key = "AAAATAAAAGUAAABnAAAAYQAAAGMAAAB5AAAAVQAAAG4AAABkAAAAZQAAAHIAAAB3AAAAcgAAAGkAAAB0AAAAdAAAAGkAAABuAAAAZwAAAE0AAABhAAAAbgAAAGEAAABnAAAAZQAAAHIAAABz";
$iss = "http://example.org";
$aud = "http://example.com";
$iat = 1356999524;
$nbf = 1357000000;
?>