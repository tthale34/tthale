<?php
ini_set('display_errors','On');
ini_set('error_reporting', E_ALL);

include("lol.inc.all.php");
ini_set('display_errors','On');
ini_set('error_reporting', E_ALL);

$lms = new lol("LMS");
$pol = new lmsPolicy($lms,96101);
echo "<br/><br/>";
echo $pol->getPolicyCode();
echo "<br/><br/>";
var_dump($pol->getPolicyProfile());
/*
$claim = new claimContentsFreezer($lol,317706);
$claim->automateClaim();
$d = $claim->getClaimDetail();
print_r($d);
$v =  $claim->getDbValidation(true);
print_r($v);
*/
//echo $claim->emailBrokerTemplate("emailBrokerValidationFail","Claim failed validation", $v );
/*
echo "<html>";
echo $claim->emailBrokerTemplate("emailBrokerValidationFail");
echo "<br/>---------------------------------------------------------------------------------<br/>";
echo $claim->emailBrokerTemplate("emailLegacyValidationFail");
echo "<br/>---------------------------------------------------------------------------------<br/>";
echo $claim->emailBrokerTemplate("emailNewClaimNotifyBroker");
echo "<br/>---------------------------------------------------------------------------------<br/>";
echo $claim->emailBrokerTemplate("emailNewClaimPaymentNotifyBroker");
echo "<br/>---------------------------------------------------------------------------------<br/>";
echo $claim->emailBrokerTemplate("emailNewClaimValidationPassNotifyBroker");
echo "<br/>---------------------------------------------------------------------------------<br/>";
echo $claim->emailBrokerTemplate("smsNewClaimNotify");
echo "<br/>---------------------------------------------------------------------------------<br/>";
echo $claim->emailBrokerTemplate("smsNewClaimPaymentNotifyClient");
echo "<br/>---------------------------------------------------------------------------------<br/>";
echo $claim->emailBrokerTemplate("smsNewClaimValidationFail");
echo "<br/>---------------------------------------------------------------------------------<br/>";
echo $claim->emailBrokerTemplate("smsNewClaimValidationPass");
echo "<br/>---------------------------------------------------------------------------------<br/>";

echo "</html>";
*/
/*
$f = "claim/sms.new.claim.notify.txt";
$d = $claim->getClaimDetail();
//print_r($d);
$t = templateBuilder::populateTemplateFile($f, $d);
*/

/*
$lol = $lms = new lol("LMS");
$claim = new claimContentsFreezer($lol,317706);
//$claim->dbValidate();


print_r($claim->getDbValidation());
*/

?>