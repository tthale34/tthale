<?php
include("lol.inc.all.php");

if ( $_SERVER['REQUEST_METHOD'] == 'POST' ) {
//    echo "post";
  $data = json_decode(file_get_contents("php://input")); //for post request
  $isPost = true;
} else {
//    echo "get";
  $data = json_decode(json_encode($_GET));
  $isPost = false;
}
//var_dump($data);

if ($jwt = getJWTData($data)) {

    if ($polID  = $jwt["Policy_ID"]) {
        $lms = new lol("LMS",$jwt);
        $pol = new lmsPolicy($lms,$polID);
        $doc = new documentGenerator($pol);
        if ($res = json_decode($doc->appMakeSchedule())) {
            
            //var_dump($res);
            
            if ($res->Success == 1) {
                echo json_encode(lol::result(true,"For your safety we have emailed you your schedule.",null,null));
            } else {
                echo json_encode(lol::result(false,"Sorry we could not generate your schedule, please contact your broker.",null,null));
            }
        } else {
            echo json_encode(lol::result(false,"Sorry we could not generate your schedule, please contact your broker.",null,null));
        }
    } else {
        echo json_encode(lol::result(false,"Sorry we could not identify your policy try logging in again.",null,null));
    }
} else {
    echo json_encode(lol::result(false,"Please login first",null,null));
}


?>