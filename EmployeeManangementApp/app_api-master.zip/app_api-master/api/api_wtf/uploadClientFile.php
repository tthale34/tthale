<?php
ini_set('display_errors','On');
ini_set('error_reporting', E_ALL);
include("lol.inc.all.php");
include_once("../classes/class.lmsftp.php");
use \Firebase\JWT\JWT;

if ( $_SERVER['REQUEST_METHOD'] == 'POST' ){
    
    try {
        $data = getJWTData((object) $_POST);
        $result = array(
            "Status"  => false,
            "Message"  => "No Action taken",
            "filedir"  => "",
            "filesize"  => "",
        );
        $target_dir = "/tmp/";
        for ($i=0; $i < $_POST['numberFiles']; $i++) {
            $file = explode(".", $_FILES["file".$i]["name"]);
            $temp_name = $_FILES['file'.$i]['tmp_name'];
            $newFileName = "appQuoteDoc".$i."_".$data["ClaimID"]."_".date("Ymd")."_".date("his").".".end($file);        
            $path_filename_ext = $target_dir . $newFileName;
            // Check if file already exists
            if (file_exists($path_filename_ext)) {
                $result["Message"]= "Sorry, file already exists.";
                $result["Status"]= false;
            } else {
                if (move_uploaded_file($temp_name, $path_filename_ext)) {
                    $result["Message"]= "File uploaded successfully.";
                    $result["filedir"]= $path_filename_ext;
                    $result["filesize"]= $_FILES['file'.$i]['size'];
                    //ftp file to LOL server
                    $folderdate = date("Y/m/d");
                    $localfilename = $path_filename_ext;
                    $ftp = new LMSFTP("192.168.169.101","lmsuser","lms", "/lumasfiles/");
                    $remote_folder = $ftp->get_root($localfilename);
                    $result["Status"] = $ftp->ftpfiletoserver($remote_folder, $folderdate, $localfilename);
                    $lms = new lol("LMS");
                    $claim = new claimAllRisk($lms, $data["ClaimID"] );
                    $claim->addDocument(basename($localfilename),"Quotation ($localfilename)",26);
                    $claim->emailLUMTemplate("emailLinkNotification","App Claim Document Uploaded:");
                    
                } else {
                    $result["Message"]= "Failed to uploaded file.";
                    $result["filedir"]= $path_filename_ext;
                    $result["Status"]= false;
                    $result["filesize"]= $_FILES['file'.$i]['size'];
                }            
            }
        }
                
    } catch (exception $e) {
        $result["Message"]= $e->getMessage();
        $result["Status"]= false;
    }
    print_r(json_encode($result));
    
}
?>