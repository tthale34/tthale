<?php
//ini_set('display_errors','On');
//ini_set('error_reporting', E_ALL);



include("lol.inc.all.php");


$lms = new lol("LMS");


$table = "L_VehicleMake";
$sortCol = "VehicleMake1";
if($_REQUEST['table'] != "")
{
    $table = $_REQUEST['table'];
}

if($_REQUEST['sortCol'] != "")
{
    $sortCol = $_REQUEST['sortCol'];
}

echo $lms->getTableData($table,$sortCol);

?>
