<?php
include("lol.inc.all.php");

use \Firebase\JWT\JWT;   
$data = json_decode(file_get_contents("php://input")); //for post request

if(ISSET($data)){
$_username = $data->user;
$_userpass = $data->pass;
$_otp  = isset($data->otp) ? $data->otp : false;
$jwt=isset($data->jwt) ? $data->jwt : "";
$lms = new lol("LMS");
if ($jwt){
	if ($decoded = JWT::decode($jwt, $key, array('HS256'))) {
		$__OTP  = isset($decoded->data->OTP) ? $decoded->data->OTP : false;		
		if ($__OTP) {
			if($__OTP == $_otp) {
				$u = $lms->register($_username,$_userpass, true);
//				var_dump($u);
				if ($u["Status"] == true) {
					$dat = $lms->getJwtToken();
		   $token = array( 
			   "iss" => $iss,
               "aud" => $aud,
			   "iat" => $iat,
			   "nbf" => $nbf,
			   "data" =>  $dat);

					$jwt = JWT::encode($token, $key);
			   
					$u["jwt"] = $jwt;
	
}
				
				
				
				
				
				
				
			} else {
				$u = lol::result(false,"Incorrect OTP",null,null);
				$u["jwt"] = $jwt;
				
			}
		}
		
	
}



} else {
	
				$u = $lms->register($_username,$_userpass);
				
				if ($u["Status"] == true) {
					$dat = $lms->getJwtToken();
		   $token = array( 
			   "iss" => $iss,
               "aud" => $aud,
			   "iat" => $iat,
			   "nbf" => $nbf,
			   "data" =>  $dat);

					$jwt = JWT::encode($token, $key);
			   
					$u["jwt"] = $jwt;

	
}



}
echo json_encode($u);	

}
?>