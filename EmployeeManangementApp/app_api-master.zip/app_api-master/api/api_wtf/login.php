<?php

include("lol.inc.all.php");
//ini_set('display_errors','On');
//ini_set('error_reporting', E_ALL);
use \Firebase\JWT\JWT;   
$data = json_decode(file_get_contents("php://input")); //for post request


if(ISSET($data)){
$_username = $data->user;
$_userpass = $data->pass;
$lms = new lol("LMS");
$u = $lms->login($_username,$_userpass);
if ($u["Status"] == true) {
    $dat = $lms->getJwtToken();
    $token = array( 
        "iss" => $iss,
        "aud" => $aud,
        "iat" => $iat,
        "nbf" => $nbf,
        "data" =>  $dat);
    $jwt = JWT::encode($token, $key);
    $u["jwt"] = $jwt;
    
}
echo json_encode($u);
}
?>