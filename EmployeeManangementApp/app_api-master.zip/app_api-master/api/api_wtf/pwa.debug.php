<?php
if ( $_SERVER['REQUEST_METHOD'] == 'POST' ) {
  $_xdat = json_decode(file_get_contents("php://input")); //for post request
} else {
  $_xdat = json_decode(json_encode($_GET));
}
$___myuria = explode("?",basename($_SERVER["REQUEST_URI"]) ,2);
$___myuri = $___myuria[0];

$___mylog = "pwa_[stamp]." . $___myuri . ".log";

	$___t = microtime(true);
	$___micro = sprintf("%06d",($___t-floor($___t))*1000000);
	$___d = new DateTime(date('Y-m-d H:i:s.'.$___micro,$___t));
	$___res = $___d->format("Ymd_His_u");
	if ($___mylog) {
		$___mylog = str_ireplace("[stamp]",$___res,$___mylog);
	} else {
		$___mylog = $___res;
	}



$___mylog = "/tmp/" . $___mylog;
file_put_contents($___mylog,print_r($_xdat, true));
?>