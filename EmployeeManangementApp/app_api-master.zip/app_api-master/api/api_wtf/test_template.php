<?php
ini_set('display_errors','On');
ini_set('error_reporting', E_ALL);
echo "start<br/>";
include("lol.inc.all.php");
echo "start<br/>";
include_once("../classes/templateBuilder.php");
echo "start<br/>";
//include("../classes/claimVehicleTheft.php");
//include("../classes/claimVehicleWindscreen.php");
//include("../classes/claimBuildingGeyser.php");
//include("../classes/documentGenerator.php");
echo "start<br/>";
ini_set('display_errors','On');
ini_set('error_reporting', E_ALL);
$lms = new lol("LMS");
echo "start<br/>";
$lms->login("elich@lum.co.za","test");
echo "start<br/>";
$template = new templateBuilder($lms, true, 308450, "claim/new_claim_sms_1.txt");
//print_r($template);
echo "start<br/>";

echo $template->getSql();
echo "start<br/>";
echo $template->prepTemplate();


?>