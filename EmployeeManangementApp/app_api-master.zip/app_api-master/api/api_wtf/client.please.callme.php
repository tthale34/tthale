<?php
//ini_set('display_errors','On');
//ini_set('error_reporting', E_ALL);
include("lol.inc.all.php");
use \Firebase\JWT\JWT;

if ( $_SERVER['REQUEST_METHOD'] == 'POST' ) {
  $data = json_decode(file_get_contents("php://input")); //for post request
  $isPost = true;
} else {
  $data = json_decode(json_encode($_GET));
  $isPost = false;
}

if ($jwt = getJWTData($data)) {
    $filename = "/tmp/jwt.txt";
    $input = print_r($jwt,true);
    file_put_contents($filename, $input);
    $lms = new lol("LMS",$jwt);
} else {
    echo json_encode(lol::result(false,"Your login session expired.",null,null));
    die();
}


echo json_encode(lol::result(true,"Thank you we will call you shortly.",null,null));

/*
if ($isPost) {
    if ($polID  = $jwt["Policy_ID"]) {    //save claim data
        $lms = new lol("LMS",$jwt);
        $pol = new lmsPolicy($lms,$polID);
        if (isset($data->itemID)) {
            if (isset($data->removeDate)) {
                if ($pol->itempdate($data)) {
                    // item removed
                    echo json_encode(lol::result(true,"The item was removed, you will receive your new schedule shortly.",null,null));
                }
            } else {
                // no date set
                echo json_encode(lol::result(false,"sorry, you have to select a valid date.",null,null));
            }
        } else {
            //no item selected
            echo json_encode(lol::result(false,"sorry, you have to select a valid item to remove.",null,null));
        }
    } else {
        echo json_encode(lol::result(false,"Your login session expired.",null,null));
    }

}
*/
?>