<?php
include("lol.inc.all.php");
//ini_set('display_errors','On');
//ini_set('error_reporting', E_ALL);
if ( $_SERVER['REQUEST_METHOD'] == 'POST' ) {
//    echo "post";
  $data = json_decode(file_get_contents("php://input")); //for post request
  $isPost = true;
} else {
//    echo "get";
  $data = json_decode(json_encode($_GET));
  $isPost = false;
}

echo lolHelperFunctions::app2011GenerateDocument($data, 508,"Claims History");


?>