<?php
//ini_set('display_errors','On');
//ini_set('error_reporting', E_ALL);
include("lol.inc.all.php");
use \Firebase\JWT\JWT;

if ( $_SERVER['REQUEST_METHOD'] == 'POST' ) {
  $data = json_decode(file_get_contents("php://input")); //for post request
  $isPost = true;
} else {
  $data = json_decode(json_encode($_GET));
  $isPost = false;
}

if ($jwt = getJWTData($data)) {
    $filename = "/tmp/jwt.txt";
    $input = print_r($jwt,true);
    file_put_contents($filename, $input);
    $lms = new lol("LMS",$jwt);
} else {
    echo json_encode(lol::result(false,"Your login session expired.",null,null));
    die();
}
//Save or get claim data
if ($isPost) {
    //save claim data
    $newClaimID = $lms->getDB()->getNextPID('policyclaim',1);
    $input = print_r($data,true);
    $filename = "/tmp/claim_" . $newClaimID . "_" . $data->claimTypeID . ".txt";
    file_put_contents($filename, $input);

    $claimTypeID = $data->claimTypeID;
    if ($claimTypeID == 1) {
        $claim = new claimVehicleWindscreen($lms,$data->PID, $data);
    }
    if ($claimTypeID == 5) {
        $claim = new claimVehicleTheft($lms,$data->PID, $data);
    }
    if ($claimTypeID == 46) {
        $claim = new claimBuildingGeyser($lms,$data->PID, $data);
    }
    if ($claimTypeID == 8) {
        $claim = new claimVehicleAccident($lms,$data->PID, $data);
    }
    if ($claimTypeID == 11) {
        $claim = new claimAllRisk($lms,$data->PID, $data);
    }
    if ($claimTypeID == 6) {
        $claim = new claimBuilding($lms,$data->PID, $data);
    }
    if ($claimTypeID == 15) {
        if(isset($data->LossType_ID) && $data->LossType_ID == 1009){
            $claim = new claimContentsFreezer($lms,$data->PID, $data);
        }else{
            $claim = new claimContents($lms,$data->PID, $data);
        }
    }
    echo json_encode(lol::result(true,"Claim Data saved",null,null));
    
    
} else {
    // get claim data
    $claimTypes = $lms->getDB()->data("select claimtype_id from policyclaim where pid=$data->claimID");
    $claimTypeID = $claimTypes["claimtype_id"];
    if ($claimTypeID == 1) {
        $claim = new claimVehicleWindscreen($lms,$data->claimID);
    }
    if ($claimTypeID == 5) {
        $claim = new claimVehicleTheft($lms,$data->claimID);
    }
    if ($claimTypeID == 46) {
        $claim = new claimBuildingGeyser($lms,$data->claimID);
    }
    if ($claimTypeID == 11) {
        $claim = new claimAllRisk($lms,$data->claimID);
    }
    if ($claimTypeID == 6) {
        $claim = new claimBuilding($lms,$data->claimID);
    }
    if ($claimTypeID == 15) {
	$claim = new claimContents($lms,$data->PID, $data);
/*
        if(isset($data->LossType_ID) && $data->LossType_ID == 1009){
            $claim = new claimContentsFreezer($lms,$data->PID, $data);
        }else{
            $claim = new claimContents($lms,$data->PID, $data);
        }
*/
    }
    if ($claimTypeID == 8) {
        $claim = new claimVehicleAccident($lms,$data->claimID);
    }
    $claimDet = $claim->getClaimDetail();
    echo json_encode(lol::result(true,"Your claim data.",$claimDet,null));   
}
?>
