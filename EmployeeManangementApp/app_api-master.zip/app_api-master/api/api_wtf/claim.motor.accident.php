<?php
// required headers
header("Access-Control-Allow-Origin: http://localhost");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
 // required to decode jwt
include_once '../configs/conf.php';
include_once '../libs/vendor/firebase/php-jwt/src/BeforeValidException.php';
include_once '../libs/vendor/firebase/php-jwt/src/ExpiredException.php';
include_once '../libs/vendor/firebase/php-jwt/src/SignatureInvalidException.php';
include_once '../libs/vendor/firebase/php-jwt/src/JWT.php';
use \Firebase\JWT\JWT;


$data = json_decode(file_get_contents("php://input"));
$jwt=isset($data->jwt) ? $data->jwt : "";
 
 

$res = array();
$result = array();
$data = array();
$objects = array();


$data["PID"] = "4567";
$data["Table"] = "PolicyClaim";

$data["policysection_id"] = 123;
$data["date_of_loss"] = "2020-10-20";
$data["WhereYouDrivingYN"] = "O";
$data["DriverName"] = "Piet";
$data["DriverSurname"] = "Poggompoel";
$data["DriverIDNumber"] = "7312124568085";
$data["IncidentType_ID"] = "5";



$tmpArray = array();
$tmpArray["123"] = "2016 Honda Belade 1600";
$tmpArray["456"] = "2013 BMW i330";


$tmpArray = array();
$tmpSubArray = array();
$tmpSubArray["Key"] = "123";
$tmpSubArray["Value"] = "2016 Honda Belade 1600";
$tmpArray[] = $tmpSubArray;

$tmpSubArray = array();
$tmpSubArray["Key"] = "456";
$tmpSubArray["Value"] = "2013 BMW i330";
$tmpArray[] = $tmpSubArray;

$objects["policysection_id"] = $tmpArray;



$tmpArray = array();
$tmpSubArray = array();
$tmpSubArray["Key"] = "P";
$tmpSubArray["Value"] = "Policy Holder";
$tmpArray[] = $tmpSubArray;
$tmpSubArray = array();
$tmpSubArray["Key"] = "S";
$tmpSubArray["Value"] = "My Spouse";
$tmpArray[] = $tmpSubArray;
$tmpSubArray = array();
$tmpSubArray["Key"] = "O";
$tmpSubArray["Value"] = "Another Driver";
$tmpArray[] = $tmpSubArray;
$objects["WhereYouDrivingYN"] = $tmpArray;

$tmpArray = array();
$tmpSubArray = array();
$tmpSubArray["Key"] = "1";
$tmpSubArray["Value"] = "Own damage only";
$tmpArray[] = $tmpSubArray;

$tmpArray = array();
$tmpSubArray = array();
$tmpSubArray["Key"] = "2";
$tmpSubArray["Value"] = "Own damage and TP damage";
$tmpArray[] = $tmpSubArray;

$tmpArray = array();
$tmpSubArray = array();
$tmpSubArray["Key"] = "3";
$tmpSubArray["Value"] = "Only TP damage";
$tmpArray[] = $tmpSubArray;

$tmpArray = array();
$tmpSubArray = array();
$tmpSubArray["Key"] = "4";
$tmpSubArray["Value"] = "Locks and Keys";
$tmpArray[] = $tmpSubArray;

$tmpArray = array();
$tmpSubArray = array();
$tmpSubArray["Key"] = "5";
$tmpSubArray["Value"] = "Radio not specified";
$tmpArray[] = $tmpSubArray;

$tmpArray = array();
$tmpSubArray = array();
$tmpSubArray["Key"] = "6";
$tmpSubArray["Value"] = "Fire Damage";
$tmpArray[] = $tmpSubArray;

$objects["IncidentType_ID"] = $tmpArray;

$result["Data"] = $data;
$result["Objects"] = $objects;


//$res["Result"] = $result;


// if jwt is not empty
if($jwt){
 
    // if decode succeed, show user details
    try {
        // decode jwt
        $decoded = JWT::decode($jwt, $key, array('HS256'));
 
        // set response code
        http_response_code(200);
 
        // show user details
/*
        echo json_encode(array(
            "message" => "Access granted.",
            "data" => $decoded->data
        ));
     
 */

    $res["Result"] = $result;
    $res["Status"] = true;
    $res["Message"] = "Access granted.";
 echo json_encode($res);
 
    }// if decode fails, it means jwt is invalid
catch (Exception $e){
 
    // set response code
    http_response_code(401);
 
    // tell the user access denied  & show error message
    echo json_encode(array(
        "Status" => false,
        "Message" => "Access denied.",
        "Error" => $e->getMessage()
    ));
} 
    // catch will be here
} // show error message if jwt is empty
else{
 
    // set response code
    http_response_code(401);
 
    // tell the user access denied
    echo json_encode(array("Message" => "Access denied, no JWT."));
}
 





//echo json_encode($res);

?>