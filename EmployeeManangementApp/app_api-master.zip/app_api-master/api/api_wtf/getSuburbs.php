<?php
//ini_set('display_errors','On');
//ini_set('error_reporting', E_ALL);

// phpinfo();

include("lol.inc.all.php");


$lms = new lol("LMS");


echo $lms->getSuburbs($_REQUEST['suburb']);

?>
