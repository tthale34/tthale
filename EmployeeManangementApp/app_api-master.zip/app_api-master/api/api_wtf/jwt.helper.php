<?php
include("lol.inc.all.php");

use \Firebase\JWT\JWT;

function notNull($obj, $default = null) {
    return isset($obj) ? $obj : $default;	
    
}

function getJWTData($jwtParent, $toArray = true) {
    global $key;
    if (is_object($jwtParent)) {
        if (isset($jwtParent->jwt)) {
            try {
                $jwtData = JWT::decode($jwtParent->jwt, $key, array('HS256'));
            } catch(Exception $e) {
                $jwtData = null;
            }
            if (is_object($jwtData)) {
                if (isset($jwtData->data)) {
                    if ($toArray) {
                        return (array) $jwtData->data;    
                    } else {
                        return $jwtData;    
                    }
                } else {
                    return null;
                }
            } else {
                return null;
            }
        } else {
            return null;
        }
    } else {
        return null;
    }
    
    
}

function setJWTData($data) {
    global $key;
    if ($data) {
        $token = array( 
		   "iss" => $iss,
           "aud" => $aud,
		   "iat" => $iat,
		   "nbf" => $nbf,
		   "data" =>  $data);
        $jwt = JWT::encode($token, $key);
        return $jwt;
    } else {
        return null;
    }
    
    
}


?>