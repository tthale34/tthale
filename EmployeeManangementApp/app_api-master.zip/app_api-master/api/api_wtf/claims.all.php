<?php

include("lol.inc.all.php");
//ini_set('display_errors','On');
//ini_set('error_reporting', E_ALL);


if ( $_SERVER['REQUEST_METHOD'] == 'POST' ) {
  $data = json_decode(file_get_contents("php://input")); //for post request
  $isPost = true;
} else {
  $data = json_decode(json_encode($_GET));
  $isPost = false;
}

$jwt = getJWTData($data);


if ($polID  = $jwt["Policy_ID"]) {
  
    $lms = new lol("LMS",$jwt);
    $pol = new lmsPolicy($lms,$polID);
      $res = $pol->getClaims(false);
      echo json_encode(lol::result(true,"Your open claims",$res,null));

    if ($isPost) {
      /*
      if (isset($data->accID)) {
          echo json_encode(lol::result(true,"Your Premium was resubmitted.",null,null));
      } else {
          echo json_encode(lol::result(false,"No Unpaid selected",null,null));
      }
      */
    } else {
/*
      $res = $pol->getClaims(true);
      echo json_encode(lol::result(true,"Your open claims",$res,null));
*/
    }



} else {
    echo json_encode(lol::result(false,"You need to be logged in.",null,null));
    
}

?>