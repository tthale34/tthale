<?php

include("lol.inc.all.php");
//ini_set('display_errors','On');
//ini_set('error_reporting', E_ALL);
//use \Firebase\JWT\JWT;
if ( $_SERVER['REQUEST_METHOD'] == 'POST' ) {
  $data = json_decode(file_get_contents("php://input")); //for post request
  $isPost = true;
} else {
  $data = json_decode(json_encode($_GET));
  $isPost = false;
}

if ($jwt = getJWTData($data)) {
    $filename = "/tmp/jwt.txt";
    $input = print_r($jwt,true);
    file_put_contents($filename, $input);
    $lms = new lol("LMS",$jwt);
} else {
    echo json_encode(lol::result(false,"Your login session expired.",null,null));
    die();
}


if ($isPost) {
    if ($polID  = $jwt["Policy_ID"]) {    //save claim data
        $lms = new lol("LMS",$jwt);
        $pol = new lmsPolicy($lms,$polID);
                if ($pol->clientEmailBroker($data)) {
                    // item removed
                    echo json_encode(lol::result(true,"Thank you, we sent your query to your broker.",null,null));
                } else {
		    echo json_encode(lol::result(false,"Sorry, we could not send your request to your broker. Please try again.",null,null));
		}
    } else {
        echo json_encode(lol::result(false,"Your login session expired.",null,null));
    }

}


?>
