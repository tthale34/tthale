<?php

include("lol.inc.all.php");
//ini_set('display_errors','On');
//ini_set('error_reporting', E_ALL);


if ( $_SERVER['REQUEST_METHOD'] == 'POST' ) {
  $data = json_decode(file_get_contents("php://input")); //for post request
  $isPost = true;
} else {
  $data = json_decode(json_encode($_GET));
  $isPost = false;
}

$jwt = getJWTData($data);


if ($polID  = $jwt["Policy_ID"]) {
  
    //debug $polID = 96101;
    $lms = new lol("LMS");
    $pol = new lmsPolicy($lms,$polID);

    if ($isPost) {
      if ((isset($data->dataKey)) && (isset($data->docID))) {
          echo json_encode(lol::result(true,"Your document was generated.",null,null));
      } else {
          echo json_encode(lol::result(false,"No document selected",null,null));
      }
    } else {
      $res = $pol->getDocuments();
      echo json_encode(lol::result(true,"Docs sent",$res,null));
    }



} else {
    echo json_encode(lol::result(false,"You need to be logged in.",null,null));
    
}

?>