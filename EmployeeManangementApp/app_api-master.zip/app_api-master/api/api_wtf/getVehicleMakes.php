<?php
//ini_set('display_errors','On');
//ini_set('error_reporting', E_ALL);



include("lol.inc.all.php");


$lms = new lol("LMS");




echo $lms->getVehicleMakes();

?>
