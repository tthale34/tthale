<?php    
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header("Content-Type: application/json; charset=UTF-8");  
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With,Accept"); 
// generate json web token
include_once '../configs/conf.php';
include_once '../libs/vendor/firebase/php-jwt/src/BeforeValidException.php';
include_once '../libs/vendor/firebase/php-jwt/src/ExpiredException.php';
include_once '../libs/vendor/firebase/php-jwt/src/SignatureInvalidException.php';
include_once '../libs/vendor/firebase/php-jwt/src/JWT.php';
use \Firebase\JWT\JWT; 
   
$data = json_decode(file_get_contents("php://input")); //for post request

if(ISSET($data)){
$uName = $data->username;
$pass = $data->password;
 //echo $_GET['name']; //for get request

$users_arr = array();

array_push($users_arr, (object) ['uName' => 'test@test.com',
'pass' => 'test', 
'userID' => '9111111111111',
'credentials' => [],
'data' => (object)['firstname'=>'Seloka','surname'=> 'Makola','email'=>'seloka@live.com']
], (object) ['uName' => 'test2@test2.com',
'pass' => 'test2', 
'userID' => '9111111111112',
'credentials' => []
], (object) ['uName' => 'test3',
'pass' => 'test3', 
'userID' => '9111111111113',
'credentials' => []
]);

foreach ($users_arr as $value) { 
	if($value->uName == $uName){
		if($value->pass == $pass){
			   $token = array( 
			   "iss" => $iss,
               "aud" => $aud,
			   "iat" => $iat,
			   "nbf" => $nbf,
			   "data" =>  $value->data);
			   
			   $jwt = JWT::encode($token, $key);
                 echo json_encode(array(
				"status" => true,
                "message" => "Successful login.",
                "jwt" => $jwt,
				"data"=> $value->data
            )
        );
			return;
		} 
		
	} 
} echo json_encode((object)['status' => false, 'message'=>'username or password incorrect']); 
} 

?>