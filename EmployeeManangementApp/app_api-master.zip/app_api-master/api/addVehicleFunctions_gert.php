<?php


include_once("../classes/lolDB.php");

$lms = new lol1("LMS");

function c($tvar) {
    $retval = str_replace("'","",$tvar);
    return $retval;
}

// if ( $_SERVER['REQUEST_METHOD'] == 'POST' ) {
//     $data = json_decode(file_get_contents("php://input")); //for post request
//     $isPost = true;
//   } else {
//     $data = json_decode(json_encode($_GET));
//     $isPost = false;
//   }
  $data = json_decode(json_encode($_GET));


  function getJWTData1($data)
    {
        global $key;
    }

//   $lms->writeLog($data);


  function getJWTData2($jwtParent, $toArray = true) {
    global $key;
    // if (is_object($jwtParent)) {
    //     if (isset($jwtParent->jwt)) {
    //         try {
    //             $jwtData = JWT::decode($jwtParent->jwt, $key, array('HS256'));
    //         } catch(Exception $e) {
    //             $jwtData = null;
    //         }
    //         if (is_object($jwtData)) {
    //             if (isset($jwtData->data)) {
    //                 if ($toArray) {
    //                     return (array) $jwtData->data;    
    //                 } else {
    //                     return $jwtData;    
    //                 }
    //             } else {
    //                 return null;
    //             }
    //         } else {
    //             return null;
    //         }
    //     } else {
    //         return null;
    //     }
    // } else {
    //     return null;
    // }
    
    }

//   $jwt = getJWTData1($data)
  
//   if ($jwt = getJWTData($data)) {
//       $filename = "/tmp/jwt.txt";
//       $input = print_r($jwt,true);
//       file_put_contents($filename, $input);
//       $lms = new lol("LMS",$jwt);
//   } else {
//       echo json_encode(lol::result(false,"Your login session expired.",null,null));
//       die();
//   }

class lol1 {
    protected $db;
    protected $SYS;
    protected $UserID = 0;
    protected $jwtToken;
    protected $userPolicyID;
    protected $userPolicyProfile;

    


    public function getJwtToken(){
        return $this->jwtToken;
    }
    
    public function getUserId(){
            return $this->UserID;            
    }

    public function lol2011ApiCall($method, $url, $data = false) {
        $curl = curl_init();
        switch ($method)
        {
            case "POST":
                curl_setopt($curl, CURLOPT_POST, 1);
    
                if ($data)
                    curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
                break;
            case "PUT":
                curl_setopt($curl, CURLOPT_PUT, 1);
                break;
            default:
                if ($data)
                    $url = sprintf("%s?%s", $url, http_build_query($data));
        }
        // Optional Authentication:
        curl_setopt($curl, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
        curl_setopt($curl, CURLOPT_USERPWD, "username:password");
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        $result = curl_exec($curl);
        curl_close($curl);
        return trim($result);
    }
    
    public function __construct($sys = null, $_jwtToken = null) {

        if ($_jwtToken) {
            $this->jwtToken = $_jwtToken;
            $this->UserID = $this->jwtToken["User_ID"];
            $this->userPolicyID = $this->jwtToken["Policy_ID"];
            
        }
        if ($sys) {
            $this->SYS = $sys;
            $this->db = new lolDB($this->SYS);    
        }
        
    }    

    public static function result($status, $message, $data = null, $objects = null) {
        $ret = array();
        $res = array();
        $ret["Status"] = $status;
        $ret["Message"] = $message;
        $res["Data"] = $data;
        $res["Objects"] = $objects;
        $ret["Result"] = $res;
        
        return $ret;
        
    }
    
    
    public function login($user, $password) {
        if ($u = $this->db->data("select PID, UserName, Password, LinkedPolicy_ID from users where username='$user'")) {
            //user found
            if ($u["Password"] == $password) {
                //user authenticated
                if ($u["LinkedPolicy_ID"]) {
                    //get policy info
                    $this->userPolicyID = $u["LinkedPolicy_ID"];
                    if ($p = $this->getUserPolicyProfile($u["PID"])) {
                        //policy found
                        $t =array();
                        $t["Policy_ID"] = $p["Policy_ID"];
                        $t["UserName"] = $p["UserName"];
                        $t["User_ID"] = $p["User_ID"];
                        $t["jwtTimeStamp"] = $p["jwtTimeStamp"];
                        $this->jwtToken = $t;
                        $this->UserID = $u["PID"];
                        $res = $this->result(true,"User Authenticated", $p, null);
                    } else {
                        // no policies found
                        $res = $this->result(false,"No policies found", null, null);
                    }
                    
                }
                return $res;
            } else {
                //user authentication failed
                $res = $this->result(false,"Authentication failed", null, null);
                return $res;
            }
            
        } else {
            //user not found
                $res = $this->result(false,"user not registerred", null, null);
                return $res;
            
        }
    }



    // Gert van Eeden 2021/0114 - add DateOfBirth to select statement
    public function getUserPolicyProfile($userid) {
        $sql = "
       select
            p.pid as Policy_ID
            ,p.policycode as PolicyCode
            ,p.client_id as Client_ID
            ,c.initials as Initials
            ,c.FirstNames as Names
            ,c.surname as Surname
            ,c.idnumber as IDNumber
            ,c.DateOfBirth as DateOfBirth
            ,c.clientcommonname as ClientCommonName
            ,c.HomeTelNumber as ClientHomeTel
            ,c.WorkTelNumber as ClientWorkTel
            ,c.cellnumber as ClientCell
            ,c.emailaddress as ClientEmail
            ,c.InsuredPersonOccupation as ClientOccupation
            ,b.brokername as BrokerName
            ,b.CellularNumber as BrokerCell
            ,b.EmailAddress as BrokerEmail
            ,b.FSPNO as BrokerFSP
            ,b.BrokerLogoFileName as BrokerLogoFN
            ,'https://www.lum.co.za/get_lms_logo.php?img=' || b.BrokerLogoFileName as BrokerLogoURL
            ,p.policyprefix_id as Prefix_ID
            ,ppf.insurerscheme_id as InsurerScheme_ID
            ,lis.insurer_ID as Insurer_ID
            ,ppf.policyprefix as PolicyPrefix
            ,i.insurer2 as Insurer
            ,lis.insurerscheme2 as InsurerScheme
            ,lps.status2 as PolicyStatus
            ,p.policystatus_id as PolicyStatus_ID
            ,get_SpecGrp(p.pid) AS SpecialGroups
            ,if(lis.Insurer_ID = 2 and lis.PolicyType_ID = 1 and ppf.pid <> 35 and p.PolicyScheme_Id <> 1078) then 
        		'<a href=https://www.lum.co.za/reports/policywordings/policywording_hollard_non_hv_2.pdf target=_blank>Policy Wording</a>'
         else if(lis.Insurer_ID = 2 and lis.PolicyType_ID = 1 and ppf.pid = 35 and p.PolicyScheme_Id <> 1078) then 
        		'<a href=https://www.lum.co.za/reports/policywordings/policywording_hollard_hv_2.pdf target=_blank>Policy Wording</a>'
         else if(lis.Insurer_ID = 2 and lis.PolicyType_ID = 1 and ppf.pid = 1143 and p.PolicyScheme_Id = 1078) then 
        		'<a href=https://www.lum.co.za/reports/policywordings/policywording_hollard_rh_2.pdf target=_blank>Policy Wording</a>'
         else if(lis.Insurer_ID = 1 and lis.PolicyType_ID = 1 and lis.pid <> 1038) then 
        		'<a href=https://www.lum.co.za/reports/policywordings/policywording_santam_2.pdf target=_blank>Policy Wording</a>'
         else if(lis.Insurer_ID = 1 and lis.PolicyType_ID = 1 and lis.pid = 1038) then 
        		'<a href=https://www.lum.co.za/reports/policywordings/policywording_santam_747_2.pdf target=_blank>Policy Wording</a>'
         else if(lis.Insurer_ID = 1037 and lis.PolicyType_ID = 1 and lis.pid <> 1080 and lis.pid <> 1085 and lis.pid <> 1084) then 
        		'<a href=https://www.lum.co.za/reports/policywordings/policywording_omi_op_2.pdf target=_blank>Policy Wording</a>'
         else if(lis.Insurer_ID = 1037 and lis.PolicyType_ID = 1 and lis.pid = 1080) then 
        		'<a href=https://www.lum.co.za/reports/policywordings/policywording_omi_og_2.pdf target=_blank>Policy Wording</a>'
         else if(lis.Insurer_ID = 1037 and lis.PolicyType_ID = 1 and lis.pid = 1085) then 
        		'<a href=https://www.lum.co.za/reports/policywordings/policywording_omi_dr_2.pdf target=_blank>Policy Wording</a>'
          else if(lis.Insurer_ID = 1037 and lis.PolicyType_ID = 1 and lis.pid = 1084) then 
        		'<a href=https://www.lum.co.za/reports/policywordings/policywording_omi_oc_2.pdf target=_blank>Policy Wording</a>'
         else 
        	''
         endif  endif endif endif endif endif endif  endif endif AS PolicyWording
         ,u.pid as User_ID
         ,u.UserName as UserName
        ,bb.BranchCode as branchcode
        ,bn.BankName1 as bankname
        ,p.AccountHolder as accountname
        ,p.AccountNumber as accountnumber
        ,ifnull(aad.hasAssist,'N',aad.hasAssist) as AssistYN
        ,ifnull(aad.hasAssist,'0861468882',aad.assistTel) as AssistTel
        ,ifnull(aad.hasAssist,'0861468882',aad.assistCompany_ID) as AssistCompanyID
        ,ifnull(aad.hasAssist,'0861468882',aad.assistCompanyName) as AssistCompanyName
        ,now() as jwtTimeStamp
        

            from users as u
            join policy as p on p.pid=u.linkedpolicy_id
            join client as c on c.pid=p.client_id
            left outer join l_broker as b on b.pid=p.activebroker_id
            join l_policyprefix as ppf on ppf.pid=p.policyprefix_id
            join l_insurerscheme as lis on lis.pid=ppf.insurerscheme_id
            join l_insurer as i on i.pid=lis.insurer_id
            join l_policystatus as lps on lps.pid=p.policystatus_id
            left outer join L_BankName as bn on bn.pid=p.Bank_Id
            left outer join L_BankBranch as bb on bb.pid=p.BankBranchCode_ID
            left outer join app_active_assist_details as aad on aad.policy_id=p.pid

            where
            u.pid=$userid
            
        ";
        $prof = $this->db->data($sql);
        $prof["PolicyItems"] = $this->getGrougedPolicyItems($prof["Policy_ID"],'N');
        $sqlPrems = "
        select
IFNULL(p.InvestmentPremiumTotal, 0, p.InvestmentPremiumTotal) as ph_invest   
 ,IFNULL(p.NettPremiumTotal, 0, p.NettPremiumTotal) as ph_nett   
 ,IFNULL(p.VatPremiumTotal, 0, p.VatPremiumTotal) as ph_vat 
 ,IFNULL(SasriaPremiumTotal, 0, p.SasriaPremiumTotal) as ph_sasria    
 ,IFNULL(p.AdminCostTotal, 0, p.AdminCostTotal) as ph_admin    
 ,IFNULL(p.AdminCost1Total, 0, p.AdminCost1Total) as ph_admin1 
 ,IFNULL(p.AdminCost2Total, 0, p.AdminCost2Total) as ph_admin2      
 ,IFNULL(p.BrutoPremiumTotal, 0, p.BrutoPremiumTotal) as ph_bruto   
 ,(SELECT SUM(
                                ifnull(R_HouseHoldAccidentalDamage,0,R_HouseHoldAccidentalDamage)
                                +ifnull(R_MotorVehicleCarRental,0,R_MotorVehicleCarRental)
                                +ifnull(R_ToolsPartsAccPremium,0,R_ToolsPartsAccPremium)
                                +ifnull(R_MotorVehicleHirePurchase,0,R_MotorVehicleHirePurchase)
                                +ifnull(R_MotorVehicle3rdPartyLegal,0,R_MotorVehicle3rdPartyLegal)
                                +ifnull(R_MotorvehicleKeys,0,R_MotorvehicleKeys)
                                +ifnull(R_MotorVehicleCarRadio,0,R_MotorVehicleCarRadio)) FROM POLICYSECTION WHERE POLICY_ID=P.PID AND IFNULL(ISQUOTEYN,'N',ISQUOTEYN)='N' AND DELETEDYN='N') as ph_extras          
 ,lol_CalcCommission(p.pid) as ph_agent_commission                         
 ,p.PolicyStatus_ID                                             
 ,p.ArrearAmount                                               
 ,p.R_CurrentProRata                                               
 ,p.R_ProrataOnDeletedItems 
 ,get_TotProrataForNextCollection(p.pid) as ProrataNextCollection 
                    from users as u
            join policy as p on p.pid=u.linkedpolicy_id
             where
            u.pid=$userid
        ";
        
        
        $prof["Premium"] = $this->db->data($sqlPrems);
        
        $limSql = "select * from pwa_GetClaimLimits(" . $prof["Policy_ID"] .")";
        $prof["ClaimLimits"] = $this->db->data($limSql);
        return $prof;
        
    }
    
    public function register($param, $pass, $otpConfirmed = false){
        $sqlp = "
        select first
            p.pid as Policy_ID
            ,c.CellNumber as CellNumber
            from policy as p
            join client as c on c.pid=p.client_id
            where
            ((c.emailaddress='$param')
                or (c.cellnumber='$param')
                or (p.policycode='$param')
                or (c.idnumber='$param')                
            )
            and p.policystatus_id in (2)
            order by
            p.pid desc
        ";
        
        $sqlu = "
            select first
            LinkedPolicy_ID as LinkedPolicy_ID
            from users
            where
                username='$param'
                
        ";
        
        if ( $p = $this->db->data($sqlp)) {
            if ( $u = $this->db->data($sqlu)) {
                // existing user
                if ($u["LinkedPolicy_ID"] == $p["Policy_ID"]) {
                    //existing user, same policy
                    $res = $this->result(false,"User already exist for this policy", null, null);
                } else {
                    //existing user, different policy
                    $res = $this->result(false,"User already exist, but different policy", null, null);
                }
                
            } else {
                //New User
                //TODO Create User
                if ($otpConfirmed) {
                    $policyid= $p["Policy_ID"];
                    $sqlnew = "
                        call pwa2020_create_user('$param','$pass',$policyid);
                        
                    ";
                    if ( $n = $this->db->query($sqlnew)) {
                        $urec = $this->db->data("select max(PID) as PID from users where username='$param'");
                        $uprofile = $this->getUserPolicyProfile($urec["PID"]);
                        $this->jwtToken = $uprofile;
                        $res = $this->result(true,"Profile created", $uprofile, null);                    
                    } else {
                        $res = $this->result(false,"Could not create user", null, null);                      
                    }
                } else {
//xx                    $uprofile = $this->getUserPolicyProfile($p["Policy_ID"]);
                    $u = array();
                    $xOTP = lolHelperFunctions::genOTP();
                    // send SMS
                    lolHelperFunctions::sendSMS($p["CellNumber"],"Your MyPolicy OTP is: " . $xOTP);
                    //$xOTP ='12345';
                    $uprofile["OTP"] = $xOTP;
                    $this->jwtToken = $uprofile;
                    $res = $this->result(true,"Enter OTP", null, null); 
                }
                

            }
        } else {
            // no client found
            $res = $this->result(false,"No Active Policy found for this Policy Holder.", null, null);
        }
        
        
        return $res;
    }

    
    public function getDB() {
        return $this->db;
    }




    public function getAllLookUps($prefix = 4){
        
        $tabs = array();
        
        $q  = $this->db->query("select distinct lookuptable, trim(check_lookupTableView(lookuptable,$prefix)) as ltab, if duallang='Y' then trim(lookuplistfield) || '2' else trim(lookuplistfield) endif as lookuplistfield from vAllQuestionTables where questiontypeid=2 and length(trim(lookuptable))>2
                                  and lookuptable not in ('l_caravantrailercovertype','L_City','L_City2015','L_Suburb','L_Suburb2015','l_employer','l_farmfencewallmeterial','l_staff','l_vehiclemake','l_vehiclemodel')");
        while ($r = $this->db->row($q)) {
//            $tabs[$r["lookuptable"]] = $this->db->all("select max(pid) as ID, " . $r["lookuplistfield"] . " as Value from " . $r["ltab"] . " group by value order by value");   
            $tabs[$r["lookuptable"]] = $this->db->all("select pid as ID, " . $r["lookuplistfield"] . " as Value from " . $r["ltab"] . "  order by value");   
        }
        

        return json_encode($tabs);
        
        
    }
    public function getPolicyItems($policyID, $del = null, $sec=null, $covertype =null) {
        $sql = "
            select
                ps.pid as PID
                ,ps.PolicySection_ID
                ,ps.DeletedYN
                ,ps.ItemDescription
                ,ps.Policy_ID
                ,p.Client_ID
                ,lps.Policysection2
                ,ps.ItemType_ID
                ,ps.ItemType
                ,ps.R_TotalInsuredAmount
                ,ps.R_NettPremium
                ,ps.R_TotalForLineItem
            from
                policysection as ps
                join policy as p on p.pid=ps.policy_id
                join client as c on c.pid=p.client_id
                join l_policysection as lps on lps.pid=ps.policysection_id
            where
                ps.policy_id=$policyID
                
        ";
        if ($del) {
            $sql .= " and ps.deletedyn='$del'";
        }
        if ($sec) {
            $sql .= " and ps.policysection_id in ($sec)";
        }
        if ($covertype) {
            $sql .= " and ps.policysection_id in ($covertype)";
        }
        return $this->db->all($sql);
        
        
    }

    public function getGrougedPolicyItems($policyID, $del = null, $sec=null, $covertype =null) {
        $sql = "
            select
                ps.pid as PID
                ,ps.PolicySection_ID
                ,ps.DeletedYN
                ,ps.ItemDescription
                ,ps.Policy_ID
                ,p.Client_ID
                ,ps.CellPhoneIEMI
                ,lps.Policysection2
                ,ps.ItemType_ID
                ,ps.ItemType
                ,ps.R_TotalInsuredAmount
                ,ps.R_NettPremium
                ,ps.R_TotalForLineItem
                ,if ps.policysection_id=6 then 'Y' else 'N' endif as Endos_M_YN
            from
                policysection as ps
                join policy as p on p.pid=ps.policy_id
                join client as c on c.pid=p.client_id
                join l_policysection as lps on lps.pid=ps.policysection_id
            where
                ps.policy_id=$policyID
                
        ";
        if ($del) {
            $sql .= " and ps.deletedyn='$del'";
        }
        if ($sec) {
            $sql .= " and ps.policysection_id in ($sec)";
        }
        if ($covertype) {
            $sql .= " and ps.policysection_id in ($covertype)";
        }
        $sql .= " order by ps.policysection_id ";
//echo $sql;
        $q = $this->db->query($sql);
        $res = array();
        $oldSec=0;
        $tmp = null;
        while ($r = $this->db->row($q)) {
            if ($r["PolicySection_ID"] <> $oldSec) {
                if ($oldSec>0){
                    $res[$oldSec] = $tmp;
                    $tmp = array();
                    $tmp[] = $r;
                } else {
                    
                    $tmp = array();
                    $tmp[] = $r;
                    
                }
                $oldSec = $r["PolicySection_ID"];
                
            } else {
                $tmp[] = $r;
                
            }
        }
        if ($tmp) {
            $res[$oldSec] = $tmp;
        }
        return $res;
    }

    /****************
     * Creator: Gert van Eeden
     * Date: 2021-01-13
     * 
     * New functions to get data from system for Add Vehicle App
     * 
     * 
     * */

    public function getTableData($tableName = "", $orderCol = "")
    {
        $tabs = array();
        if($tableName != "")
        {
            $sql = "select * from ". $tableName;
            if($orderCol != "")
            {
                $sql .= " ORDER BY ".$orderCol ."   ";
            }
            
        }
        // echo $sql;
        $q = $this->db->query($sql);

        while ($r = $this->db->row($q)) {
            if($orderCol != "")
            {
                $tabs[$r[$orderCol]] = $r;
            }
            else
            {
                $tabs[$r["PID"]] = $r;
           }
        }
        return json_encode($tabs);
    }

    public function getVehicleMakes()
    {
        $tabs = array();
        
        $sql = "SELECT L_VehicleMake.VehicleMake1, L_VehicleMake.PID 
            FROM L_VehicleMake  
            LEFT OUTER JOIN L_Vehicle ON L_VehicleMake.PID = L_Vehicle.VehicleMake_ID
            WHERE L_Vehicle.VehicleType_ID = 2
            
            GROUP BY L_VehicleMake.VehicleMake1, L_VehicleMake.PID 
            ORDER BY L_VehicleMake.VehicleMake1";
        
        $q = $this->db->query($sql);

        while ($r = $this->db->row($q)) {
            $tabs[$r["VehicleMake1"]] = $r;
        }
        return json_encode($tabs);
    }

    /****************
     * Creator: Gert van Eeden
     * Date: 2021-01-13
     * 
     * New functions to get data from system for Add Vehicle App
     * 
     * 
     * */
    public function getVehicleBrands($VehicleMakePID,$vehicleYear)
    {
        // echo($VehicleMakePID);
        $tabs = array();
        if($VehicleMakePID <> "" AND is_numeric($vehicleYear) AND $vehicleYear >0 )
        {
            
            $vSqlString  = "SELECT m.pid, m.ModelDescription2, v.RetailPrice FROM L_Vehicle v ";
            $vSqlString .= "LEFT OUTER JOIN l_Vehiclemake vm on vm.PID = v.VehicleMake_Id ";
            $vSqlString .= "LEFT OUTER JOIN l_VehicleModel m on m.PID = v.VehicleModel_ID ";
            $vSqlString .= "WHERE vm.pid = ".$VehicleMakePID." AND v.PriceYear = ".$vehicleYear." ORDER BY m.ModelDescription2"; 
            
            // echo ($vSqlString);
            // $preSql = "SELECT 
            //     L_VehicleMake.VehicleMake1, 
            //     L_VehicleModel.ModelDescription1,
            //     MAX(L_Vehicle.PID) AS VehiclePID,
            //     MAX(L_VehicleMake.PID) AS VehicleMakePID, 
            //     MAX(L_VehicleModel.PID) AS L_VehicleModelPID
                
            //     FROM L_Vehicle 
            //     LEFT OUTER JOIN L_VehicleMake ON L_VehicleMake.PID = L_Vehicle.VehicleMake_ID
            //     LEFT OUTER JOIN L_VehicleModel ON L_VehicleModel.PID = L_Vehicle.VehicleModel_ID
            //     WHERE 
            //     ";
            // $postSql ="
            //     GROUP BY 
            //     L_VehicleModel.ModelDescription1,
            //     L_VehicleMake.VehicleMake1
                
            //     ORDER BY L_VehicleModel.ModelDescription1,
            //     L_VehicleMake.VehicleMake1
            //     ";
            // Check for Mercedes will be implemented later
            if($VehicleMakePID == 20162 OR $VehicleMakePID == 20430)
            {
                $wherestring = " L_VehicleMake.PID = 20162
                    OR L_VehicleMake.PID = 20430 ";
            }
            else
            {
                $wherestring = " L_VehicleMake.PID = ". $VehicleMakePID." ";               
            }
            $sql = $preSql . $wherestring . $postSql;
            // echo($sql);


            $q = $this->db->query($vSqlString);
            // echo($q);
            while ($r = $this->db->row($q)) {
            //     $tabs[$r["L_VehicleModelPID"] = $r;
                // echo($r);
                // print_r($r);
                // echo($r["L_VehicleModelPID"]);
                $tabs[$r["ModelDescription2"]] = $r;
            }   
        }
        return json_encode($tabs);

    }

    /****************
     * Creator: Gert van Eeden
     * Date: 2021-01-15
     *
     * New functions to get vehicle retail value
     *
     *
     * */
    public function getRetailValue($VehicleMakeID, $VehicleYear, $VehicleModelID)
    {
        $tabs = array();
        // echo($VehicleMakeID ."-". $VehicleYear."-".$VehicleModelID);

        if($VehicleMakeID > 0 AND $VehicleYear > 0 AND   $VehicleModelID > 0)
        {
            // get Make and Model
            $sql1 = "SELECT MMCode FROM L_Vehicle WHERE VehicleMake_ID = " . $VehicleMakeID . " AND VehicleModel_ID =  " . $VehicleModelID;
            // echo("SQL:");
            // echo($sql1);
            // echo(": END SQL");
            $q1 = $this->db->query($sql1);
            $r1 = $this->db->row($q1);
            $MMCode = $r1['MMCode'];
            
            // echo($MMCode);

            if($MMCode != "")
            {
              $sql = "SELECT * FROM aMandM WHERE MMCode = '". $MMCode. "' AND YearModel ='". $VehicleYear ."' ";
            //   echo $sql;
              $q = $this->db->query($sql);
            //   echo($q);
              while ($r = $this->db->row($q)) {
                $tabs[$r["PID"]] = $r;
              }
            }
        }
        return json_encode($tabs);

    }

    /****************
     * Creator: Gert van Eeden
     * Date: 2021-01-19
     *
     * Get suburbs for drop down list
     *
     *
     * */
    public function getSuburbs($suburb)
    {
        $tabs = array();
        if(strlen($suburb) >= 4)
        {
            $sql = "SELECT * FROM L_Suburb2015 Where Suburb1 LIKE '" .$suburb . "%' ORDER BY Suburb1";
            // echo($sql);
            $q = $this->db->query($sql);
            //   echo($q);
              while ($r = $this->db->row($q)) {
                $tabs[$r["Suburb2"].$r["PID"]] = $r;
              }
        }
        return json_encode($tabs);
    }

    /****************
     * Creator: Gert van Eeden
     * Date: 2021-01-19
     *
     * Get City for drop down list
     *
     * */
    private function getItemDescription($VehicleMake_ID, $VehicleModel_ID, $VehicleYear)
    // this function will set the item description field
    {
        // get make 
        $sqlMake = "SELECT VehicleMake2 FROM L_VehicleMake WHERE PID = '" . $VehicleMake_ID . "'";
        $q = $this->db->query($sqlMake);
        $r = $this->db->row($q); 
        $Make = $r['VehicleMake2'];
        // get model
        $sqlModel = "SELECT ModelDescription2 FROM L_VehicleModel WHERE PID = '".$VehicleModel_ID."'";
        $q1 = $this->db->query($sqlModel);
        $r1 = $this->db->row($q1); 
        $Model = $r1['ModelDescription2'];
        // combine strings
        $retval = $Make . " " . $Model . " " . $VehicleYear;
        
        return $retval;
    }


     public function getCity($SuburbID="0")
    {
        $tabs = array();
        if(is_numeric($SuburbID) && $SuburbID > 0)
        {
            // $sql = "SELECT * FROM L_City WHERE PID = ".$CityID." ORDER BY City1";
            $vSqlString = "SELECT csa.city_id, c.City2, csa.PostalCode AS pcode, csa.Area_ID FROM city_sub_area_2015 csa ";
			$vSqlString .= "JOIN L_Suburb2015 s ON csa.suburb_ID = s.PID ";
            $vSqlString .= "JOIN L_City2015 c ON csa.City_ID = c.PID WHERE csa.Suburb_ID = " . $SuburbID . " ORDER BY c.City2";	
            
            // echo($vSqlString);

            $q = $this->db->query($vSqlString);
            //   echo($q);
              while ($r = $this->db->row($q)) {
                $tabs[$r["City2"].$r["PID"]] = $r;
              }

        }
        return json_encode($tabs);
    }

    public function writeLog($logval =""){
        $myfile = fopen("/tmp/addvehicle1.txt", "a");
        $txt = "WRITE LOG
";
        $txt .= "FUNCTION:".$_GET['function_name']."
";
        // $txt .= print_r($_REQUEST,true);
        $txt .= " 
".$logval;

        fwrite($myfile, $txt);
        fclose($myfile);
    }

    private function setZero($tvar) {
        if($tvar == "")
        {
            $retval = "0";
        }
        else
        {
            $retval = $tvar;
        }
        return $retval;
    }

    private function setNo($tvar) {
        if($tvar == "")
        {
            $retval = "N";
        }
        else
        {
            $retval = "Y";
        }
        return $retval;
    }

    private function getDriverBirthDate($IsRegularDriverYN, $DriverBirthDate, $user_DateOfBirth)
    {
        if($IsRegularDriverYN == "Y")
        {
            $driverArray['DOB'] = $user_DateOfBirth;
            $driverArray['AGE'] = date("Y") - substr($user_DateOfBirth,0,4) ;
            
        }
        else
        {
            $driverArray['DOB'] = $DriverBirthDate ."-01-01";
            $driverArray['AGE'] = date("Y") - $DriverBirthDate;
        }
        return $driverArray;
    }


    private function getTotal($valArray)
    {
        $total = 0;
        foreach ($valArray as $key => $value) {
            if (is_numeric($value))
            {
                $total += $value;
            }

        }
        return $total;
    }


	function recalculateItemNew($Section_ID){        
//        global $this->db;     
             
    //     /*get the policycode*/
        $sql = "SELECT Policy_Id, ItemDescription,IFNULL(ps.R_TotalForLineItem, 0, ps.R_TotalForLineItem) AS R_TotalForLineItem FROM PolicySection WHERE PID = ".$Section_ID;     

        $dsData = $this->db->query($sql);
        $dsData = $this->db->query($sql);

    //     $qCalc = $this->db->query($calcSection);
    
        $q = $this->db->query($sqlnewSection);
        //   echo($q);
        while ($row = $this->db->row($dsData)) {
            $Policy_Id = $row["Policy_Id"];
            $ItemDescription = $row["ItemDescription"];                                                                                    
        }
        
        // $this->db->sql_freeresult($dsData);                                    

        $sql  = "CALL calc_Section(".$Section_ID.", 'N'); commit;";
        // $sql = "werrwer";
        $errorSql = $this->db->query($sql);
        if($errorSql =="")
        {
            $returnJson["error"] = "Query Error";
        }

        $sqlpremium  = "SELECT CalcNettPremium from PolicySection WHERE pid = ".$Section_ID;                   
        $qpremium = $this->db->query($sqlpremium);
        //   echo($q);
        while ($row = $this->db->row($qpremium)) {
            $returnJson["CalcNettPremium"] = $row['CalcNettPremium'];    
        }
        
        $sql3  = "SELECT IFNULL(R_TotalForLineItem, 0, R_TotalForLineItem) AS R_TotalForLineItem from PolicySection WHERE pid = ".$Section_ID;                
        $q3 = $this->db->query($sql3);
        //   echo($q);
        while ($row = $this->db->row($q3)) {
            $returnJson["R_TotalForLineItem"] = $row['R_TotalForLineItem'];    
        }

        $returnJson["PolicySectionID"] = $Section_ID;
        // $sql4  = "CALL calc_prorata(0, ".$Section_ID.", lfs_MonthFirstDate(1), 'C') ;";              
        // $q4 = $this->db->query($sql4);
        // //   echo($q);
        // while ($row = $this->db->row($q4)) {
        //     $returnJson["Calculate_Prorata"] = $row['PRORATA'];    
        // }
    
        // $sql  = "CALL calc_prorata(0, ".$Section_ID.", lfs_MonthFirstDate(1), 'C');";      
        // $returnJson["Calculate_Prorata"] = $this->db->sql_error($this->db->sql_query($sql));

        
        return $returnJson;

    }    
    private function getAreaID($City_Day_Id ,$Suburb_Day_Id)
    // This function will get the AreaID
    {
        $retval = 0;
        if ($City_Day_Id > 0 AND $Suburb_Day_Day >0)
        {
            $vSqlString = "SELECT Area_ID FROM  city_sub_area_2015 WHERE City_ID = '" .$City_Day_Id. "' AND Suburb_ID = '" .$Suburb_Day_Id. "' ";
            $q = $this->db->query($vSqlString);

            while ($row = $this->db->row($q)) {
                $retval = $row['Area_ID'];    
            }
        }
        return $retval;
    }

    private function setDefaultValue($formVal,$defaultVal)
    {
        if($formVal == "")
        {
            $retval = $defaultVal;
        }
        else
        {
            $retval = $formVal;
        }
        return $retval;
    }


    public function addVehicleNew()
    {

        $storeArray = array();
        // date_default_timezone_set('Africa/Johannesburg');

        $date = date_create(date(), timezone_open('Africa/Johannesburg'));
        $currentDateTime = date_format($date, 'Y-m-d H:i:s');
        
        
        $storeArray['Policy_Id'] = $_POST['user_Policy_ID'];
        $storeArray['ItemDescription'] = $this->getItemDescription($_POST['VehicleMake_ID'], $_POST['VehicleModel_ID'], $_POST['VehicleYear']);

        $storeArray['AdditionalCoverYN'] = $this->setNo($_POST['R_AdditionalOtherAmount']);
        $storeArray['ExcessRand'] = $_POST['car_excess']; // check on lum form vor values
        // Set excess type
        switch ($storeArray['ExcessRand']){
            case "0":
                $ExcessOption_ID ="0";
                $AdditionalHigherExcessYN = "N";
                break;
            case "2500":
                $ExcessOption_ID ="3";
                $AdditionalHigherExcessYN = "N";
                break;
            default:
                $ExcessOption_ID ="11";
                $AdditionalHigherExcessYN = "Y";
                                
        }
        $storeArray['ExcessOption_ID'] = $ExcessOption_ID;
        $storeArray['AdditionalHigherExcessYN'] = $AdditionalHigherExcessYN;
        $storeArray['HigherExcessYN'] = $AdditionalHigherExcessYN;
        


        $storeArray['IsQuoteYN'] = "Y";


        $storeArray['R_TotalInsuredAmount'] = $this->getTotal([$_POST['R_Retail'], $_POST['R_AdditionalOtherAmount']] );
 
        $storeArray['PensionDiscountYN'] = 'N';
        $storeArray['YearModel'] = $_POST['VehicleYear'];

        $storeArray['ActiveFromDate'] = $currentDateTime;
        $storeArray['ActiveToDate'] = $currentDateTime;
        $storeArray['ClientDateTime'] = $currentDateTime;
        $storeArray['ServerDateTime'] = $currentDateTime;

        $storeArray['DeletedYN'] = 'N';
        $storeArray['ToParentYN'] = 'N';
        $storeArray['FromChildYN'] = 'N';

        $storeArray['IsPolicyHolderYN'] = $_POST['IsPolicyHolderYN'];

        $driverArray = $this->getDriverBirthDate($_POST['IsRegularDriverYN'],$_POST['DriverBirthDate'],$_POST['user_DateOfBirth'] );
        
        $storeArray['DriverBirthDate'] = $driverArray['DOB']; 
        $storeArray['DriverAge'] = $driverArray['AGE'];
        $storeArray['DriverLicenceIssueDate'] = $_POST['DriverLicenceIssueYear']."-01-01";
        $storeArray['DriverPeriodLicence'] = date("Y") - $_POST['DriverLicenceIssueYear'];

        if ($_POST['VehicleRadioYN'] == 'N' || $_POST['VehicleRadioYN'] == "")
        {
            $storeArray['VehicleRadioYN'] = 'N';
            $storeArray['R_RadioInsuredAmount'] = "";
        }
        else
        {
            $storeArray['VehicleRadioYN'] = "Y";
            $storeArray['R_RadioInsuredAmount'] = $_POST['VehicleRadioYN'];
        }

        if ($_POST['LocksKeysYN'] == 'N' || $_POST['LocksKeysYN'] == '' )
        {
            $storeArray['LocksKeysYN'] = 'N';
        }
        else
        {
            $storeArray['LocksKeysYN'] = "Y";
            $storeArray['R_MotorVehicleKeysAmount'] = $_POST['LocksKeysYN'];
            
        }
                
        $storeArray['R_Retail'] = $_POST['R_Retail'];

        $storeArray['VehicleMake_ID'] = $_POST['VehicleMake_ID'];
        $storeArray['VehicleModel_ID'] = $_POST['VehicleModel_ID'];

        
        if ($_POST['IsRegularDriverYN'] == 'N')
        {
            $storeArray['DriverofVehicle'] = $_POST['DriverofVehicle'] ;
            $storeArray['DriverInitials'] = $_POST['DriverInitials'] ;
        }
        else
        {
            $storeArray['DriverofVehicle'] = $_POST['user_Surname'] ;
            $storeArray['DriverInitials'] = $_POST['user_Initials'] ;
        }

        $storeArray['CoverType_ID'] = $_POST['CoverType_ID'];
        $storeArray['VehiclePurpose_ID'] = $_POST['VehiclePurpose_ID'];
        $storeArray['ElectronicTrackerYN'] = $_POST['ElectronicTrackerYN'];
        $storeArray['R_AdditionalOtherAmount'] = $_POST['R_AdditionalOtherAmount'];
        $storeArray['InsuredAddressSuburb_ID'] = $_POST['[suburbs] ']; //? must it only be the suburb day?
        $storeArray['VehicleRegisteredInNameOf'] = $_POST['VehicleRegisteredInNameOf'];

        $storeArray['M1Option_ID'] = $this->setDefaultValue($_POST['M1Option_ID'],"0");


        $storeArray['OverNightParking_ID'] = $_POST['OverNightParking_ID']; 

        $storeArray['SmartOption_ID'] = $this->setDefaultValue($_POST['SmartOption_ID'],"0");
        // $_POST['SmartOption_ID']; 

        $storeArray['DriverLicenceIssueDate'] = $_POST['DriverLicenceIssueYear'] . "-01-01";
        $storeArray['Suburb_Day_Id'] = $_POST['suburbs'];  //? must it only be the suburb day?
        $storeArray['City_Day_Id'] = $_POST['InsuredAddressCity_ID'];
        // 

        $storeArray['VehicleArea_ID'] = $this->getAreaID($storeArray['City_Day_Id'],$storeArray['Suburb_Day_Id']);


        $storeArray['OMI4x4And4x2YN'] =  $this->setDefaultValue($_POST['4x4cover'],"N");

        $storeArray['OutStandingHirePurchaseYN'] = $this->setDefaultValue($_POST['creditShortfallCS'],"N");
        
        // $_POST['creditShortfallCS'];
        
        $storeArray['R_OutStandingHirePurchaseAmount'] = $this->setDefaultValue($_POST['credit_shortfall_amount'],"0");
        
        
//         // ? where do i save credit shortfall? creditShortfallCS

//         // $storeArray[''] = $_POST[''];
//         // $storeArray[''] = $_POST[''];

//         // BUILD SQL 
        // store blank record
        $sqlnewSection  = "SELECT new_Section(".$storeArray['Policy_Id'].", 2, 0) AS NewSection_ID; commit;";

        $q = $this->db->query($sqlnewSection);
        //   echo($q);
        while ($r = $this->db->row($q)) {
            $NewItem_ID = $r["NewSection_ID"];
        }

        $updateStr ="";
        $sqlstart = " UPDATE PolicySection SET  ";
        // $sqlMiddle =" VALUES (";
        foreach ($storeArray as $key => $value) {
            $updateStr .= $key. " = 
            '".c($value)."' ,";
        }
        $sqlUpdate = $sqlstart . substr($updateStr, 0, -1). " WHERE PID ='" . $NewItem_ID  . "'";

        $qUpdate = $this->db->query($sqlUpdate);

        $calcSection  = "SELECT calc_Section(".$NewItem_ID.", 'Y') ; commit;";
        $qCalc = $this->db->query($calcSection);

        $retval = $this->recalculateItemNew($NewItem_ID);



        $myfile = fopen("/tmp/addvehicle1.txt", "a");
        $txt = "

ADD VEHICLE FUNCTION:
";

        $txt .= print_r($_POST,true);
        $txt .= print_r($storeArray,true);
//         $txt .= $currentDateTime." SQL: 
// ".$sqlnewSection." ITEMID: ".$NewItem_ID." SQL2: ".$sql."CALCRESULT:".print_r($retval,true);

        $txt .= json_encode($retval);
        $txt .= print_r($driverArray,true);
        $txt .= " 
JWT:". $this->returnJWT();

        fwrite($myfile, $txt);
        fclose($myfile); 

        return json_encode($retval);
    }

    public function saveVehicleNew()
    {

        $storeArray = array();
        // date_default_timezone_set('Africa/Johannesburg');

        $date = date_create(date(), timezone_open('Africa/Johannesburg'));
        $currentDateTime = date_format($date, 'Y-m-d H:i:s');
        
        
        // $sql  = "CALL calc_prorata(".$_POST['user_Client_ID'] .","    .$_POST['PolicySectionID'].", lfs_MonthFirstDate(1), 'C');";      
//        cover_start_date
        $sql  = "CALL calc_prorata(0,"    .$_POST['PolicySectionID'].", '".$_POST['cover_start_date']."', 'C');commit;";      
        $q = $this->db->query($sql);

        $myfile = fopen("/tmp/addvehicle1.txt", "a");
        $txt = $sql."

SAVE VEHICLE FUNCTION: CALC PRO-RATA
";

//         // $txt .= print_r($_POST,true);
        $txt .= $calcProRata.print_r($_REQUEST,true);
        $txt .= " 
JWT:". $this->returnJWT();

        // $txt .= json_encode($retval); 
        fwrite($myfile, $txt);
        fclose($myfile);  

        return json_encode($retval); 
    }

    public function returnJWT()
    {
        $retval = $_POST['jwt'];
        return $retval;
    }

    public function saveFourFieldsNew1()
    {
        $storeArray = array();

        $date = date_create(date(), timezone_open('Africa/Johannesburg'));
        $currentDateTime = date_format($date, 'Y-m-d H:i:s');
        
        
        $PolicySectionID = $_POST['PolicySectionID'];

        $storeArray['VehicleRegistrationNumber'] = $_POST['reg_number'];
        $storeArray['VehicleVIN'] = $_POST['vin_number'];
        $storeArray['VehicleEngineNumber'] = $_POST['engine_number'];
        
        $storeArray['Bank_ID'] = $_POST['fin_institution'];
        $storeArray['FinanceAccountNumber'] = $_POST['fin_account_number'];
        

        $updateStr ="";
        $sqlstart = " UPDATE PolicySection SET  ";
        // $sqlMiddle =" VALUES (";
        foreach ($storeArray as $key => $value) {
            $updateStr .= $key. " = 
            '".c($value)."' ,";
        }
        $sqlUpdate = $sqlstart . substr($updateStr, 0, -1). " WHERE PID ='" . $PolicySectionID  . "'";

        $qUpdate = $this->db->query($sqlUpdate);

        $this->writeLog("SAVE FOUR FIELDS:".$sqlUpdate ); // . print_r($_REQUEST,true)
        $retval['action'] ="SAVE FOUR FIELDS";
        return json_encode($retval); 
    }


    public function sendClientSMS() 
    {
        $this->smsClient($_POST['message']);
        $this->writeLog("SEND CLIENT SMS");

    }




    public function sendBrokerSMS()
    {
        $this->writeLog("SEND BROKER SMS");
    }

    public function getBankList()
    {
        

        $tabs = array();
        $sql = "SELECT * FROM L_BankName WHERE DeletedYN <> 'N' ORDER BY BankName1";
        $q = $this->db->query($sql);
        //   echo($q);
        while ($r = $this->db->row($q)) {
        $tabs[$r["BankName1"].$r["PID"]] = $r;
        }
        $this->writeLog("SEND BROKER SMS:".$sql );
        return json_encode($tabs);
    }

}

$lms = new lol1("LMS");


// echo ($lms->getCity($_REQUEST['suburbID']));

// echo "INSIDE ADD VEHICLE";
// echo $lms->writeLog("OUTSIDE SWITCH");
// echo $lms->writeLog();

switch($_GET['function_name'])
{
    case "add_vehicle":
        // echo "INSIDE ADD VEHICLE";
        // echo $lms->writeLog("INSIDE SWITCH");
        // echo $lms->writeLog("INSIDE SWITCH");
        echo $lms->addVehicleNew();
        break;

    case "save_vehicle":
        // echo "INSIDE ADD VEHICLE";
        // echo $lms->writeLog("INSIDE SWITCH");
        // echo $lms->writeLog("INSIDE SWITCH");
        echo $lms->saveVehicleNew();
        break;
    case "send_client_sms":
        // echo $lms->writeLog("1");
        echo $lms->sendClientSMS();
        // echo $lms->writeLog('2');
        // echo $lms->writeLog('3');
        break;      
    case "send_broker_sms":
        // echo $lms->writeLog("1");
        echo $lms->sendBrokerSMS();
        // echo $lms->writeLog('2');
        // echo $lms->writeLog('3');
        break;      
    case "get_bank_list":
        // echo $lms->writeLog("1");
        echo $lms->getBankList();
        // echo $lms->writeLog('2');
        // echo $lms->writeLog('3');
        break;      
    case "save_four_fields":
        // echo $lms->writeLog("1");
        echo $lms->saveFourFieldsNew1();
        // echo $lms->writeLog('2');
        // echo $lms->writeLog('3');
        break;      
                            
    default:
        // echo $lms->writeLog();
        $blank = 1; // do nothing
}


$lms->writeLog("FINALWRITE:".print_r($data, true));

 